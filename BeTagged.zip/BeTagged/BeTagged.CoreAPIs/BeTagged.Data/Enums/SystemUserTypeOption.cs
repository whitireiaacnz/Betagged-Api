﻿namespace BeTagged.Data.Enums;

[EnumLookupTable(typeof(SystemUserType))]
public enum SystemUserTypeOption : byte
{
    Influencer = 1,
    BrandMember = 2,
    BeTaggedOps = 3
}
