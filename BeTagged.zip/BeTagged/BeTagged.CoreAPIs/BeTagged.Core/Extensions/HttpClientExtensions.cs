﻿using System.IO;
using System.Net.Http;
using System.Threading;

namespace BeTagged.Core.Extensions;

public static class HttpClientExtensions
{
    public static async Task<Stream> GetFileStream(this HttpClient httpClient, string url,
        CancellationToken cancellationToken = default)
    {
        var response = await httpClient.GetAsync(url, cancellationToken);
        return await response.Content.ReadAsStreamAsync(cancellationToken);
    }
}
