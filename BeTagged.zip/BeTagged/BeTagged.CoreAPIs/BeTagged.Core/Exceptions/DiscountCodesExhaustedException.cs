﻿using System;

namespace BeTagged.Core.Exceptions;

public class DiscountCodesExhaustedException : Exception
{
    private const string DefaultMessage =
        "Discount code is not available for this Product. Please upload discount codes before approving the request.";

    public DiscountCodesExhaustedException(string message = DefaultMessage) : base(message)
    {
    }
}
