﻿using System.Net.Mail;

namespace BeTagged.Core.Utils;

public static class EmailUtil
{
    public static string GetDomain(string email) => new MailAddress(email).Host.ToLower();
}
