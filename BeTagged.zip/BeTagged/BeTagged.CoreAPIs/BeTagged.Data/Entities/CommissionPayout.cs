﻿using System;
using BeTagged.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(CommissionPayoutEntityConfiguration))]
public class CommissionPayout : BaseEntity
{
    public int CommissionPayoutId { get; set; }

    public int InfluencerId { get; set; }

    public int ProductSaleId { get; set; }

    public int TransactionId { get; set; }

    public int BrandOrganizationId { get; set; }

    public DateTime PaidOnUtc { get; set; }

    // Foreign Keys
    public Influencer Influencer { get; set; }

    public ProductSale ProductSale { get; set; }

    public Transaction Transaction { get; set; }

    public BrandOrganization BrandOrganization { get; set; }
}
