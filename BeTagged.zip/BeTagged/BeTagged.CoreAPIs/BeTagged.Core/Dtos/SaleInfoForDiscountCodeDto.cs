﻿using System;

namespace BeTagged.Core.Dtos;

public class SaleInfoForDiscountCodeDto
{
    public int BrandOrganizationId { get; set; }

    public int BrandProductId { get; set; }

    public int? ProductPromotionId { get; set; }

    public int? InfluencerId { get; set; }

    public SystemSalesChannelOption? SalesChannel { get; set; }

    public int NumberOfSales { get; set; }

    public DateTime SalesCountTillUtc { get; set; }

    public decimal Price { get; set; }

    public int CommissionPercentage { get; set; }

    public decimal InfluencerCommissionPercentage { get; set; }
}
