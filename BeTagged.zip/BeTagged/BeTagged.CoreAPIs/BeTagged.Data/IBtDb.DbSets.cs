﻿using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data;

public partial interface IBtDb
{
    DbSet<User> Users { get; set; }

    DbSet<Influencer> Influencers { get; set; }

    DbSet<BrandMember> BrandMembers { get; set; }

    DbSet<Phone> Phones { get; set; }

    DbSet<EmailAddress> EmailAddresses { get; set; }

    DbSet<PhoneOtp> PhoneOtps { get; set; }

    DbSet<EmailOtp> EmailOtps { get; set; }

    DbSet<BrandOrganization> BrandOrganizations { get; set; }

    DbSet<BrandMembership> BrandMemberships { get; set; }

    DbSet<PasswordResetToken> PasswordResetTokens { get; set; }

    DbSet<BrandProduct> BrandProducts { get; set; }

    DbSet<BrandProductDiscountCodesFile> BrandProductDiscountCodesFiles { get; set; }

    DbSet<BrandProductDiscountCode> BrandProductDiscountCodes { get; set; }

    DbSet<ProductPromotion> ProductPromotions { get; set; }

    DbSet<ProductPromotionRequest> ProductPromotionRequests { get; set; }

    DbSet<ProductPromotionLink> ProductPromotionLinks { get; set; }

    DbSet<ProductSale> ProductSales { get; set; }

    DbSet<CommissionPayout> CommissionPayouts { get; set; }

    DbSet<Transaction> Transactions { get; set; }

    DbSet<ShortenedLink> ShortenedLinks { get; set; }

    DbSet<BrandProductsSalesDataFile> BrandProductsSalesDataFiles { get; set; }

    DbSet<BrandMembershipInvitation> BrandMembershipInvitations { get; set; }

    DbSet<InfluencerBankAccount> InfluencerBankAccounts { get; set; }

    DbSet<InAppNotification> InAppNotifications { get; set; }

    DbSet<NotificationProcessorLog> NotificationProcessorLogs { get; set; }

    DbSet<WebhookMappingDetail> ShopifyWebhookMappingDetails { get; set; }

    // System lookup tables
    DbSet<SystemRole> SystemRoles { get; set; }

    DbSet<SystemUserType> SystemUserTypes { get; set; }

    DbSet<SystemCategory> SystemCategories { get; set; }

    DbSet<SystemCountry> SystemCountries { get; set; }

    DbSet<SystemCurrencyCode> SystemCurrencyCodes { get; set; }

    DbSet<SystemSalesChannel> SystemSalesChannels { get; set; }

    DbSet<SystemApprovalStatus> SystemApprovalStatuses { get; set; }

    DbSet<SystemShortenedLinkEntityType> SystemShortenedLinkEntityTypes { get; set; }

    DbSet<SystemInvitationStatus> SystemInvitationStatuses { get; set; }

    DbSet<SystemProductUrlType> SystemProductUrlTypes { get; set; }

    DbSet<SystemInAppNotificationType> SystemInAppNotificationTypes { get; set; }

    DbSet<SystemSalesSource> SystemSalesSources { get; set; }

    DbSet<T> Set<T>() where T : class;
}
