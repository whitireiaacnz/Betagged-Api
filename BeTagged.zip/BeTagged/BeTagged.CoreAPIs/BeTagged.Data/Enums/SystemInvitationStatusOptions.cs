﻿using System.Runtime.Serialization;

namespace BeTagged.Data.Enums;

[EnumLookupTable(typeof(SystemInvitationStatus))]
public enum SystemInvitationStatusOptions : byte
{
    [EnumMember(Value = "Invitation Sent")]
    InvitationSent = 1,
    Active = 2
}
