﻿using System;
using System.Threading.Tasks;
using System.Transactions;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data;

public static class BeTaggedTransaction
{
    public static async Task<TResult> ExecuteInTransactionAsync<TResult>(this IBtDb db, Func<Task<TResult>> action, Func<TResult, bool> commitCriteria = null)
    {
        var strategy = (BeTaggedSqlExecutionStrategy)db.Database.CreateExecutionStrategy();

        try
        {
            strategy.SuspendRetryStrategy();

            return await strategy.ExecuteAsync(async () =>
            {
                using var scope = GetTransactionScope();
                var result = await action.Invoke();

                if (commitCriteria is null || commitCriteria(result))
                {
                    scope.Complete();
                }

                return result;
            });
        }
        finally
        {
            strategy.EnableRetryStrategy();
        }
    }

    public static async Task ExecuteInTransactionAsync(this IBtDb db, Func<Task> action)
    {
        var strategy = (BeTaggedSqlExecutionStrategy)db.Database.CreateExecutionStrategy();

        try
        {
            strategy.SuspendRetryStrategy();

            await strategy.ExecuteAsync(async () =>
            {
                using var scope = GetTransactionScope();
                await action.Invoke();
                scope.Complete();
            });
        }
        finally
        {
            strategy.EnableRetryStrategy();
        }
    }

    public static void ExecuteInTransaction(this IBtDb db, Action action)
    {
        var strategy = (BeTaggedSqlExecutionStrategy)db.Database.CreateExecutionStrategy();

        try
        {
            strategy.SuspendRetryStrategy();

            strategy.Execute(() =>
            {
                using var scope = GetTransactionScope();
                action.Invoke();
                scope.Complete();
            });
        }
        finally
        {
            strategy.EnableRetryStrategy();
        }
    }

    public static TResult ExecuteInTransaction<TResult>(this IBtDb db, Func<TResult> action, Func<TResult, bool> commitCriteria = null)
    {
        var strategy = (BeTaggedSqlExecutionStrategy)db.Database.CreateExecutionStrategy();

        try
        {
            strategy.SuspendRetryStrategy();

            return strategy.Execute(() =>
             {
                 using var scope = GetTransactionScope();
                 var result = action.Invoke();

                 if (commitCriteria is null || commitCriteria(result))
                 {
                     scope.Complete();
                 }

                 return result;
             });
        }
        finally
        {
            strategy.EnableRetryStrategy();
        }
    }

    private static TransactionScope GetTransactionScope() => new(TransactionScopeOption.Required,
        new TransactionOptions
        {
            IsolationLevel = IsolationLevel.ReadCommitted,
            Timeout = TimeSpan.FromMinutes(1)
        }, TransactionScopeAsyncFlowOption.Enabled);
}
