﻿using System.Threading;
using BeTagged.Core.Dtos;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Storage;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Queries.Profile;

public static class GetBrandMemberProfile
{
    public class Query : IRequest<BrandMemberProfileDto>
    {
    }

    public class Handler : IRequestHandler<Query, BrandMemberProfileDto>
    {
        private readonly ICurrentBrandMember _currentBrandMember;

        private readonly IReadOnlyRepository<Data.Entities.BrandMember> _brandRepo;

        private readonly IStorageService _storageService;

        public Handler(ICurrentBrandMember currentBrandMember, IReadOnlyRepository<BrandMember> brandRepo,
            IStorageService storageService)
        {
            _currentBrandMember = currentBrandMember;
            _brandRepo = brandRepo;
            _storageService = storageService;
        }

        public async Task<BrandMemberProfileDto> Handle(Query request, CancellationToken cancellationToken)
        {
            var brandProfileSpec = new GetBrandMemberProfileSpec(_currentBrandMember.BrandMembershipId, _currentBrandMember.BrandMemberId);
            var profile = await _brandRepo.SingleOrDefaultAsync(brandProfileSpec, cancellationToken);

            if (profile is not null)
            {
                profile.ProfilePicUrl = _storageService.GetSignedUrl(profile.ProfilePicUrl);
            }

            return profile;
        }
    }
}
