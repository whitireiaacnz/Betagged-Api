﻿using System;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetBrandMembershipInvitationSpec : ISingleResultQuerySpecification<BrandMembershipInvitation, BrandMembershipInvitation>
{
    public GetBrandMembershipInvitationSpec(int brandOrganizationId, string email)
    {
        var normalizedEmail = email.ToUpper();
        Query = q => q
            .Where(x => x.BrandOrganizationId == brandOrganizationId)
            .Where(x => x.NormalizedEmailAddress == normalizedEmail);
    }

    public GetBrandMembershipInvitationSpec(int brandOrganizationId, int invitationId, bool includeBrandOrganization = false)
    {
        Query = q => GetQuery(q, brandOrganizationId, invitationId, includeBrandOrganization);
    }

    public Func<IQueryable<BrandMembershipInvitation>, IQueryable<BrandMembershipInvitation>> Query { get; }

    private static IQueryable<BrandMembershipInvitation> GetQuery(IQueryable<BrandMembershipInvitation> queryable, int brandOrganizationId,
        int invitationId, bool includeBrandOrganization)
    {
        IQueryable<BrandMembershipInvitation> query = queryable.Include(x =>
            x.BrandMembership.BrandMember.User);

        if (includeBrandOrganization)
        {
            query = query.Include(x => x.BrandOrganization);
        }

        query = query.Where(x => x.BrandOrganizationId == brandOrganizationId)
            .Where(x => x.BrandMembershipInvitationId == invitationId);

        return query;
    }
}
