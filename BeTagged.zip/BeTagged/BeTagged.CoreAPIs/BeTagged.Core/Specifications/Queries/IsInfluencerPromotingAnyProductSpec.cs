﻿using System;
using System.Threading;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class IsInfluencerPromotingAnyProductSpec : IAnyQuerySpecification<ProductPromotion>
{
    public IsInfluencerPromotingAnyProductSpec(int influencerId)
    {
        Query = async (q, ctx) => await q
            .AnyAsync(x => x.InfluencerId == influencerId && !x.IsDeleted, ctx);
    }

    public Func<IQueryable<ProductPromotion>, CancellationToken, Task<bool>> Query { get; }
}
