﻿using System;
using System.Threading;
using BeTagged.Core.Services.BackgroundWork;
using BeTagged.Core.Services.Shopify;

namespace BeTagged.Core.Commands;

public static class ShopifyWebhookEvent
{
    public record Command(string Topic, dynamic Payload) : IRequest<Response>;

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IShopifyService _shopifyService;
        private readonly IBackgroundWorker _backgroundWorker;

        public Handler(IBackgroundWorker backgroundWorker, IShopifyService shopifyService)
        {
            _backgroundWorker = backgroundWorker;
            _shopifyService = shopifyService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            _backgroundWorker.Schedule(() => _shopifyService.ShopifyWebhookEventHandler(request.Topic, (object)request.Payload),
            DateTime.Now.AddMinutes(5));

            return new Response();
        }
    }

    public class Response
    {
    }
}
