﻿using System.Threading;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Commands.Authentication;

public static class VerifyBrandMemberAuthenticateByPhone
{
    public record Command(string CountryCode, string Phone, string Otp, string InvitationKey) : IRequest<BrandMemberAuthenticationResponse>;

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.CountryCode).NotEmpty();
            RuleFor(x => x.Phone).NotEmpty();
            RuleFor(x => x.Otp).NotEmpty();
        }
    }

    public class Handler : IRequestHandler<Command, BrandMemberAuthenticationResponse>
    {
        private readonly IAuthenticationService _authenticationService;

        public Handler(IAuthenticationService authenticationService) => _authenticationService = authenticationService;

        public async Task<BrandMemberAuthenticationResponse> Handle(Command request, CancellationToken cancellationToken)
            => await _authenticationService.AuthenticateBrandMemberByPhoneAsync(request.CountryCode, request.Phone, request.Otp,
                request.InvitationKey, cancellationToken);
    }
}
