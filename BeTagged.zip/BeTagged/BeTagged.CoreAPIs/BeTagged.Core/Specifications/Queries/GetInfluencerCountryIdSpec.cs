﻿using System;
using BeTagged.Data.Specifications;

namespace BeTagged.Core.Specifications.Queries;

public class GetInfluencerCountryIdSpec : ISingleResultQuerySpecification<Influencer, byte?>
{
    public GetInfluencerCountryIdSpec(int id)
    {
        Query = queryable => queryable
            .Where(x => x.InfluencerId == id)
            .Select(x => x.CountryId);
    }

    public Func<IQueryable<Influencer>, IQueryable<byte?>> Query { get; }
}
