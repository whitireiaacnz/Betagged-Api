﻿using System;
using System.ComponentModel.DataAnnotations;

namespace BeTagged.Data.Entities;

public class PasswordResetToken : BaseEntity
{
    public int PasswordResetTokenId { get; set; }

    [MaxLength(64)]
    public string Token { get; set; }

    public DateTime ValidTillUtc { get; set; }

    public int UserId { get; set; }

    // Foreign keys
    public User User { get; set; }
}
