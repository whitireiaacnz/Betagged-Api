﻿using System;
using BeTagged.Core.Dtos;

namespace BeTagged.Core.Services.Storage;

public interface IStorageService
{
    Task<string> UploadFileAsync(FileUploadDto fileUpload);

    string GetUploadSignedUrl(FileUploadSignedUrlDto signedUrlDto);

    Task DeleteFileAsync(string file);

    string GetSignedUrl(string file, DateTime? expiry = null);
}
