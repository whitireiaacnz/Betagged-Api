﻿using System;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetInfluencerSpec : ISingleResultQuerySpecification<Influencer, Influencer>
{
    public GetInfluencerSpec(int influencerId)
    {
        Query = queryable => queryable
            .Include(x => x.User)
            .Where(x => x.InfluencerId == influencerId);
    }

    public Func<IQueryable<Influencer>, IQueryable<Influencer>> Query { get; }
}
