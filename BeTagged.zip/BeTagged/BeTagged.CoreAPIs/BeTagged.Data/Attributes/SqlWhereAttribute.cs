﻿using System;

namespace BeTagged.Data.Attributes;

[AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
public class SqlWhereAttribute : Attribute
{
    public SqlWhereAttribute(string sqlWhere) => SqlWhere = sqlWhere;

    public string SqlWhere { get; }
}
