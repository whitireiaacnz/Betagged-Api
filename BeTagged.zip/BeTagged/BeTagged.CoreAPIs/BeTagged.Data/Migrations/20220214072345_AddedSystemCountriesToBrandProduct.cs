﻿using BeTagged.Data.Seed;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class AddedSystemCountriesToBrandProduct : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AddColumn<byte>(
            name: "system_currency_id",
            schema: "public",
            table: "brand_products",
            type: "smallint",
            nullable: false,
            defaultValue: (byte)0);

        migrationBuilder.CreateTable(
            name: "system_currencies_lut",
            schema: "public",
            columns: table => new
            {
                system_currency_id = table.Column<byte>(type: "smallint", nullable: false),
                name = table.Column<string>(type: "text", nullable: true)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_system_currencies_lut", x => x.system_currency_id);
            });

        EnumLookupTableSeeder.FillEnumLookup(migrationBuilder, "system_currencies_lut", typeof(SystemCurrencyCodeOption));

        migrationBuilder.CreateIndex(
            name: "ix_brand_products_system_currency_id",
            schema: "public",
            table: "brand_products",
            column: "system_currency_id");

        migrationBuilder.AddForeignKey(
            name: "fk_brand_products_system_currencies_lut_system_currency_id",
            schema: "public",
            table: "brand_products",
            column: "system_currency_id",
            principalSchema: "public",
            principalTable: "system_currencies_lut",
            principalColumn: "system_currency_id",
            onDelete: ReferentialAction.Restrict);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropForeignKey(
            name: "fk_brand_products_system_currencies_lut_system_currency_id",
            schema: "public",
            table: "brand_products");

        migrationBuilder.DropTable(
            name: "system_currencies_lut",
            schema: "public");

        migrationBuilder.DropIndex(
            name: "ix_brand_products_system_currency_id",
            schema: "public",
            table: "brand_products");

        migrationBuilder.DropColumn(
            name: "system_currency_id",
            schema: "public",
            table: "brand_products");
    }
}
