﻿using System.Threading;
using BeTagged.Core.Dtos;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Users;
using BeTagged.Core.Utils;

namespace BeTagged.Core.Commands.Profile;

public static class AddEmail
{
    public class Command : IRequest<Response>
    {
        public string Email { get; set; }
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator(ICurrentUser currentUser)
        {
            RuleFor(x => x.Email)
                .Cascade(CascadeMode.Stop)
                .NotEmpty().EmailAddress()
                .Must(x => !BlacklistedEmailDomains.BlacklistEmailDomains.Contains(EmailUtil.GetDomain(x)))
                .When(_ => currentUser.UserType == SystemUserTypeOption.BrandMember)
                .WithMessage(ValidationMessages.BlacklistedEmailMessage);

            RuleFor(x => x.Email).NotEmpty().EmailAddress();
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IUserService _userService;

        public Handler(IUserService userService)
        {
            _userService = userService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var emailResponse = await _userService.AddUnverifiedEmailAsync(request.Email);
            return emailResponse.Map<Response>();
        }
    }

    public class Response : Result<UserEmailAddressDto>
    {
    }
}
