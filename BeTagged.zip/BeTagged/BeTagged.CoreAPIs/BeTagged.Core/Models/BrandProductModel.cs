﻿using System;
using AutoMapper;
using BeTagged.Core.Mapping;
using BeTagged.Core.Services.Storage;
using Newtonsoft.Json;

namespace BeTagged.Core.Models;

public class BrandProductModel : Result, ICustomMap<BrandProduct, BrandProductModel>
{
    public BrandProductModel()
    {
        SocialMediaKits = new();
        ProductUrls = new();
        ShowCaseMediaUrls = Enumerable.Empty<string>();
        Categories = Enumerable.Empty<LookupItem>();
    }

    public virtual int BrandProductId { get; set; }

    public string Name { get; set; }

    public string ProductCode { get; set; }

    public string Description { get; set; }

    public decimal Price { get; set; }

    public decimal CommissionPercentage { get; set; }

    public int BuyerDiscountPercentage { get; set; }

    public bool IsApprovalBasedOffer { get; set; }

    public string BannerImageUrl { get; set; }

    public IEnumerable<string> ShowCaseMediaUrls { get; set; }

    public ProductSocialMediaKit SocialMediaKits { get; set; }

    public ProductIncommDetail ProductIncommDetails { get; set; }

    public BrandProductUrl ProductUrls { get; set; }

    [JsonIgnore]
    public string ProductUrl { get; set; }

    [JsonIgnore]
    public SystemProductUrlOption ProductUrlTypeId { get; set; }

    public SystemProductStatusOption ProductStatus { get; set; }

    public string Hashtags { get; set; }

    public virtual DateTime? ListedOnUtc { get; set; }

    public LookupItem Country { get; set; }

    public string CurrencyCode { get; set; }

    public string CurrencySymbol { get; set; }

    public string City { get; set; }

    public IEnumerable<LookupItem> Categories { get; set; }

    public void ConfigureMap(IMappingExpression<BrandProduct, BrandProductModel> mapping)
    {
        mapping.ForMember(x => x.Categories,
            o =>
                o.MapFrom(x => x.Categories.Select(y => new LookupItem(y.SystemCategoryId, y.Name))));

        mapping.ForMember(destination => destination.ProductStatus,
            map => map.MapFrom(source => source.ProductStatusId));

        mapping.ForMember(x => x.Country,
            map => map.MapFrom(src =>
                new LookupItem(src.Country.SystemCountryId, src.Country.Name)));

        mapping.ForMember(x => x.CurrencyCode,
            map => map.MapFrom(src => src.Country.CurrencyCode));

        mapping.ForMember(x => x.CurrencySymbol,
            map => map.MapFrom(src => src.Country.CurrencySymbol));

        mapping.ForMember(x => x.ProductIncommDetails,
            map => map.MapFrom(src => src.ProductIncommDetails));
    }

    public void SignTheUrls(IStorageService storageService)
    {
        BannerImageUrl = storageService.GetSignedUrl(BannerImageUrl);
        ShowCaseMediaUrls = ShowCaseMediaUrls.Select(x => storageService.GetSignedUrl(x));
        SocialMediaKits.FacebookMediaKitUrl = storageService.GetSignedUrl(SocialMediaKits.FacebookMediaKitUrl);
        SocialMediaKits.InstagramMediaUrl = storageService.GetSignedUrl(SocialMediaKits.InstagramMediaUrl);
        SocialMediaKits.TwitterMediaKitUrl = storageService.GetSignedUrl(SocialMediaKits.TwitterMediaKitUrl);
        SocialMediaKits.TikTokMediaKitUrl = storageService.GetSignedUrl(SocialMediaKits.TikTokMediaKitUrl);

        if (ProductIncommDetails is not null)
        {
            foreach (var variantDetail in ProductIncommDetails.VariantDetails)
            {
                if (variantDetail is not null)
                {
                    variantDetail.ProductImageUrls = variantDetail.ProductImageUrls.Select(y => storageService.GetSignedUrl(y)).ToList();
                }
            }
        }
    }

    public void SetProductUrls()
    {
        if (ProductUrlTypeId == SystemProductUrlOption.Company)
        {
            ProductUrls.CompanyProductUrl = ProductUrl;
        }
        else
        {
            ProductUrls.EcommercePlatformUrl = ProductUrl;
        }
    }
}
