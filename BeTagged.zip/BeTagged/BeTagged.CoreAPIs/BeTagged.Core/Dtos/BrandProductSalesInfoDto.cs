﻿using System;

namespace BeTagged.Core.Dtos;

public class BrandProductSalesInfoDto
{
    public int BrandProductId { get; set; }

    public string ProductName { get; set; }

    public decimal Price { get; set; }

    public int Sales { get; set; }

    public decimal SalesValue { get; set; }

    public decimal Commission { get; set; }

    public IEnumerable<string> ShowCaseMediaUrls { get; set; }

    public string CurrencyCode { get; set; }

    public string CurrencySymbol { get; set; }

    public DateTime? SalesDataLastUploadedAtUtc { get; set; }

    public SystemProductUrlOption ProductListedOn { get; set; }
}
