﻿namespace BeTagged.Core.Utils;

public static class PhoneUtil
{
    public static bool IsValidPhone(string countryCode, string phoneNumber)
    {
        var phoneUtil = PhoneNumbers.PhoneNumberUtil.GetInstance();
        var nationalizedCountryCode = AppendPlusToCountryCode(countryCode);

        try
        {
            var phone = phoneUtil.Parse(nationalizedCountryCode + phoneNumber, null);
            return phoneUtil.IsValidNumber(phone);
        }
        catch
        {
            return false;
        }
    }

    public static (string CountryCode, string PhoneNumber) ParsePhone(string countryCode, string phoneNumber)
    {
        var phoneUtil = PhoneNumbers.PhoneNumberUtil.GetInstance();
        var nationalizedCountryCode = AppendPlusToCountryCode(countryCode);
        var phone = phoneUtil.Parse(nationalizedCountryCode + phoneNumber, null);
        return ($"+{phone.CountryCode}", phone.NationalNumber.ToString());
    }

    private static string AppendPlusToCountryCode(string countryCode)
    {
        var code = countryCode.Trim();
        return code.StartsWith('+') ? countryCode : $"+{code}";
    }
}
