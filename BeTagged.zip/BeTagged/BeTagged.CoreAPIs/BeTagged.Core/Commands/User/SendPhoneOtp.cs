﻿using System.Threading;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Otp;
using BeTagged.Core.Services.Security;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Commands.User;

public static class SendPhoneOtp
{
    public record Command(int PhoneId) : IRequest<Response>;

    public class Validator : AbstractValidator<Command>
    {
        public Validator() => RuleFor(x => x.PhoneId).GreaterThan(0);
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IBtDb _db;
        private readonly ICurrentUser _currentUser;
        private readonly IPhoneOtpService _phoneOtpService;

        public Handler(IBtDb db, ICurrentUser currentUser, IPhoneOtpService phoneOtpService)
        {
            _db = db;
            _currentUser = currentUser;
            _phoneOtpService = phoneOtpService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var response = new Response();

            var phone = await _db.Phones.Where(x => x.PhoneId == request.PhoneId)
                 .Where(x => x.UserId == null || x.UserId == _currentUser.UserId)
                 .SingleOrDefaultAsync(cancellationToken);

            if (phone is null)
            {
                response.Error = ErrorType.ValidationError;
                response.ErrorMessage = ValidationMessages.PhoneDoesNotExists;
                return response;
            }

            await _phoneOtpService.GenerateAndSendPhoneOtpAsync(phone, SystemOtpUsageTypeOption.Verification);
            return response;
        }
    }

    public class Response : Result
    {
    }
}
