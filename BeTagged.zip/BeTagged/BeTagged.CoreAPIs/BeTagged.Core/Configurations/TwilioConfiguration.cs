﻿namespace BeTagged.Core.Configurations;

public class TwilioConfiguration
{
    public const string Section = "Twilio";

    public string AccountSid { get; set; }

    public string AuthToken { get; set; }
}
