﻿using System;
using BeTagged.Core.Utils;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetPhoneSpecForUserType : ISingleResultQuerySpecification<Phone, Phone>
{
    public GetPhoneSpecForUserType(string countryCode, string phoneNumber, SystemUserTypeOption userType)
    {
        var (parsedCountryCode, parsedPhoneNumber) = PhoneUtil.ParsePhone(countryCode, phoneNumber);

        Query = queryable => queryable
            .Include(x => x.User)
            .Where(x => x.CountryCode == parsedCountryCode)
            .Where(x => x.PhoneNumber == parsedPhoneNumber)
            .Where(x => x.IsPrimary)
            .Where(x => x.User.UserType == userType);
    }

    public Func<IQueryable<Phone>, IQueryable<Phone>> Query { get; }
}
