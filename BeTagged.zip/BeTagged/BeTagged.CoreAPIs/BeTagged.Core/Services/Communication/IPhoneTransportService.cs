﻿namespace BeTagged.Core.Services.Communication;

internal interface IPhoneTransportService
{
    Task SendTextAsync(string phoneNumber, string text);
}
