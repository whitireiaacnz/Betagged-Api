﻿using System;
using BeTagged.Data.Specifications;

namespace BeTagged.Core.Specifications.Queries;

public class GetPromotionRequestByIdSpec : ISingleResultQuerySpecification<ProductPromotionRequest, ProductPromotionRequest>
{
    public GetPromotionRequestByIdSpec(int id)
    {
        Query = queryable => queryable
            .Where(x => x.ProductPromotionRequestId == id);
    }

    public Func<IQueryable<ProductPromotionRequest>, IQueryable<ProductPromotionRequest>> Query { get; }
}
