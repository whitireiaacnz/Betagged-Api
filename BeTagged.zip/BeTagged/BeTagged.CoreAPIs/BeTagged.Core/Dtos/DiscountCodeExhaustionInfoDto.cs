﻿namespace BeTagged.Core.Dtos;

public class DiscountCodeExhaustionInfoDto
{
    public int TotalDiscountCodeCount { get; set; }

    public int ExhaustedDiscountCodeCount { get; set; }

    public BrandProduct BrandProduct { get; set; }

    public decimal ExhaustionPercentage => ((decimal)ExhaustedDiscountCodeCount / TotalDiscountCodeCount) * 100;
}
