﻿namespace BeTagged.Core.Models;

public record LookupItem(int Id, string Name);
