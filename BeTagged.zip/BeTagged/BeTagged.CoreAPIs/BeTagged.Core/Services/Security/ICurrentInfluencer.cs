﻿namespace BeTagged.Core.Services.Security;

public interface ICurrentInfluencer : ICurrentUser
{
    int InfluencerId { get; }
}
