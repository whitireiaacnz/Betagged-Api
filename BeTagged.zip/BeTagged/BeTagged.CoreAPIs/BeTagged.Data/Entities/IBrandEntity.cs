﻿namespace BeTagged.Data.Entities;

public interface IBrandEntity
{
    public int BrandOrganizationId { get; set; }

    public BrandOrganization BrandOrganization { get; set; }
}
