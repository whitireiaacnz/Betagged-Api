﻿using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Attributes;

public class PercentageColumnAttribute : ColumnAttribute
{
    public PercentageColumnAttribute()
    {
        TypeName = "decimal(5, 2)";
    }
}
