﻿namespace BeTagged.Core.Dtos;

public class ActOnProductPromotionRequestDto
{
    public int ProductPromotionRequestId { get; set; }

    public int? ActedByBrandMemberId { get; set; }

    public int BrandProductId { get; set; }

    public int BrandOrganizationId { get; set; }

    public SystemApprovalStatusOption ApprovalStatus { get; set; }

    public bool? IsPeriodExpired { get; set; }
}
