﻿using System;
using System.Threading;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Storage;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;
using BeTagged.Data.Services;

namespace BeTagged.Core.Queries;

public static class GetBrandDashboardInsights
{
    public class Query : IRequest<Response>
    {
        public DateTime? From { get; set; }

        public DateTime? To { get; set; }

        public byte CountryId { get; set; }
    }

    public class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.From).LessThan(x => x.To).When(x => x.From is not null);
            RuleFor(x => x.CountryId).GreaterThan((byte)0);
        }
    }

    public class Handler : IRequestHandler<Query, Response>
    {
        private const int TopInfluencerCount = 4;
        private readonly IReadOnlyRepository<SystemCountry> _countriesRepository;
        private readonly IQueryService _queryService;
        private readonly ICurrentBrandMember _currentBrandMember;
        private readonly IStorageService _storageService;

        public Handler(ICurrentBrandMember currentBrandMember, IReadOnlyRepository<SystemCountry> countriesRepository,
            IQueryService queryService, IStorageService storageService)
        {
            _currentBrandMember = currentBrandMember;
            _countriesRepository = countriesRepository;
            _queryService = queryService;
            _storageService = storageService;
        }

        public async Task<Response> Handle(Query request, CancellationToken cancellationToken)
        {
            var getCountrySpec = new GetCountrySpec(request.CountryId);
            var country = await _countriesRepository.SingleOrDefaultAsync(getCountrySpec, cancellationToken);

            var response = new Response();

            if (country is null)
            {
                response.Error = ErrorType.ValidationError;
                response.ErrorMessage = ValidationMessages.CountryDoesNotExists;
                return response;
            }

            var parameters = new
            {
                @BrandOrganizationId = _currentBrandMember.BrandOrganizationId,
                @FromDate = request.From,
                @ToDate = request.To,
                @TopInfluenerCount = TopInfluencerCount,
                @CountryId = request.CountryId,
                @TopSellingProductCount = 5
            };

            var queryResult = await _queryService.QueryMultipleAsync(BtQueryType.GetBrandDashboardInsights,
                null, parameters);

            using (queryResult)
            {
                response = queryResult.ReadFirst<Response>();
                response.SocialMediaPerformance = new SocialMediaPerformanceModel()
                {
                    Facebook = queryResult.ReadFirst<SocialMediaPerformanceModel.MediaPlatformPerformance>(),
                    TikTok = queryResult.ReadFirst<SocialMediaPerformanceModel.MediaPlatformPerformance>(),
                    Instagram = queryResult.ReadFirst<SocialMediaPerformanceModel.MediaPlatformPerformance>(),
                    Twitter = queryResult.ReadFirst<SocialMediaPerformanceModel.MediaPlatformPerformance>()
                };
                response.Influencers = queryResult.Read<Influencer>();
                response.TopSellingProducts = queryResult.Read<ProductDetails>();
            }

            response.CurrencyCode = country.CurrencyCode;
            response.CurrencySymbol = country.CurrencySymbol;

            foreach (var product in response.TopSellingProducts)
            {
                product.ShowCaseMediaUrls = product.ShowCaseMediaUrls
                    .Select(x => _storageService.GetSignedUrl(x));
            }

            foreach (var influencer in response.Influencers)
            {
                influencer.ProfilePicUrl = _storageService.GetSignedUrl(influencer.ProfilePicUrl);
            }

            return response;
        }
    }

    public class Response : Result
    {
        public Response()
        {
            Influencers = Enumerable.Empty<Influencer>();
            TopSellingProducts = Enumerable.Empty<ProductDetails>();
        }

        public string CurrencyCode { get; set; }

        public string CurrencySymbol { get; set; }

        public int ProductListedTillDate { get; set; }

        public int SalesVolumeThisMonth { get; set; }

        public decimal SalesValueThisMonth { get; set; }

        public SocialMediaPerformanceModel SocialMediaPerformance { get; set; }

        public int TotalInfluencersInvolved { get; set; }

        public decimal CommissionToBePaidThisMonth { get; set; }

        public IEnumerable<Influencer> Influencers { get; set; }

        public IEnumerable<ProductDetails> TopSellingProducts { get; set; }
    }

    public class Influencer
    {
        public int InfluencerId { get; set; }

        public string ProfilePicUrl { get; set; }

        public string Name { get; set; }
    }
}
