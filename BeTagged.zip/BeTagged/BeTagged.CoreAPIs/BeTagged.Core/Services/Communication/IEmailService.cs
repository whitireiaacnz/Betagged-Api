﻿namespace BeTagged.Core.Services.Communication;

public interface IEmailService
{
    Task SendWelcomeEmailAsync(string emailAddress);

    Task SendOtpEmailAsync(string emailAddress, string otp);

    Task SendProductUnlistedEmailAsync(int brandOrganizationId, int brandProductId);

    Task SendBrandMembershipInvitationToNewUserAsync(string emailAddress, string invitationLink);

    Task SendBrandMembershipInvitationToExistingUserAsync(string emailAddress, string invitationLink);

    Task SendBradMemberRemovedFromBrandEmailAsync(string emailAddress, string brandName);
}
