﻿using System.Data;

namespace BeTagged.Core.Services.Misc;

public interface IExcelDataReaderService
{
    /// <summary>
    /// Returns the header of the excel file.
    /// </summary>
    /// <param name="path">directory file path or url of the the excel file</param>
    /// <returns></returns>
    Task<DataSet> GetHeaderDataSetAsync(string path);

    Task<DataSet> GetExcelDataSetAsync(string path);
}
