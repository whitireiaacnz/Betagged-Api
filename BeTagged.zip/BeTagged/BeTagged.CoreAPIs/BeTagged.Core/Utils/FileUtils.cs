﻿using System;
using System.IO;
using BeTagged.Common.Extensions;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Utils;

public static class FileUtils
{
    public static bool IsUserAuthorizedToUploadFile(FileCategory category, ICurrentUser user)
    {
        switch (category)
        {
            case FileCategory.BrandProduct:
            case FileCategory.Brand:
                return user.UserType == SystemUserTypeOption.BrandMember;
            case FileCategory.Misc:
            case FileCategory.User:
                return true;
            default:
                throw new ArgumentOutOfRangeException(nameof(category), category, null);
        }
    }

    public static string GetUploadDirectory(FileCategory category)
    {
        switch (category)
        {
            case FileCategory.BrandProduct:
                return "brand/brandProudcts/";
            case FileCategory.Misc:
                return "mics/";
            case FileCategory.User:
                return "user/";
            case FileCategory.Brand:
                return "brand/";
            default:
                throw new ArgumentOutOfRangeException(nameof(category), category, null);
        }
    }

    /// <param name="file">path or url for the file</param>
    /// <returns>Absolute file path eg. /Brand/BrandProducts/xyz.jpg</returns>
    public static string GetFileAbsolutePath(string file)
    {
        if (file.IsNullOrEmpty()) { return null; }

        var fileName = file;

        if (file.IsUri())
        {
            fileName = new Uri(fileName).LocalPath.TrimStart('/');
        }

        return fileName;
    }

    /// <param name="file">path or url for the file</param>
    /// <returns>Extensions of the file eg. .zip</returns>
    public static string GetFileExtension(string file)
    {
        var absoluteFilePath = GetFileAbsolutePath(file);
        return Path.GetExtension(absoluteFilePath);
    }
}
