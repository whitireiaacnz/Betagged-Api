﻿using System;
using BeTagged.Data.Specifications;

namespace BeTagged.Core.Specifications.Queries;

public class GetCountrySpec : ISingleResultQuerySpecification<SystemCountry, SystemCountry>
{
    public GetCountrySpec(byte countryId)
    {
        Query = queryable => queryable.Where(x => x.SystemCountryId == countryId);
    }

    public Func<IQueryable<SystemCountry>, IQueryable<SystemCountry>> Query { get; }
}
