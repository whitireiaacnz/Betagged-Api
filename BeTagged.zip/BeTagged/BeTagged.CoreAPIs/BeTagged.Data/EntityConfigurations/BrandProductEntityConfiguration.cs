﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

internal class BrandProductEntityConfiguration : IEntityTypeConfiguration<BrandProduct>
{
    public void Configure(EntityTypeBuilder<BrandProduct> builder)
    {
        builder.HasKey(x => x.BrandProductId);

        builder.Property(x => x.BrandProductId)
            .UseIdentityAlwaysColumn();

        builder.HasOne(x => x.ProductStatus)
            .WithMany(x => x.BrandProducts)
            .HasForeignKey(x => x.ProductStatusId);

        builder.HasOne(x => x.BrandOrganization)
            .WithMany(x => x.BrandProducts)
            .HasForeignKey(x => x.BrandOrganizationId);

        builder.HasOne(x => x.ProductUrlType)
            .WithMany(x => x.BrandProducts)
            .HasForeignKey(x => x.ProductUrlTypeId);

        builder.HasMany(x => x.Categories)
            .WithMany(x => x.BrandProducts)
            .UsingEntity<Dictionary<string, object>>("brand_product_categories",
                j => j.HasOne<SystemCategory>().WithMany().HasForeignKey("system_category_id"),
                j => j.HasOne<BrandProduct>().WithMany().HasForeignKey("brand_product_id"));

        builder.HasOne(x => x.CreatedByUser)
            .WithMany()
            .HasForeignKey(x => x.CreatedByUserId);

        builder.HasOne(x => x.ModifiedByUser)
            .WithMany()
            .HasForeignKey(x => x.ModifiedByUserId);

        builder.Property(x => x.BrandProductKey)
            .HasColumnType("uuid")
            .HasDefaultValueSql("uuid_generate_v4()");

        builder.HasIndex(x => x.BrandProductKey).IsUnique();
    }
}
