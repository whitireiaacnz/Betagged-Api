﻿namespace BeTagged.Data.Enums;

[EnumLookupTable(typeof(SystemProductUrlType))]
public enum SystemProductUrlOption : byte
{
    Company = 1,
    EcommercePlatform = 2,
    InCommMall = 3
}
