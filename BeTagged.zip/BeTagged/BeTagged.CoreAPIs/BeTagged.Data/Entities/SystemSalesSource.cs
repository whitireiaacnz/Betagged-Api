﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Entities;

[Table("system_sales_sources_lut")]
public class SystemSalesSource
{
    public SystemSalesSource()
    {
        ProductSales = new List<ProductSale>();
    }

    public SystemSalesSourceOption SystemSalesSourceId { get; set; }

    [Required]
    public string Name { get; set; }

    public ICollection<ProductSale> ProductSales { get; set; }
}
