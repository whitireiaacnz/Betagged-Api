﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

internal class InfluencerBankAccountEntityConfiguration : IEntityTypeConfiguration<InfluencerBankAccount>
{
    public void Configure(EntityTypeBuilder<InfluencerBankAccount> builder)
    {
        builder.HasKey(x => x.InfluencerBankAccountId);

        builder.Property(x => x.InfluencerBankAccountId)
            .UseIdentityAlwaysColumn();

        builder.Property(x => x.SwiftCode).HasMaxLength(30);

        builder.Property(x => x.AccountNumber).HasMaxLength(45);

        builder.HasOne(x => x.Country)
            .WithMany(x => x.InfluencerBankAccounts)
            .HasForeignKey(x => x.CountryId);

        builder.HasOne(x => x.Influencer)
            .WithMany(x => x.InfluencerBankAccounts)
            .HasForeignKey(x => x.InfluencerId);
    }
}
