﻿using System;
using System.IO;
using BeTagged.Core.Enums;

namespace BeTagged.Core.Dtos;

public record FileUploadDto
{
    public FileUploadDto()
    {
        Expiry = DateTime.UtcNow.AddMinutes(5);
    }

    public Stream Stream { get; set; }

    public string ContentType { get; set; }

    public string FileName { get; set; }

    public FileCategory? Category { get; set; }

    public DateTime Expiry { get; set; }
}
