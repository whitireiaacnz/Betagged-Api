﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class PluralCurrentCodeTable : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropForeignKey(
            name: "fk_brand_products_system_currency_code_lut_currency_code_id",
            schema: "public",
            table: "brand_products");

        migrationBuilder.DropPrimaryKey(
            name: "pk_system_currency_code_lut",
            schema: "public",
            table: "system_currency_code_lut");

        migrationBuilder.RenameTable(
            name: "system_currency_code_lut",
            schema: "public",
            newName: "system_currency_codes_lut",
            newSchema: "public");

        migrationBuilder.AddPrimaryKey(
            name: "pk_system_currency_codes_lut",
            schema: "public",
            table: "system_currency_codes_lut",
            column: "system_currency_code_id");

        migrationBuilder.AddForeignKey(
            name: "fk_brand_products_system_currency_codes_lut_currency_code_id",
            schema: "public",
            table: "brand_products",
            column: "currency_code_id",
            principalSchema: "public",
            principalTable: "system_currency_codes_lut",
            principalColumn: "system_currency_code_id",
            onDelete: ReferentialAction.Restrict);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropForeignKey(
            name: "fk_brand_products_system_currency_codes_lut_currency_code_id",
            schema: "public",
            table: "brand_products");

        migrationBuilder.DropPrimaryKey(
            name: "pk_system_currency_codes_lut",
            schema: "public",
            table: "system_currency_codes_lut");

        migrationBuilder.RenameTable(
            name: "system_currency_codes_lut",
            schema: "public",
            newName: "system_currency_code_lut",
            newSchema: "public");

        migrationBuilder.AddPrimaryKey(
            name: "pk_system_currency_code_lut",
            schema: "public",
            table: "system_currency_code_lut",
            column: "system_currency_code_id");

        migrationBuilder.AddForeignKey(
            name: "fk_brand_products_system_currency_code_lut_currency_code_id",
            schema: "public",
            table: "brand_products",
            column: "currency_code_id",
            principalSchema: "public",
            principalTable: "system_currency_code_lut",
            principalColumn: "system_currency_code_id",
            onDelete: ReferentialAction.Restrict);
    }
}
