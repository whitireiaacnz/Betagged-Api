﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Entities;

[Table("system_shortened_link_entity_types_lut")]
public class SystemShortenedLinkEntityType
{
    public SystemShortenedLinkEntityType()
    {
        ShortenedLinks = new List<ShortenedLink>();
    }

    public SystemShortenedLinkEntityTypeOption SystemShortenedLinkEntityTypeId { get; set; }

    [MaxLength(32)]
    public string Name { get; set; }

    // Reverse navigation
    public ICollection<ShortenedLink> ShortenedLinks { get; set; }
}
