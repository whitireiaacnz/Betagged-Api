﻿using BeTagged.Common.Extensions;

namespace BeTagged.Core.Validators;

public class ProductVariantValidator : AbstractValidator<VariantDetail>
{
    public ProductVariantValidator()
    {
        RuleForEach(x => x.ProductImageUrls).NotEmpty().NotNull()
        .Must(x => x.IsUri())
         .WithMessage(ValidationMessages.LinkMustBeValidUri);
    }
}
