﻿using System;
using Microsoft.EntityFrameworkCore.Storage;
using Npgsql.EntityFrameworkCore.PostgreSQL;

namespace BeTagged.Data;

internal class BeTaggedSqlExecutionStrategy : NpgsqlRetryingExecutionStrategy
{
    private bool _isRetrySuspended;

    public BeTaggedSqlExecutionStrategy(ExecutionStrategyDependencies dependencies) : base(dependencies)
    {
    }

    public override bool RetriesOnFailure => DoWeNeedToRetry();

    public void SuspendRetryStrategy() => _isRetrySuspended = true;

    public void EnableRetryStrategy() => _isRetrySuspended = false;

    protected override bool ShouldRetryOn(Exception exception)
    {
        return !_isRetrySuspended && base.ShouldRetryOn(exception);
    }

    private bool DoWeNeedToRetry()
    {
        return !_isRetrySuspended && base.RetriesOnFailure;
    }
}
