﻿using System;
using BeTagged.Core.Configurations;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.BackgroundWork;
using BeTagged.Core.Services.CDP;
using BeTagged.Core.Services.Communication;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Core.Utils;
using BeTagged.Data.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Z.EntityFramework.Plus;

namespace BeTagged.Core.Services.Otp;

internal class EmailOtpService : IEmailOtpService
{
    private readonly IBtDb _db;
    private readonly SecurityConfiguration _securityConfiguration;
    private readonly IEmailService _emailService;
    private readonly AppConfiguration _appConfiguration;
    private readonly EmailConfiguration _emailConfiguration;
    private readonly IBackgroundWorker _backgroundWorker;
    private readonly IReadOnlyRepository<User> _usersRepo;

    public EmailOtpService(IBtDb db, IOptions<SecurityConfiguration> securityConfiguration,
         IEmailService emailService, AppConfiguration appConfiguration, IOptions<EmailConfiguration> emailConfiguration,
         IBackgroundWorker backgroundWorker, IReadOnlyRepository<User> usersRepo)
    {
        _db = db;
        _securityConfiguration = securityConfiguration.Value;
        _emailService = emailService;
        _appConfiguration = appConfiguration;
        _backgroundWorker = backgroundWorker;
        _usersRepo = usersRepo;
        _emailConfiguration = emailConfiguration.Value;
    }

    public async Task GenerateAndSendEmailOtpAsync(EmailAddress emailAddress, SystemOtpUsageTypeOption otpUsageType)
    {
        var otp = await GenerateOtpForEmailAsync(emailAddress, otpUsageType);

        if (IsOtpEnabled())
        {
            await _emailService.SendOtpEmailAsync(emailAddress.EmailAddress_, otp);
        }
    }

    public async Task<Result<bool>> VerifyEmailAsync(int userId, int emailAddressId, string otp,
        SystemOtpUsageTypeOption otpUsageType)
    {
        var result = new Result<bool>();

        var email = await _db.EmailAddresses
            .Where(x => (x.UserId == null || x.UserId == userId) && x.EmailAddressId == emailAddressId)
            .SingleOrDefaultAsync();

        if (email is null)
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = ValidationMessages.EmailDoesNotExists;
            return result;
        }

        var otpEntity = await _db.EmailOtps
            .Where(x => x.EntityId == emailAddressId)
            .Where(x => x.Value == otp)
            .Where(x => x.ValidTillUtc >= DateTime.UtcNow)
            .Where(x => x.UsageTypeId == otpUsageType)
            .FirstOrDefaultAsync();

        if (otpEntity is null)
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = "Invalid Email OTP.";
            return result;
        }

        email.IsVerified = true;
        otpEntity.IsDeleted = true;
        email.UserId = userId;

        await _db.SaveChangesAsync();

        var getUserKeySpec = new GetUserKeySpecification(userId);
        var userKey = await _usersRepo.SingleOrDefaultAsync(getUserKeySpec);

        _backgroundWorker.Enqueue<ICdpService>(x =>
            x.UpdateUserEmailAsync(userKey, email.EmailAddress_));

        return result;
    }

    private async Task<string> GenerateOtpForEmailAsync(EmailAddress emailAddress, SystemOtpUsageTypeOption otpUsageType)
    {
        string otp;

        if (IsOtpEnabled())
        {
            otp = OtpUtil.GenerateRandomOTP(PhoneConstants.OtpLength, PhoneConstants.AllowedOtpChar);
        }
        else
        {
            otp = EmailConstants.DummyOtp;
        }

        var emailOtps = new EmailOtp()
        {
            EntityId = emailAddress.EmailAddressId,
            Value = otp,
            ValidTillUtc = DateTime.UtcNow.AddMinutes(_securityConfiguration.OtpValidityInMinutes),
            UsageTypeId = otpUsageType
        };

        await _db.EmailOtps.Where(x => x.EntityId == emailAddress.EmailAddressId && !x.IsDeleted)
            .Where(x => x.UsageTypeId == otpUsageType)
            .UpdateAsync(_ => new EmailOtp() { IsDeleted = true });

        _db.EmailOtps.Add(emailOtps);

        await _db.SaveChangesAsync();

        return otp;
    }

    private bool IsOtpEnabled()
    {
        return _appConfiguration.Environment == AppEnvironment.Production ||
              _emailConfiguration.EmailMode == EmailMode.Live;
    }
}
