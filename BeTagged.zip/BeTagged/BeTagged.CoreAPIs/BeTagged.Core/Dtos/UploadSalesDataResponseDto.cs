﻿using System;

namespace BeTagged.Core.Dtos;

public class UploadSalesDataResponseDto
{
    // Then name should ideally be 'Message' but need to keep it 'Data' for backward compatability.
    public string Data { get; set; }

    public DateTime SalesDataLastUploadedAtUtc { get; set; }
}
