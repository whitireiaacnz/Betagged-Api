﻿using Newtonsoft.Json;

namespace BeTagged.Core.Dtos;

public class UpdateBrandProductDto
{
    public UpdateBrandProductDto()
    {
        SocialMediaKits = new();
        ShowCaseMediaUrls = Enumerable.Empty<string>();
        Categories = Enumerable.Empty<int>();
    }

    [JsonIgnore]
    public int BrandProductId { get; set; }

    public IEnumerable<int> Categories { get; set; }

    public string Name { get; set; }

    public string Hashtags { get; set; }

    public string Description { get; set; }

    public string BannerImageUrl { get; set; }

    public IEnumerable<string> ShowCaseMediaUrls { get; set; }

    public ProductSocialMediaKit SocialMediaKits { get; set; }

    public bool IsApprovalBasedOffer { get; set; }
}
