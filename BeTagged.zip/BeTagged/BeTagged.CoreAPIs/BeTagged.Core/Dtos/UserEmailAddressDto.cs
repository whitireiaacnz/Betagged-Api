﻿namespace BeTagged.Core.Dtos;

public class UserEmailAddressDto
{
    public int Id { get; set; }

    public string EmailAddress { get; set; }

    public bool IsPrimary { get; set; }
}
