﻿using System;
using System.Threading;
using BeTagged.Core.Dtos;
using BeTagged.Core.Extensions;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetBrandInsightsInfluencersInfoSpec : IListResultQuerySpecification<ProductSale, BrandInsightsInfluencerInfoDto>
{
    public GetBrandInsightsInfluencersInfoSpec(int countryId, int brandOrganizationId, DateTime? from, DateTime? to, int skip, int take, string orderBy)
    {
        Query = async (queryable, ct) => await queryable
                .Include(x => x.BrandProduct)
                .ThenInclude(c => c.Country)
                .Include(x => x.Influencer)
                .ThenInclude(x => x.User)
                .Where(x => x.BrandProduct.CountryId == countryId && x.BrandOrganizationId == brandOrganizationId)
                .Where(y => from == null || (y.SoldAtUtc >= from && y.SoldAtUtc <= to))
                .GroupBy(x => x.InfluencerId)
                .Select(x => new BrandInsightsInfluencerInfoDto()
                {
                    InfluencerProfilePicUrl = x.First().Influencer.User.ProfilePicPath,
                    InfluencerName = x.First().Influencer.User.Name,
                    Sales = x.Sum(y => y.Quantity),
                    Commission = x.Sum(y => y.InfluencerPayableCommission),
                    ProductsSold = x.Select(x => new BrandProductInfo
                    {
                        BrandProductId = x.BrandProductId,
                        BrandProductName = x.BrandProduct.Name
                    }).Distinct(),
                    CurrencyCode = x.First().BrandProduct.Country.CurrencyCode,
                    CurrencySymbol = x.First().BrandProduct.Country.CurrencySymbol
                })
                .Where(x => x.Sales > 0)
                .OrderByDynamic(orderBy, null)
                .Skip(skip)
                .Take(take + 1)
                .ToListAsync(ct);
    }

    public Func<IQueryable<ProductSale>, CancellationToken, Task<IList<BrandInsightsInfluencerInfoDto>>> Query { get; }
}
