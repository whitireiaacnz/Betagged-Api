﻿using System;
using BeTagged.Core.Dtos;

namespace BeTagged.Core.Services.Shopify;

public interface IShopifyService
{
    Task<(long Id, string Url)> CreateProductAsync(AddBrandProductDto dto, Guid brandProductKey);

    Task UpdateProductAsync(BrandProduct product);

    Task<string> GetShopDomain();

    Task SaveWebhookMappingDetails(string cartToken, string productionPromotionKey);

    Task<WebhookMappingDetail> GetWebhookMappingDetail(string checkoutId);

    Task SubscribeToWebhooksAsync();

    Task ShopifyWebhookEventHandler(string topic, dynamic payload);
}
