﻿using System;
using System.Threading;
using BeTagged.Core.Services.Security;
using Z.EntityFramework.Plus;

namespace BeTagged.Core.Commands.User;

public static class ReadAllUserNotifications
{
    public record Command() : IRequest<Response>;

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IBtDb _db;
        private readonly ICurrentUser _currentUser;

        public Handler(ICurrentUser currentUser, IBtDb db)
        {
            _currentUser = currentUser;
            _db = db;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            await _db.InAppNotifications
                .Where(x => x.UserId == _currentUser.UserId)
                .Where(x => !x.HasReadByUser)
                .UpdateAsync(x => new InAppNotification()
                {
                    HasReadByUser = true,
                    ReadAtUtc = DateTime.UtcNow
                });

            return new Response();
        }
    }

    public class Response
    {
    }
}
