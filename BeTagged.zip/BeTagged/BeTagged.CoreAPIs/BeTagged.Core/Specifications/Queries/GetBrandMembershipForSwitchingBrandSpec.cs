﻿using System;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetBrandMembershipForSwitchingBrandSpec : ISingleResultQuerySpecification<BrandMembership, BrandMembership>
{
    public GetBrandMembershipForSwitchingBrandSpec(int brandMemberId, int brandOrganizationId)
    {
        Query = q => q
            .Include(x => x.BrandMember.User)
            .ThenInclude(x => x.EmailAddresses.Where(y => y.IsPrimary))
            .Include(x => x.BrandMember.User)
            .ThenInclude(x => x.Phones.Where(y => y.IsPrimary))
            .Include(x => x.BrandOrganization)
            .Where(x => x.BrandMemberId == brandMemberId)
            .Where(x => x.BrandOrganizationId == brandOrganizationId)
            .Where(x => !x.IsDisabled);
    }

    public Func<IQueryable<BrandMembership>, IQueryable<BrandMembership>> Query { get; }
}
