﻿namespace BeTagged.Core.Services.Security;

public interface IAuthTokenService
{
    string GetTokenForInfluencer(Influencer influencer);

    string GetTokenForBrandMember(BrandMember brandMember, BrandMembership brandMembership);
}
