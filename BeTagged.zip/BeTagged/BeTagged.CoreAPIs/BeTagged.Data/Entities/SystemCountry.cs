﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Entities;

[Table("system_countries_lut")]
public class SystemCountry
{
    public SystemCountry()
    {
        BrandProducts = new List<BrandProduct>();
        Influencers = new List<Influencer>();
        InfluencerBankAccounts = new List<InfluencerBankAccount>();
    }

    public byte SystemCountryId { get; set; }

    [MaxLength(64)]
    public string Name { get; set; }

    [MaxLength(2)]
    public string IsoCode { get; set; }

    [MaxLength(3)]
    public string Iso3Code { get; set; }

    [MaxLength(7)]
    public string IsdCode { get; set; }

    public string CurrencyCode { get; set; }

    public string CurrencySymbol { get; set; }

    // Reverse navigation
    public ICollection<BrandProduct> BrandProducts { get; set; }

    public ICollection<Influencer> Influencers { get; set; }

    public ICollection<InfluencerBankAccount> InfluencerBankAccounts { get; set; }
}
