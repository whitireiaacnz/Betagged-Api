﻿using System.Threading;
using BeTagged.Common.Utils;
using BeTagged.Core.Queries.Shared;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.SocialMedia;
using BeTagged.Core.Services.Storage;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Queries.ProductPromotion;

public static class GetInfluencersSeekingApproval
{
    public class Query : ODataQueryBase, IRequest<PaginatedList<InfluencerSeekingApprovalModel>>
    {
        public int BrandProductId { get; set; }
    }

    public class Handler : IRequestHandler<Query, PaginatedList<InfluencerSeekingApprovalModel>>
    {
        private readonly IReadOnlyBtDb _db;
        private readonly ICurrentBrandMember _currentBrandMember;
        private readonly IStorageService _storageService;
        private readonly ISocialMediaService _socialMediaService;

        public Handler(IReadOnlyBtDb db, ICurrentBrandMember currentBrandMember, IStorageService storageService, ISocialMediaService socialMediaService)
        {
            _db = db;
            _currentBrandMember = currentBrandMember;
            _storageService = storageService;
            _socialMediaService = socialMediaService;
        }

        public async Task<PaginatedList<InfluencerSeekingApprovalModel>> Handle(Query request, CancellationToken cancellationToken)
        {
            var influencerIds = await _db.ProductPromotionRequests
                .Where(x => x.BrandProductId == request.BrandProductId
                            && x.BrandOrganizationId == _currentBrandMember.BrandOrganizationId)
                .Where(x => x.ApprovalStatusId == SystemApprovalStatusOption.Pending)
                .GroupBy(p => p.InfluencerId)
                .Select(x => x.First().InfluencerId)
                .Skip(request.Skip)
                .Take(request.Take + 1)
                .ToListAsync(cancellationToken);

            var influencerData = await _db.ProductPromotionRequests
                .Include(x => x.Influencer)
                .ThenInclude(x => x.User)
                .Where(x => x.BrandProductId == request.BrandProductId
                            && influencerIds.Contains(x.InfluencerId))
                .ToListAsync(cancellationToken);

            var groupedData = influencerData.GroupBy(p => p.InfluencerId).ToList();

            List<InfluencerSeekingApprovalModel> influencersSeekingApproval = new();

            if (groupedData.Any())
            {
                foreach (var group in groupedData)
                {
                    List<ProductPromotionRequest> promotionRequestList = group.ToList();

                    List<ApprovalRequest> pendingRequestList = new List<ApprovalRequest>();

                    foreach (var t in promotionRequestList)
                    {
                        pendingRequestList.Add(new()
                        {
                            PromotionRequestId = t.ProductPromotionRequestId,
                            SalesChannel = t.SalesChannelId,
                            Followers = ThreadSafeRandom.Next(0, 10000),
                            ApprovalStatus = t.ApprovalStatusId,
                            ActedOnUtc = t.ActedAtUtc,
                            IsRejectedDueToPeriodExpiration = t.IsRejectedDueToPeriodExpiration,
                            SocialMediaHandleUrl = _socialMediaService.GetSalesChannelLink(t.SalesChannelId,
                            promotionRequestList[0].Influencer.SocialMediaAccounts)
                        });
                    }

                    var influencer = promotionRequestList[0].Influencer;

                    influencersSeekingApproval.Add(new InfluencerSeekingApprovalModel()
                    {
                        InfluencerId = influencer.InfluencerId,
                        InfluencerName = influencer.User.Name,
                        ProfilePicUrl = _storageService.GetSignedUrl(influencer.User.ProfilePicPath),
                        RequestedOnUtc = promotionRequestList.Min(x => x.RequestedOnUtc),
                        Requests = pendingRequestList,
                    });
                }
            }

            return new PaginatedList<InfluencerSeekingApprovalModel>(influencersSeekingApproval, request.Skip, request.Take);
        }
    }
}
