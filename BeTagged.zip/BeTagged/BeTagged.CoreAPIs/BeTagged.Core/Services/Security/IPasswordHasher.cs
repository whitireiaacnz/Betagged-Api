﻿namespace BeTagged.Core.Services.Security;

public interface IPasswordHasher
{
    string GetHashedPassword(string password, string salt);
}
