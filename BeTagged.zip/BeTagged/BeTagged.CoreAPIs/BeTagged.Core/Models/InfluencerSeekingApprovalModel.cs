﻿using System;

namespace BeTagged.Core.Models;

public class InfluencerSeekingApprovalModel
{
    public InfluencerSeekingApprovalModel()
    {
        Requests = Enumerable.Empty<ApprovalRequest>();
    }

    public int InfluencerId { get; set; }

    public string InfluencerName { get; set; }

    public string ProfilePicUrl { get; set; }

    public int ProductsSold { get; set; }

    public DateTime RequestedOnUtc { get; set; }

    public IEnumerable<ApprovalRequest> Requests { get; set; }
}

public class ApprovalRequest
{
    public int PromotionRequestId { get; set; }

    public SystemSalesChannelOption SalesChannel { get; set; }

    public SystemApprovalStatusOption ApprovalStatus { get; set; }

    public DateTime? ActedOnUtc { get; set; }

    // TODO: read followers from DB
    public int Followers { get; set; }

    public bool? IsRejectedDueToPeriodExpiration { get; set; }

    public string SocialMediaHandleUrl { get; set; }
}
