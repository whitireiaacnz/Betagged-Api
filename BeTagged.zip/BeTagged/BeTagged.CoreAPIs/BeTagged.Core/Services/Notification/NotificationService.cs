﻿using System;
using BeTagged.Core.Services.BackgroundWork;
using BeTagged.Core.Services.CDP;
using BeTagged.Core.Services.UrlUtils;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Services.Notification;

internal class NotificationService : INotificationService
{
    private readonly IBackgroundWorker _backgroundWorker;
    private readonly IReadOnlyRepository<ProductPromotion> _productPromotionsReadRepo;
    private readonly IReadOnlyRepository<User> _usersReadOnlyRepository;
    private readonly IBtDb _db;
    private readonly IReadOnlyRepository<BrandProduct> _brandProductsReadOnlyRepo;
    private readonly IUrlBuilder _urlBuilder;
    private readonly IReadOnlyRepository<Influencer> _influencersReadonlyRepo;
    private readonly ICdpService _cdpService;

    public NotificationService(IBackgroundWorker backgroundWorker, IReadOnlyRepository<ProductPromotion> productPromotionsReadRepo,
        IReadOnlyRepository<User> usersReadOnlyRepository, IBtDb db, IReadOnlyRepository<BrandProduct> brandProductsReadOnlyRepo, IUrlBuilder urlBuilder,
        IReadOnlyRepository<Influencer> influencersReadonlyRepo, ICdpService cdpService)
    {
        _backgroundWorker = backgroundWorker;
        _productPromotionsReadRepo = productPromotionsReadRepo;
        _usersReadOnlyRepository = usersReadOnlyRepository;
        _db = db;
        _brandProductsReadOnlyRepo = brandProductsReadOnlyRepo;
        _urlBuilder = urlBuilder;
        _influencersReadonlyRepo = influencersReadonlyRepo;
        _cdpService = cdpService;
    }

    public void SendSignupCompletedNotification(Guid userKey)
    {
        _backgroundWorker.Schedule<ICdpService>(x =>
            x.AddHasCompletedSignupUserAttributeAsync(userKey), TimeSpan.FromSeconds(10));

        _backgroundWorker.Schedule<ICdpService>(x =>
            x.SendSignupCompletedEventAsync(userKey), TimeSpan.FromSeconds(10));
    }

    public void SendOnBoardingCompletedNotification(Guid userKey)
    {
        _backgroundWorker.Schedule<ICdpService>(x =>
            x.AddHasCompletedOnboardingUserAttributeAsync(userKey), TimeSpan.FromSeconds(10));

        _backgroundWorker.Schedule<ICdpService>(x =>
            x.SendOnboardingCompletedEventAsync(userKey), TimeSpan.FromSeconds(10));
    }

    public void SendProductListedNotification(Guid userKey, int brandProductId, string brandProductUrl,
        string productName)
    {
        _backgroundWorker.Enqueue<IInAppNotificationService>(x =>
            x.SendProductListedNotificationAsync(userKey, brandProductId, brandProductUrl, productName));
        _backgroundWorker.Enqueue<ICdpService>(x => x.AddHasListedAProductUserAttributeAsync(userKey));
        _backgroundWorker.Enqueue<ICdpService>(x => x.SendProductListedEventAsync(userKey, brandProductUrl, brandProductId, productName));
    }

    public void SendXPercentageCouponExhaustedNotification(IEnumerable<Guid> userKeys, int percentage,
        string brandProductUrl, int brandProductId, string productName)
    {
        _backgroundWorker.Enqueue<IInAppNotificationService>(x =>
            x.SendXPercentCouponExhaustedNotificationAsync(userKeys, brandProductId, brandProductUrl, productName, percentage));
        _backgroundWorker.Enqueue<ICdpService>(x =>
            x.SendXPercentageCouponExhaustedEventAsync(userKeys, percentage, brandProductUrl, brandProductId, productName));
    }

    public void SendSalesDataNeedsToBeUploadedNotification(Guid userKey, string brandProductUrl, int brandProductId,
        string productName)
    {
        _backgroundWorker.Enqueue<IInAppNotificationService>(x =>
            x.SendSalesDataNeedsTobeUploadedAsync(userKey, brandProductId, brandProductUrl, productName));

        _backgroundWorker.Enqueue<ICdpService>(x =>
            x.SendSalesDataNeedsToBeUploadedEventAsync(userKey, brandProductUrl, brandProductId, productName));
    }

    public Task SendProductSoldNotificationAsync(Guid userKey)
    {
        throw new NotImplementedException();
    }

    public void SendProductRequestApprovedNotification(Guid userKey, int productId, string productUrl, string productName)
    {
        _backgroundWorker.Enqueue<IInAppNotificationService>(x => x.SendProductRequestApprovedNotificationAsync(userKey,
            productId, productUrl, productName));

        _backgroundWorker.Enqueue<ICdpService>(x =>
            x.SendProductRequestApprovedEventAsync(userKey, productId, productUrl, productName));
    }

    public void SendProductRequestRejectedNotification(Guid userKey, int productId, string productUrl, string productName)
    {
        _backgroundWorker.Enqueue<IInAppNotificationService>(x => x.SendProductRequestRejectedNotificationAsync(userKey,
            productId, productUrl, productName));

        _backgroundWorker.Enqueue<ICdpService>(x =>
            x.SendProductRequestRejectedEventAsync(userKey, productId, productUrl, productName));
    }

    public async Task SendProductUnlistedNotificationAsync(int productId, string productUrl, string productName)
    {
        var getInfluencerKeysSpec = new GetInfluencerUserKeysPromotingTheProductSpec(productId);
        var influencerKeys = await _productPromotionsReadRepo.ListAsync(getInfluencerKeysSpec);

        _backgroundWorker.Enqueue<IInAppNotificationService>(x =>
            x.SendProductUnlistedNotificationAsync(influencerKeys, productId, productUrl, productName));
        _backgroundWorker.Enqueue<ICdpService>(x =>
            x.SendProductUnlistedEventAsync(influencerKeys, productId, productUrl, productName));
    }

    public async Task SendProductListingReminderNotificationAsync(int userId, int daysWithoutListingProduct)
    {
        var getUserKeySpec = new GetUserKeySpecification(userId);
        var userKey = await _usersReadOnlyRepository.SingleAsync(getUserKeySpec);

        _backgroundWorker.Enqueue<ICdpService>(x =>
            x.SendProductListingReminderEventAsync(userKey, daysWithoutListingProduct));

        _backgroundWorker.Enqueue<IInAppNotificationService>(x =>
            x.SendProductListingReminderNotificationAsync(userKey, daysWithoutListingProduct));
    }

    public async Task SendInfluencerSeekingApprovalNotificationAsync()
    {
        var productWithPendingRequests = await _db.ProductPromotionRequests
            .Include(x => x.BrandOrganization.BrandMemberships.Where(y => !y.IsDisabled))
            .ThenInclude(x => x.BrandMember.User)
            .Where(x => x.ApprovalStatusId == SystemApprovalStatusOption.Pending)
            .Where(x => !x.BrandProduct.IsDeleted && x.BrandProduct.ProductStatusId == SystemProductStatusOption.Listed)
            .GroupBy(x => x.BrandProductId)
            .Select(x => new
            {
                ProductId = x.Key,
                MembersKeys = x.SelectMany(x => x.BrandOrganization.BrandMemberships.Select(x => x.BrandMember.User.UserKey))
            })
            .ToDictionaryAsync(x => x.ProductId, x => x.MembersKeys);

        foreach (var productWithPendingRequest in productWithPendingRequests)
        {
            var getProductDetailsSpec = new GetBrandProductMinimalSpec(productWithPendingRequest.Key);
            var productDetails = await _brandProductsReadOnlyRepo.SingleAsync(getProductDetailsSpec);
            var productUrl = _urlBuilder.BuildProductDetailsUrl(productDetails.BrandProductId);

            var memberKeys = productWithPendingRequest.Value.ToList();
            var productId = productDetails.BrandProductId;
            var productName = productDetails.Name;

            _backgroundWorker.Enqueue<IInAppNotificationService>(x => x.SendInfluencerSeekingApprovalNotificationAsync(
                memberKeys, productId, productUrl, productName));

            _backgroundWorker.Enqueue<ICdpService>(x => x.SendInfluencerSeekingApprovalEventAsync(
                memberKeys, productId, productUrl, productName));
        }
    }

    public async Task SendReminderForPickingAProductToInfluencerAsync(int influencerId, int daysWithoutPickingAProduct)
    {
        var getInfluencerSpec = new GetInfluencerSpec(influencerId);
        var influencer = await _influencersReadonlyRepo.SingleAsync(getInfluencerSpec);

        _backgroundWorker.Enqueue<IInAppNotificationService>(x =>
            x.SendReminderForPickProductToInfluencerAsync(influencer.User.UserId, daysWithoutPickingAProduct));

        _backgroundWorker.Enqueue<ICdpService>(x =>
            x.SendReminderForPickingAProductToInfluencerAsync(influencer.User.UserKey, daysWithoutPickingAProduct));
    }

    public async Task SendCompleteSignupReminderNotificationAsync(Guid userKey)
    {
        await _cdpService.SendCompleteSignupReminderEventAsync(userKey);
    }

    public async Task SendCompleteOnboardingReminderNotificationAsync(Guid userKey)
    {
        await _cdpService.SendCompleteOnboardingReminderEventAsync(userKey);
    }
}
