﻿namespace BeTagged.Common.Configurations;

public class ClevertapConfiguration
{
    public const string Section = "ClevertapConfiguration";

    public string ProjectId { get; set; }

    public string Passcode { get; set; }
}
