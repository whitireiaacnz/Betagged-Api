﻿using System.Threading;
using BeTagged.Core.Queries.Shared;
using BeTagged.Core.Services.Security;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Queries.User;

public static class GetNotifications
{
    public class Query : ODataQueryBase, IRequest<PaginatedList<Response>>
    {
    }

    public class Handler : IRequestHandler<Query, PaginatedList<Response>>
    {
        private readonly ICurrentUser _currentUser;
        private readonly IReadOnlyBtDb _btDb;

        public Handler(ICurrentUser currentUser, IReadOnlyBtDb btDb)
        {
            _currentUser = currentUser;
            _btDb = btDb;
        }

        public async Task<PaginatedList<Response>> Handle(Query request, CancellationToken cancellationToken)
        {
            var notifications = await _btDb.InAppNotifications
                .Where(x => x.UserId == _currentUser.UserId)
                .OrderByDescending(x => x.UserNotificationId)
                .Skip(request.Skip)
                .Take(request.Take + 1)
                .Select(x => new Response()
                {
                    NotificationId = x.UserNotificationId,
                    Title = x.Title,
                    Content = x.Content,
                    HasReadByUser = x.HasReadByUser,
                    ArgumentsString = x.Arguments,
                    NotificationType = x.SystemInAppNotificationTypeId,
                    CreatedAtUtc = x.CreatedAtUtc
                }).ToListAsync(cancellationToken);

            return new PaginatedList<Response>(notifications, request.Skip, request.Take);
        }
    }

    public class Response : InAppNotificationModel
    {
    }
}
