﻿using System;
using BeTagged.Common.Extensions;
using BeTagged.Core.Dtos;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.CDP;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Storage;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Core.Utils;
using BeTagged.Data.Constants;
using BeTagged.Data.Repositories;
using Microsoft.EntityFrameworkCore;
using Z.EntityFramework.Plus;

namespace BeTagged.Core.Services.Users;

internal class UserService : IUserService
{
    private readonly IBtDb _db;
    private readonly IPasswordHasher _passwordHasher;
    private readonly IRepository<EmailAddress> _emailRepository;
    private readonly IRepository<Phone> _phoneRepository;
    private readonly IRepository<User> _userRepository;
    private readonly IReadOnlyRepository<User> _usersReadonlyRepo;
    private readonly IStorageService _storageService;
    private readonly ICdpService _cdpService;

    public UserService(IBtDb db, IPasswordHasher passwordHasher, IRepository<EmailAddress> emailRepository,
        IRepository<Phone> phoneRepository, IRepository<User> userRepository, IStorageService storageService, ICdpService cdpService,
        IReadOnlyRepository<User> usersReadonlyRepo)
    {
        _db = db;
        _passwordHasher = passwordHasher;
        _emailRepository = emailRepository;
        _phoneRepository = phoneRepository;
        _userRepository = userRepository;
        _storageService = storageService;
        _cdpService = cdpService;
        _usersReadonlyRepo = usersReadonlyRepo;
    }

    public async Task<Result<User>> CreateUserAsync(CreateUserDto createUser)
    {
        var result = new Result<User>();

        if (createUser.UserType is null)
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = "Specify the UserType of the the User.";
            return result;
        }

        if (string.IsNullOrEmpty(createUser.Email))
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = "Email is required to create a user.";
            return result;
        }

        if (string.IsNullOrEmpty(createUser.Password))
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = "Password is required to create a user.";
            return result;
        }

        var emailResult = await GetEmailEntityAsync(createUser.Email, true,
                "This Email is already registered with us, please try signing in.");

        if (!emailResult.IsSuccess)
        {
            result.Error = emailResult.Error;
            result.ErrorMessage = emailResult.ErrorMessage;
            result.Errors.AddRange(emailResult.Errors);
            return result;
        }

        var email = emailResult.Data;

        var user = new User()
        {
            Name = createUser.Name,
            UserType = createUser.UserType.Value,
            LastLoginAtUtc = DateTime.UtcNow,
            LastActivityAtUtc = DateTime.UtcNow,
        };

        SetUserPassword(user, createUser.Password);

        if (createUser.CountryCode.IsNotNullOrEmpty() && createUser.Phone.IsNotNullOrEmpty())
        {
            var phoneResult = await GetPhoneEntityAsync(createUser.CountryCode, createUser.Phone, true,
                "This phone number is already registered with us, please try signing in.");

            if (!phoneResult.IsSuccess)
            {
                result.Error = phoneResult.Error;
                result.ErrorMessage = phoneResult.ErrorMessage;
                result.Errors.AddRange(phoneResult.Errors);
                return result;
            }

            var phone = phoneResult.Data;
            user.Phones.Add(phone);
        }

        user.EmailAddresses.Add(email);
        _db.Users.Add(user);

        await _db.SaveChangesAsync();

        await _cdpService.CreateUserProfileAsync(user.UserKey, createUser);

        result.Data = user;

        return result;
    }

    public async Task ChangePasswordAsync(int userId, string password)
    {
        var user = await _db.Users.SingleAsync(x => x.UserId == userId);
        SetUserPassword(user, password);
        await _db.SaveChangesAsync();
    }

    public async Task<Result<UserEmailAddressDto>> AddUnverifiedEmailAsync(string emailAddress)
    {
        var result = new Result<UserEmailAddressDto>();

        var emailResult = await GetEmailEntityAsync(emailAddress, false);

        if (!emailResult.IsSuccess)
        {
            result.Error = emailResult.Error;
            result.ErrorMessage = emailResult.ErrorMessage;
            result.Errors.AddRange(emailResult.Errors);
            return result;
        }

        var email = emailResult.Data;

        if (email.EmailAddressId == 0)
        {
            await _emailRepository.AddAsync(email);
            await _db.SaveChangesAsync();
        }

        result.Data = new()
        {
            EmailAddress = emailAddress,
            Id = email.EmailAddressId,
            IsPrimary = email.IsPrimary,
        };

        return result;
    }

    public async Task<Result<UserPhoneDto>> AddUnverifiedPhoneAsync(string countryCode, string phoneNumber)
    {
        var result = new Result<UserPhoneDto>();

        var phoneResult = await GetPhoneEntityAsync(countryCode, phoneNumber, false);

        if (!phoneResult.IsSuccess)
        {
            result.Error = phoneResult.Error;
            result.ErrorMessage = phoneResult.ErrorMessage;
            result.Errors.AddRange(phoneResult.Errors);
            return result;
        }

        var phone = phoneResult.Data;

        if (phone.PhoneId == 0)
        {
            await _phoneRepository.AddAsync(phone);
            await _db.SaveChangesAsync();
        }

        result.Data = new UserPhoneDto() { Phone = phone.ToString(), Id = phone.PhoneId, IsPrimary = phone.IsPrimary };
        return result;
    }

    public async Task<Result<string>> ValidateAndChangePassword(string currentPassword, string newPassword, int userId)
    {
        var result = new Result<string>();

        var userSpec = new GetUserSpec(userId);
        var user = await _userRepository.SingleAsync(userSpec);

        if (user.PasswordHash != _passwordHasher.GetHashedPassword(currentPassword, user.Salt))
        {
            result.ErrorMessage = "Invalid password.";
            result.Error = ErrorType.ValidationError;
            return result;
        }

        if (newPassword == currentPassword)
        {
            result.ErrorMessage = "The new password cannot be the same as your old password, please provide a different one.";
            result.Error = ErrorType.ValidationError;
            return result;
        }

        SetUserPassword(user, newPassword);
        await _db.SaveChangesAsync();

        result.Data = "Password changed successfully.";
        return result;
    }

    public async Task<string> AddProfilePicture(
        string url, int userId)
    {
        var userSpec = new GetUserSpec(userId);
        var user = await _userRepository.SingleAsync(userSpec);

        user.ProfilePicPath = FileUtils.GetFileAbsolutePath(url);

        await _db.SaveChangesAsync();

        var signedUrl = _storageService.GetSignedUrl(user.ProfilePicPath);
        return signedUrl;
    }

    public async Task<Result<bool>> SetPrimaryEmail(int emailAddressId, int userId)
    {
        var result = new Result<bool>();

        var emailSpec = new GetEmailAddressSpec(emailAddressId, userId);
        var email = await _emailRepository.SingleOrDefaultAsync(emailSpec);

        if (email is null)
        {
            result.ErrorMessage = "Email does not exists";
            result.Error = ErrorType.ResourceNotFound;
            result.Data = false;
            return result;
        }

        email.IsPrimary = true;

        await _db.EmailAddresses.Where(x => x.UserId == userId)
            .Where(x => x.EmailAddressId != emailAddressId)
            .UpdateAsync(_ => new EmailAddress() { IsPrimary = false });

        await _db.SaveChangesAsync();

        result.Data = true;
        return result;
    }

    public async Task<Result<bool>> SetPrimaryPhone(int phoneId, int userId)
    {
        var result = new Result<bool>();

        var getPhoneSpec = new GetPhoneSpec(phoneId, userId);
        var phone = await _phoneRepository.SingleOrDefaultAsync(getPhoneSpec);

        if (phone is null)
        {
            result.ErrorMessage = "Phone does not exists";
            result.Error = ErrorType.ResourceNotFound;
            result.Data = false;
            return result;
        }

        phone.IsPrimary = true;

        await _db.Phones.Where(x => x.UserId == userId)
            .Where(x => x.PhoneId != phoneId)
            .UpdateAsync(_ => new Phone() { IsPrimary = false });

        await _db.SaveChangesAsync();

        result.Data = true;
        return result;
    }

    public async Task<Guid> GetUserKeyAsync(int userId)
    {
        var getUserKeySpec = new GetUserKeySpecification(userId);
        var userKey = await _usersReadonlyRepo.SingleAsync(getUserKeySpec);
        return userKey;
    }

    private async Task<Result<Phone>> GetPhoneEntityAsync(string countryCode, string phoneNumber, bool isPrimary,
        string alreadyTakenErrorMessage = "Phone is already taken.")
    {
        var result = new Result<Phone>();

        var isValidPhone = PhoneUtil.IsValidPhone(countryCode, phoneNumber);

        if (!isValidPhone)
        {
            result.ErrorMessage = ValidationMessages.PhoneIsNotValid;
            result.Error = ErrorType.ValidationError;
            return result;
        }

        var (parsedCountryCode, parsedPhoneNumber) = PhoneUtil.ParsePhone(countryCode, phoneNumber);

        var getPhoneSpec = new GetPhoneSpec(parsedCountryCode, parsedPhoneNumber);
        var phone = await _phoneRepository.SingleOrDefaultAsync(getPhoneSpec);

        if (phone?.UserId is not null)
        {
            result.ErrorMessage = alreadyTakenErrorMessage;
            result.Error = ErrorType.ValidationError;
            return result;
        }

        phone ??= new Phone()
        {
            CountryCode = parsedCountryCode,
            PhoneNumber = parsedPhoneNumber,
            IsVerified = false,
            IsPrimary = isPrimary,
        };

        result.Data = phone;
        return result;
    }

    private async Task<Result<EmailAddress>> GetEmailEntityAsync(string emailAddress, bool isPrimary,
        string alreadyTakenErrorMessage = "Email is already taken.")
    {
        var result = new Result<EmailAddress>();

        var emailSpec = new GetEmailAddressSpec(emailAddress);
        var email = await _emailRepository.SingleOrDefaultAsync(emailSpec);

        if (email?.UserId is not null)
        {
            result.ErrorMessage = alreadyTakenErrorMessage;
            result.Error = ErrorType.ValidationError;
            return result;
        }

        email ??= new EmailAddress()
        {
            EmailAddress_ = emailAddress,
            IsVerified = false,
            IsPrimary = isPrimary,
        };

        result.Data = email;
        return result;
    }

    private User SetUserPassword(User user, string newPassword)
    {
        if (user.PasswordHash is null)
        {
            user.LastPasswordChangeAtUtc = DateTime.UtcNow;
        }

        var passwordSalt = SecurityUtil.GenerateSalt(DbConstants.UserSaltLength);

        user.PasswordHash = _passwordHasher.GetHashedPassword(newPassword, passwordSalt);
        user.LastActivityAtUtc = DateTime.UtcNow;
        user.Salt = passwordSalt;

        return user;
    }
}
