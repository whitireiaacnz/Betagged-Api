﻿using System;

namespace BeTagged.Core.Exceptions;

public class EmailTransportException : Exception
{
    public EmailTransportException(string message, Exception innerException) : base(message, innerException)
    {
    }
}
