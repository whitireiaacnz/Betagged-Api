﻿using System;
using BeTagged.Data.Seed;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class BrandProductsTable : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(
            name: "system_countries_lut",
            schema: "public",
            columns: table => new
            {
                system_country_id = table.Column<byte>(type: "smallint", nullable: false),
                name = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_system_countries_lut", x => x.system_country_id);
            });

        migrationBuilder.CreateTable(
            name: "system_product_status_lut",
            schema: "public",
            columns: table => new
            {
                system_product_status_id = table.Column<byte>(type: "smallint", nullable: false),
                name = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_system_product_status_lut", x => x.system_product_status_id);
            });

        migrationBuilder.CreateTable(
            name: "brand_products",
            schema: "public",
            columns: table => new
            {
                brand_product_id = table.Column<int>(type: "integer", nullable: false)
                    .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                product_code = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                description = table.Column<string>(type: "character varying(1024)", maxLength: 1024, nullable: true),
                currency_code = table.Column<string>(type: "character varying(4)", maxLength: 4, nullable: true),
                price = table.Column<decimal>(type: "numeric", nullable: false),
                commission_percentage = table.Column<int>(type: "integer", nullable: false),
                buyer_discount_percentage = table.Column<int>(type: "integer", nullable: false),
                is_approval_based_offer = table.Column<bool>(type: "boolean", nullable: false),
                banner_image_url = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                show_case_media_urls = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                social_media_kit = table.Column<ProductSocialMediaKit>(type: "jsonb", nullable: true),
                company_product_url = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                tiktok_commerce_url = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                be_tagged_mall_url = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                other_commerce_url = table.Column<string>(type: "character varying(512)", maxLength: 512, nullable: true),
                listed_on_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                brand_organization_id = table.Column<int>(type: "integer", nullable: false),
                product_status_id = table.Column<byte>(type: "smallint", nullable: false),
                created_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                modified_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                is_deleted = table.Column<bool>(type: "boolean", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_brand_products", x => x.brand_product_id);
                table.ForeignKey(
                    name: "fk_brand_products_brand_organizations_brand_organization_id",
                    column: x => x.brand_organization_id,
                    principalSchema: "public",
                    principalTable: "brand_organizations",
                    principalColumn: "brand_organization_id",
                    onDelete: ReferentialAction.Restrict);
                table.ForeignKey(
                    name: "fk_brand_products_system_product_status_lut_product_status_id",
                    column: x => x.product_status_id,
                    principalSchema: "public",
                    principalTable: "system_product_status_lut",
                    principalColumn: "system_product_status_id",
                    onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateTable(
            name: "brand_product_countries",
            schema: "public",
            columns: table => new
            {
                brand_product_id = table.Column<int>(type: "integer", nullable: false),
                system_country_id = table.Column<byte>(type: "smallint", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_brand_product_countries", x => new { x.brand_product_id, x.system_country_id });
                table.ForeignKey(
                    name: "fk_brand_product_countries_brand_products_brand_product_id",
                    column: x => x.brand_product_id,
                    principalSchema: "public",
                    principalTable: "brand_products",
                    principalColumn: "brand_product_id",
                    onDelete: ReferentialAction.Cascade);
                table.ForeignKey(
                    name: "fk_brand_product_countries_system_countries_lut_system_country",
                    column: x => x.system_country_id,
                    principalSchema: "public",
                    principalTable: "system_countries_lut",
                    principalColumn: "system_country_id",
                    onDelete: ReferentialAction.Cascade);
            });

        migrationBuilder.CreateIndex(
            name: "ix_brand_product_countries_system_country_id",
            schema: "public",
            table: "brand_product_countries",
            column: "system_country_id");

        migrationBuilder.CreateIndex(
            name: "ix_brand_products_brand_organization_id",
            schema: "public",
            table: "brand_products",
            column: "brand_organization_id",
            unique: true);

        migrationBuilder.CreateIndex(
            name: "ix_brand_products_product_status_id",
            schema: "public",
            table: "brand_products",
            column: "product_status_id",
            unique: true);
        EnumLookupTableSeeder.FillEnumLookup(migrationBuilder, "system_product_status_lut", typeof(SystemProductStatusOption));
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable(
            name: "brand_product_countries",
            schema: "public");

        migrationBuilder.DropTable(
            name: "brand_products",
            schema: "public");

        migrationBuilder.DropTable(
            name: "system_countries_lut",
            schema: "public");

        migrationBuilder.DropTable(
            name: "system_product_status_lut",
            schema: "public");
    }
}
