﻿using System;
using System.Threading;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetInfluencersPromotionRequestsSpec : IListResultQuerySpecification<ProductPromotionRequest, ProductPromotionRequest>
{
    public GetInfluencersPromotionRequestsSpec(int brandProductId, IEnumerable<int> influencerIds)
    {
        Query = async (queryable, ct) => await queryable
            .Include(x => x.Influencer)
            .ThenInclude(x => x.User)
            .Where(x => x.BrandProductId == brandProductId
                        && influencerIds.Contains(x.InfluencerId)
                        && x.ApprovalStatusId == SystemApprovalStatusOption.Pending)
            .ToListAsync(ct);
    }

    public Func<IQueryable<ProductPromotionRequest>, CancellationToken, Task<IList<ProductPromotionRequest>>> Query { get; }
}
