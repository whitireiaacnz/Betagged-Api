﻿using System;
using System.Text.Json;

namespace BeTagged.Data.Entities;

public class InfluencerMediaAccounts
{
    public SocialMediaAccount Instagram { get; set; }

    public SocialMediaAccount TikTok { get; set; }

    public SocialMediaAccount Twitter { get; set; }

    public SocialMediaAccount Facebook { get; set; }
}

public class SocialMediaAccount : IDisposable
{
    public string Username { get; set; }

    public JsonDocument MetaData { get; set; }

    public void Dispose()
    {
        MetaData?.Dispose();
    }
}
