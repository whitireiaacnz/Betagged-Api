﻿using System.Threading;
using BeTagged.Core.Dtos;

namespace BeTagged.Core.Services.Promotion;

public interface IProductPromotionService
{
    Task<Result<ProductPromotionDetails>> CreatePromotionAsync(int brandProductId, SystemSalesChannelOption salesChannelId, int influencerId, BrandProduct product, CancellationToken cancellationToken);

    Task<Result<ProductPromotionRequestDetails>> ActOnPromotionRequestAsync(ActOnProductPromotionRequestDto actOnPromotionRequestDto,
        CancellationToken cancellationToken);

    Task<Result<InfluencerSeekingApprovalModel>> ActOnPromotionRequestsAsync(ActOnProductPromotionRequestsDto dto);

    Task ApproveAllPendingRequestsAsync(int brandProductId, int brandOrganizationId, int actByMemberId, CancellationToken cancellationToken);

    Task<ProductPromotion> GetProductPromotionByKey(string productPromotionKey);
}
