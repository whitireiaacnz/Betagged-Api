﻿using System;
using System.Threading;
using BeTagged.Core.Queries.Shared;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Storage;
using BeTagged.Data.Services;

namespace BeTagged.Core.Queries.BrandBusinessInsight;

public static class GetBrandOrganizationPlatformInsights
{
    public class Query : ODataQueryBase, IRequest<Response>
    {
        public byte CountryId { get; set; }

        public DateTime? From { get; set; }

        public DateTime? To { get; set; }

        public SystemSalesChannelOption SalesChannel { get; set; }
    }

    public class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.From).LessThan(x => x.To).When(x => x.From is not null);
            RuleFor(x => x.CountryId).GreaterThan((byte)0);
        }
    }

    public class Handler : IRequestHandler<Query, Response>
    {
        private readonly ICurrentBrandMember _currentBrandMember;
        private readonly IQueryService _queryService;
        private readonly IStorageService _storageService;

        public Handler(ICurrentBrandMember currentBrandMember, IQueryService queryService,
            IStorageService storageService)
        {
            _currentBrandMember = currentBrandMember;
            _queryService = queryService;
            _storageService = storageService;
        }

        public async Task<Response> Handle(Query request, CancellationToken cancellationToken)
        {
            var response = new Response();

            var parameters = new
            {
                BrandOrganizationId = _currentBrandMember.BrandOrganizationId,
                FromDate = request.From,
                ToDate = request.To,
                CountryId = request.CountryId,
                SalesChannelId = request.SalesChannel,
                Skip = request.Skip,
                Take = request.Take
            };

            var result = await _queryService.QueryAsync<PlatformInsight>(BtQueryType.GetBrandPlatformInsights,
                null, parameters);

            var salesAndClicks = await _queryService.QueryAsync<SalesAndClicksData>(BtQueryType.GetSalesAndClicksForBrandBusinessInsights,
                null, parameters);

            foreach (var product in result)
            {
                product.ShowCaseMediaUrls =
                    product.ShowCaseMediaUrls.Select(x => _storageService.GetSignedUrl(x));
            }

            response.PlatformInsights = result;
            response.ClicksSummation = salesAndClicks.Sum(x => x.Clicks);
            response.SalesSummation = salesAndClicks.Sum(x => x.Sales);

            return response;
        }
    }

    public class Response
    {
        public int SalesSummation { get; set; }

        public int ClicksSummation { get; set; }

        public IEnumerable<PlatformInsight> PlatformInsights { get; set; }
    }

    public class PlatformInsight
    {
        public int BrandProductId { get; set; }

        public string BrandProductName { get; set; }

        public int Sales { get; set; }

        public int Clicks { get; set; }

        public decimal Conversions { get; set; }

        public int InfluencersInvolved { get; set; }

        public IEnumerable<string> ShowCaseMediaUrls { get; set; }
    }
}
