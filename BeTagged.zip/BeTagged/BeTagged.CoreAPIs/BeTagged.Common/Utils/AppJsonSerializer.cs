﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace BeTagged.Common.Utils;

public static class AppJsonSerializer
{
    static AppJsonSerializer()
    {
        ContractResolver = new CamelCasePropertyNamesContractResolver();

        JsonSerializerSettings serializerSettings = new()
        {
            ContractResolver = ContractResolver
        };

        JsonConvert.DefaultSettings = () => serializerSettings;
    }

    public static IContractResolver ContractResolver { get; }

    public static string Serialize(this object input, JsonSerializerSettings settings = null)
        => JsonConvert.SerializeObject(input, settings);

    public static T Deserialize<T>(this string input, JsonSerializerSettings settings = null)
        => input is null ? default : JsonConvert.DeserializeObject<T>(input, settings);

    public static object Deserialize(this string input, Type type, JsonSerializerSettings settings = null)
        => JsonConvert.DeserializeObject(input, type, settings);
}
