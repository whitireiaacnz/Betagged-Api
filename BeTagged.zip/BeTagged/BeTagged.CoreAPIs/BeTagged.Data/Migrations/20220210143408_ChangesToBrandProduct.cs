﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class ChangesToBrandProduct : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AlterColumn<string>(
            name: "hashtags",
            schema: "public",
            table: "brand_products",
            type: "character varying(1024)",
            maxLength: 1024,
            nullable: true,
            oldClrType: typeof(string),
            oldType: "text",
            oldNullable: true);

        migrationBuilder.CreateTable(
            name: "brand_product_categories",
            schema: "public",
            columns: table => new
            {
                brand_product_id = table.Column<int>(type: "integer", nullable: false),
                system_category_id = table.Column<short>(type: "smallint", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_brand_product_categories", x => new { x.brand_product_id, x.system_category_id });
                table.ForeignKey(
                    name: "fk_brand_product_categories_brand_products_brand_product_id",
                    column: x => x.brand_product_id,
                    principalSchema: "public",
                    principalTable: "brand_products",
                    principalColumn: "brand_product_id",
                    onDelete: ReferentialAction.Restrict);
                table.ForeignKey(
                    name: "fk_brand_product_categories_system_categories_lut_system_categ",
                    column: x => x.system_category_id,
                    principalSchema: "public",
                    principalTable: "system_categories_lut",
                    principalColumn: "system_category_id",
                    onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateIndex(
            name: "ix_brand_product_categories_system_category_id",
            schema: "public",
            table: "brand_product_categories",
            column: "system_category_id");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable(
            name: "brand_product_categories",
            schema: "public");

        migrationBuilder.AlterColumn<string>(
            name: "hashtags",
            schema: "public",
            table: "brand_products",
            type: "text",
            nullable: true,
            oldClrType: typeof(string),
            oldType: "character varying(1024)",
            oldMaxLength: 1024,
            oldNullable: true);
    }
}
