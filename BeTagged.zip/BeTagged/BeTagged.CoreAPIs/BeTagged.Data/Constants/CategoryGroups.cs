﻿namespace BeTagged.Data.Constants;

public static class CategoryGroups
{
    public const string Architecture = "Architecture";

    public const string Arts = "Arts";

    public const string Beauty = "Beauty";

    public const string Entertainment = "Entertainment";

    public const string FashionAndLuxury = "Fashion and luxury";

    public const string Fitness = "Fitness";

    public const string FoodAndBeverages = "Food & Beverages";

    public const string Games = "Games";

    public const string HomeAndGarden = "Home and Garden";

    public const string Outdoors = "Outdoors";

    public const string Parenting = "Parenting";

    public const string PetsAndAnimal = "Pets and Animal";

    public const string Photography = "Photography";

    public const string Sports = "Sports";

    public const string Technology = "Technology";

    public const string Travel = "Travel";

    public const string Others = "Others";
}
