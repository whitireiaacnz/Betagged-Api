﻿using System.Threading;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Commands.Authentication;

public static class BrandMemberAuthenticate
{
    public record Command(string Email, string Password, string InvitationKey) : IRequest<BrandMemberAuthenticationResponse>;

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.Email).NotEmpty().EmailAddress();
            RuleFor(x => x.Password).NotEmpty();
        }
    }

    public class Handler : IRequestHandler<Command, BrandMemberAuthenticationResponse>
    {
        private readonly IAuthenticationService _authenticationService;

        public Handler(IAuthenticationService authenticationService)
        {
            _authenticationService = authenticationService;
        }

        public async Task<BrandMemberAuthenticationResponse> Handle(Command request, CancellationToken cancellationToken)
        {
            return await _authenticationService.AuthenticateBrandMemberAsync(request.Email, request.Password, request.InvitationKey);
        }
    }
}
