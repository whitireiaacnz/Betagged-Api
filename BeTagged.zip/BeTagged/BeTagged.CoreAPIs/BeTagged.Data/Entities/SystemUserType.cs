﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Entities;

[Table("system_user_types_lut")]
public class SystemUserType
{
    public SystemUserType()
    {
        Users = new List<User>();
    }

    public SystemUserTypeOption SystemUserTypeId { get; set; }

    [Required, MaxLength(16)]
    public string Name { get; set; }

    // Reverse navigation
    public ICollection<User> Users { get; set; }
}
