﻿using BeTagged.Core.Configurations;
using BeTagged.Core.Exceptions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Twilio;
using Twilio.Exceptions;
using Twilio.Rest.Api.V2010.Account;

namespace BeTagged.Core.Services.Communication;

internal class TwilioTransportService : IPhoneTransportService
{
    private readonly ILogger _logger;

    public TwilioTransportService(IOptions<TwilioConfiguration> twilioConfiguration, ILogger<TwilioTransportService> logger)
    {
        TwilioClient.Init(twilioConfiguration.Value.AccountSid, twilioConfiguration.Value.AuthToken);
        _logger = logger;
    }

    public async Task SendTextAsync(string phoneNumber, string text)
    {
        try
        {
            await MessageResource.CreateAsync(
            body: text,
            from: new Twilio.Types.PhoneNumber(PhoneConstants.SmsFrom),
            to: phoneNumber);
        }
        catch (TwilioException ex)
        {
            _logger.LogError(ex, "Error while sending the message. {Info}", new { PhoneNumber = phoneNumber, Text = text });
            throw new PhoneTransportException(ex.Message, ex.InnerException);
        }
    }
}
