﻿using System;
using System.Collections.Generic;
using BeTagged.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(ProductPromotionEntityConfiguration))]
public class ProductPromotion : BaseEntity
{
    public ProductPromotion()
    {
        ProductSales = new List<ProductSale>();
    }

    public int ProductPromotionId { get; set; }

    public int BrandProductId { get; set; }

    public int InfluencerId { get; set; }

    public SystemSalesChannelOption SalesChannelId { get; set; }

    public int CommissionPercentage { get; set; }

    [CurrencyColumn]
    public decimal PlatformCommissionPercentage { get; set; }

    [CurrencyColumn]
    public decimal InfluencerCommissionPercentage { get; set; }

    public int? ProductPromotionRequestId { get; set; }

    public int? ProductPromotionLinkId { get; set; }

    public int? DiscountCodeId { get; set; }

    public Guid ProductPromotionKey { get; set; }

    // Foreign Keys
    public BrandProduct BrandProduct { get; set; }

    public Influencer Influencer { get; set; }

    public SystemSalesChannel SalesChannel { get; set; }

    public ProductPromotionRequest ProductPromotionRequest { get; set; }

    public ProductPromotionLink ProductPromotionLink { get; set; }

    public BrandProductDiscountCode DiscountCode { get; set; }

    // Reverse Navigation
    public ICollection<ProductSale> ProductSales { get; set; }
}
