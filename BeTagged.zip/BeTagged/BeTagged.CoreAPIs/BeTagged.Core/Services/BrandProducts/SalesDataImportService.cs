﻿using System;
using System.Data;
using System.Globalization;
using BeTagged.Common.Extensions;
using BeTagged.Core.Dtos;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Misc;
using BeTagged.Core.Services.ProductSales;
using BeTagged.Core.Services.Storage;
using BeTagged.Core.Specifications;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Core.Utils;
using BeTagged.Data.Repositories;
using Microsoft.Extensions.Logging;

namespace BeTagged.Core.Services.BrandProducts;

internal class SalesDataImportService : ISalesDataImportService
{
    private const string DiscountCodesColumnName = "Coupon Codes";
    private const string NumberOfSalesColumnName = "Volume of sales using coupon code";
    private const string SalesTillDateColumnName = "Sales made upto date (dd-mm-yyyy)";
    private const string RequiredDateTimeFormat = "dd-MM-yyyy";

    private readonly IProductSalesService _productSaleService;
    private readonly IBtDb _db;
    private readonly IRepository<BrandProductsSalesDataFile> _salesDataFileRepository;
    private readonly IStorageService _storageService;
    private readonly IExcelDataReaderService _excelDataReader;
    private readonly IRepository<BrandProductDiscountCode> _discountsCodeRepository;
    private readonly ILogger _logger;

    public SalesDataImportService(IBtDb db, IRepository<BrandProductsSalesDataFile> salesDataFileRepository,
        IStorageService storageService, IExcelDataReaderService excelDataReader,
        IRepository<BrandProductDiscountCode> discountsCodeRepository, ILogger<SalesDataImportService> logger, IProductSalesService productSaleService)
    {
        _db = db;
        _salesDataFileRepository = salesDataFileRepository;
        _storageService = storageService;
        _excelDataReader = excelDataReader;
        _discountsCodeRepository = discountsCodeRepository;
        _logger = logger;
        _productSaleService = productSaleService;
    }

    public async Task ImportSalesDataAsync(int salesDataFileId)
    {
        var getSalesDataFileSpec = new GetBrandProductSalesDataFileSpec(salesDataFileId);
        var salesDataFile = await _salesDataFileRepository.SingleAsync(getSalesDataFileSpec);

        salesDataFile.ImportStatusId = ImportStatus.InProgress;
        await _db.SaveChangesAsync();

        try
        {
            var salesDataFileUrl = _storageService.GetSignedUrl(salesDataFile.FilePath);
            var salesData = await _excelDataReader.GetExcelDataSetAsync(salesDataFileUrl);
            var rows = salesData.Tables[0].Rows;

            await _db.ExecuteInTransactionAsync(async () =>
            {
                for (int rowIndex = 1; rowIndex < rows.Count; rowIndex++)
                {
                    try
                    {
                        var row = rows[rowIndex];
                        await ImportSalesDataRowAsync(row, salesDataFile.BrandProductId, salesDataFileId);
                    }
                    catch (Exception e)
                    {
                        _logger.LogError(e, "Error while importing sales data row. {@Info}",
                            new { Row = rowIndex, SaleDataFileId = salesDataFileId });
                    }
                }

                salesDataFile.ImportStatusId = ImportStatus.Completed;

                await _db.SaveChangesAsync();
            });
        }
        catch (Exception e)
        {
            salesDataFile.ImportStatusId = ImportStatus.Failed;
            salesDataFile.ImportError = e.ToString();

            _logger.LogError(e, "Error while importing sales data. SalesDataFileId: {SalesDataFileId}",
                salesDataFileId);

            throw;
        }
        finally
        {
            await _db.SaveChangesAsync();
        }
    }

    public async Task<Result<bool>> ValidateSalesDataFileAsync(string url)
    {
        var result = new Result<bool>();

        if (!PropertyValidationUtil.IsExcelFile(url))
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = ValidationMessages.SalesDataFileMustBeExcelFile;
            return result;
        }

        var salesData = await _excelDataReader.GetExcelDataSetAsync(url);
        var table = salesData.Tables[0];
        var rowCount = table.Rows.Count;

        if (rowCount == 0)
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = "Excel file doesn't have any row.";
        }

        var headerRow = table.Rows[0].ItemArray.Where(x => x is not DBNull).ToArray();

        if (headerRow.Length > 3)
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = "Excel file has more than excepted (3) columns.";
            return result;
        }

        var requiredColumns = new List<string>
        {
            DiscountCodesColumnName, NumberOfSalesColumnName, SalesTillDateColumnName
        };

        foreach (var column in headerRow)
        {
            var columnName = column!.ToString();
            requiredColumns.Remove(columnName);
        }

        if (requiredColumns.Any())
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage =
                $"Excel file doesn't have required columns. Columns missing are '{string.Join(", ", requiredColumns)}'." +
                " Please download the sample file to know the required structure";
            return result;
        }

        if (rowCount > 500)
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = "You can upload at most 500 discount codes sales data at once.";
            return result;
        }

        var rows = table.Rows;
        for (int rowIndex = 1; rowIndex < rows.Count; rowIndex++)
        {
            var rowValidationResult = ValidateSalesDataRow(rows[rowIndex], rowIndex);

            if (!rowValidationResult.IsSuccess)
            {
                result.Error = rowValidationResult.Error;
                result.ErrorMessage = rowValidationResult.ErrorMessage;
                return result;
            }
        }

        return result;
    }

    private static string GetDateTimeStringForExcelColumn(object dateTimeObject)
    {
        return dateTimeObject is DateTime time
            ? time.ToString(RequiredDateTimeFormat)
            : dateTimeObject.ToString();
    }

    private static Result<bool> ValidateSalesDataRow(DataRow row, int rowNumber)
    {
        var numberOfSalesStr = row.ItemArray[1]!.ToString();

        var result = new Result<bool>();

        if (!int.TryParse(numberOfSalesStr, out _))
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = $"Sales volume at row {rowNumber + 1} is not a valid number.";
            return result;
        }

        var salesTillDateStr = row.ItemArray[2]!.ToString();

        if (!DateTime.TryParseExact(GetDateTimeStringForExcelColumn(row.ItemArray[2]!), RequiredDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None,
                out _))
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage =
                $"Sales made upto date at row {rowNumber + 1} is not a valid date, value got is '{salesTillDateStr}'`";
            return result;
        }

        return result;
    }

    private async Task ImportSalesDataRowAsync(DataRow row, int brandProductId, int salesDataFileId)
    {
        var discountCode = row.ItemArray[0]!.ToString();
        var numberOfSales = row.ItemArray[1]!.ToString().ToInt();

        DateTime.TryParseExact(GetDateTimeStringForExcelColumn(row.ItemArray[2]!), RequiredDateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None,
            out var salesTillDate);

        salesTillDate = DateTime.SpecifyKind(salesTillDate, DateTimeKind.Utc);

        var discountCodeSalesInfoSpec =
            new GetSalesInfoForDiscountCodeSpec(brandProductId, discountCode, salesTillDate);

        var discountCodeSalesDataInfo =
            await _discountsCodeRepository.SingleOrDefaultAsync(discountCodeSalesInfoSpec);

        if (discountCodeSalesDataInfo is null)
        {
            _logger.LogInformation("Discount code doesn't exists while importing the sales data file. {@Info}",
                new { DiscountCode = discountCode, SalesDataFileId = salesDataFileId });

            return;
        }

        if (numberOfSales <= discountCodeSalesDataInfo!.NumberOfSales ||
            discountCodeSalesDataInfo.ProductPromotionId is null)
        {
            return;
        }

        var numberOfSalesToImport = numberOfSales - discountCodeSalesDataInfo.NumberOfSales;

        var dto = new AddProductSaleDto()
        {
            ProductPromotionId = discountCodeSalesDataInfo.ProductPromotionId!.Value,
            BrandProductId = discountCodeSalesDataInfo.BrandProductId,
            InfluencerId = discountCodeSalesDataInfo.InfluencerId!.Value,
            BrandOrganizationId = discountCodeSalesDataInfo.BrandOrganizationId,
            SalesChannelId = discountCodeSalesDataInfo.SalesChannel!.Value,
            IsCommissionPaidOff = false,
            SoldAtUtc = salesTillDate,
            SalesDataFileId = salesDataFileId,
            Quantity = numberOfSalesToImport,
            Price = discountCodeSalesDataInfo.Price,
            CommissionPercentage = discountCodeSalesDataInfo.CommissionPercentage,
            InfluencerCommissionPercentage = discountCodeSalesDataInfo.InfluencerCommissionPercentage,
            SalesSourceId = SystemSalesSourceOption.SalesDataImport,
        };

        await _productSaleService.AddProductSaleAsync(dto);
    }
}
