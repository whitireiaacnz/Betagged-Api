﻿using System;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetBrandMembershipInvitationForSigninSpec : ISingleResultQuerySpecification<BrandMembershipInvitation, BrandMembershipInvitation>
{
    public GetBrandMembershipInvitationForSigninSpec(int userId, string invitationKey)
    {
        Query = q => q
            .Include(x => x.BrandMembership.BrandMember.User)
            .Include(x => x.BrandMembership.BrandOrganization)
            .ThenInclude(x => x.Categories)
            .Where(x => x.InvitationKey == invitationKey)
            .Where(x => x.BrandMembership.BrandMember.User.UserId == userId)
            .Where(x => !x.BrandMembership.IsDisabled);
    }

    public Func<IQueryable<BrandMembershipInvitation>, IQueryable<BrandMembershipInvitation>> Query { get; }
}
