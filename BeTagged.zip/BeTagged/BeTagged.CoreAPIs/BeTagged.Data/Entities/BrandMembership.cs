﻿using BeTagged.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(BrandMembershipEntityConfiguration))]
public class BrandMembership : BaseEntity, IBrandEntity
{
    public int BrandMembershipId { get; set; }

    public bool IsDisabled { get; set; }

    public int BrandMemberId { get; set; }

    public int BrandOrganizationId { get; set; }

    public int InvitedByMemberId { get; set; }

    public SystemRoleOption RoleId { get; set; }

    public int? InvitationId { get; set; }

    // Foreign keys
    public BrandMember BrandMember { get; set; }

    public BrandOrganization BrandOrganization { get; set; }

    public BrandMember InvitedByMember { get; set; }

    public SystemRole Role { get; set; }

    public BrandMembershipInvitation Invitation { get; set; }

    public void DisableMembership()
    {
        IsDisabled = true;
        IsDeleted = true;
    }
}
