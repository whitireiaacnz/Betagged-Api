﻿using System.Threading;
using BeTagged.Core.Services.Otp;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Commands.User;

public static class VerifyEmail
{
    public record Command(int EmailAddressId, string Otp) : IRequest<Response>;

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.EmailAddressId).GreaterThan(0);
            RuleFor(x => x.Otp).NotEmpty();
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly ICurrentUser _currentUser;
        private readonly IEmailOtpService _emailOtpService;

        public Handler(ICurrentUser currentUser, IEmailOtpService emailOtpService)
        {
            _currentUser = currentUser;
            _emailOtpService = emailOtpService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var verificationResult = await _emailOtpService.VerifyEmailAsync(
                _currentUser.UserId,
                request.EmailAddressId,
                request.Otp, SystemOtpUsageTypeOption.Verification);

            return new Response() { ErrorMessage = verificationResult.ErrorMessage, Error = verificationResult.Error };
        }
    }

    public class Response : Result
    {
    }
}
