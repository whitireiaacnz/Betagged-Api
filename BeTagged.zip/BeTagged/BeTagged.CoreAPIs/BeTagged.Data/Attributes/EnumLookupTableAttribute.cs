﻿using System;

namespace BeTagged.Data.Attributes;

[AttributeUsage(AttributeTargets.Enum)]
internal class EnumLookupTableAttribute : Attribute
{
    public EnumLookupTableAttribute(Type entity) => Entity = entity;

    public Type Entity { get; }
}
