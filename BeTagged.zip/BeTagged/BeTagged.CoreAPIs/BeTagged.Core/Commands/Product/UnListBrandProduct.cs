﻿using System.Threading;
using BeTagged.Core.Services.BrandProducts;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Commands.Product;

public static class UnListBrandProduct
{
    public record Command(int BrandProductId) : IRequest<Response>;

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IBrandProductService _brandProductService;
        private readonly ICurrentBrandMember _currentBrandMember;

        public Handler(IBrandProductService brandProductService, ICurrentBrandMember currentBrandMember)
        {
            _brandProductService = brandProductService;
            _currentBrandMember = currentBrandMember;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            Result result = await _brandProductService.UnlistProductAsync(_currentBrandMember.BrandOrganizationId,
                request.BrandProductId);

            return result.Map<Response>();
        }
    }

    public class Response : Result
    {
    }
}
