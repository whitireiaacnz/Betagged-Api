﻿namespace BeTagged.Core.Enums;

public enum OrderByDirectionType
{
    ASC,
    DESC
}
