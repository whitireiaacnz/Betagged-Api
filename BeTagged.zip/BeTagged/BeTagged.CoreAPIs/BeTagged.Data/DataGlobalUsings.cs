﻿global using BeTagged.Data.Attributes;
global using BeTagged.Data.Entities;
global using BeTagged.Data.Enums;
