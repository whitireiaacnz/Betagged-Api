﻿using System;

namespace BeTagged.Core.Services.UrlUtils;

public interface IUrlShortenerService
{
    Task<string> ShortenUrlAsync(Uri uri);
}
