﻿namespace BeTagged.Core.Dtos;

public class BrandMembershipInvitationResponseDto
{
    public int Id { get; set; }

    public string Email { get; set; }

    public SystemRoleOption Role { get; set; }

    public SystemInvitationStatusOptions Status { get; set; }
}
