﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

internal class ProductPromotionRequestEntityConfiguration : IEntityTypeConfiguration<ProductPromotionRequest>
{
    public void Configure(EntityTypeBuilder<ProductPromotionRequest> builder)
    {
        builder.HasKey(x => x.ProductPromotionRequestId);

        builder.Property(x => x.ProductPromotionRequestId)
            .UseIdentityAlwaysColumn();

        builder.HasOne(x => x.ActedByBrandMember)
            .WithMany()
            .HasForeignKey(x => x.ActedByBrandMemberId);

        builder.HasOne(x => x.Influencer)
           .WithMany(x => x.ProductPromotionRequests)
           .HasForeignKey(x => x.InfluencerId);

        builder.HasOne(x => x.SalesChannel)
           .WithMany(x => x.ProductPromotionRequests)
           .HasForeignKey(x => x.SalesChannelId);

        builder.HasOne(x => x.BrandProduct)
           .WithMany(x => x.ProductPromotionRequests)
           .HasForeignKey(x => x.BrandProductId);

        builder.HasOne(x => x.BrandOrganization)
           .WithMany(x => x.ProductPromotionRequests)
           .HasForeignKey(x => x.BrandOrganizationId);

        builder.HasOne(x => x.ApprovalStatus)
           .WithMany(x => x.ProductPromotionRequests)
           .HasForeignKey(x => x.ApprovalStatusId);
    }
}
