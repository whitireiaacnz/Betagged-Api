﻿using System.Threading;
using BeTagged.Core.Services.Profile;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Commands.Profile;

public static class SocialMedia
{
    public class Command : InfluencerMediaAccountsModel, IRequest<Response>
    {
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x).Must(x => x.Facebook != null
                        || x.Twitter != null
                        || x.Facebook != null
                        || x.Instagram != null)
                .WithMessage(ValidationMessages.ProvideAtLeastOneSocialMediaHandle);
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly ICurrentInfluencer _currentInfluencer;
        private readonly IInfluencerService _influencerService;

        public Handler(ICurrentInfluencer currentInfluencer, IInfluencerService influencerService)
        {
            _currentInfluencer = currentInfluencer;
            _influencerService = influencerService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            Result response = await _influencerService.UpdateSocialMediaHandle(_currentInfluencer.InfluencerId,
                request);

            return response.Map<Response>();
        }
    }

    public class Response : Result
    {
    }
}
