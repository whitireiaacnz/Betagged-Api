﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

public class BrandMembershipInvitationEntityConfiguration : IEntityTypeConfiguration<BrandMembershipInvitation>
{
    public void Configure(EntityTypeBuilder<BrandMembershipInvitation> builder)
    {
        builder.HasKey(x => x.BrandMembershipInvitationId);

        builder.Property(x => x.BrandMembershipInvitationId)
            .UseIdentityAlwaysColumn();

        builder.Property(x => x.NormalizedEmailAddress)
            .HasComputedColumnSql("upper(email_address)", stored: true);

        builder.HasOne(x => x.InvitedByBrandMember)
            .WithMany(x => x.SentBrandMembershipInvitations)
            .HasForeignKey(x => x.InvitedByBrandMemberId);

        builder.HasOne(x => x.BrandOrganization)
            .WithMany(x => x.BrandMembershipInvitations)
            .HasForeignKey(x => x.BrandOrganizationId);

        builder.HasOne(x => x.Role)
            .WithMany(x => x.BrandMembershipInvitations)
            .HasForeignKey(x => x.RoleId);

        builder.HasOne(x => x.InvitationStatus)
            .WithMany(x => x.BrandMembershipInvitations)
            .HasForeignKey(x => x.InvitationStatusId);

        builder.HasIndex(x => x.InvitationKey).IsUnique();
    }
}
