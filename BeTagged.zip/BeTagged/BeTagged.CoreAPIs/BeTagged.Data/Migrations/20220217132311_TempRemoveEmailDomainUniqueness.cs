﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class TempRemoveEmailDomainUniqueness : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropIndex(
            name: "ix_brand_organizations_email_domain",
            schema: "public",
            table: "brand_organizations");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateIndex(
            name: "ix_brand_organizations_email_domain",
            schema: "public",
            table: "brand_organizations",
            column: "email_domain",
            unique: true);
    }
}
