﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

internal class PasswordResetTokenEntityConfiguration : IEntityTypeConfiguration<PasswordResetToken>
{
    public void Configure(EntityTypeBuilder<PasswordResetToken> builder)
    {
        builder.HasKey(x => x.PasswordResetTokenId);
        builder.Property(x => x.PasswordResetTokenId).UseIdentityAlwaysColumn();
        builder.Property(x => x.Token).IsRequired();

        builder.HasOne(x => x.User)
            .WithMany(x => x.PasswordResetTokens)
            .HasForeignKey(x => x.UserId);

        builder.HasIndex(x => x.Token).IsUnique();
    }
}
