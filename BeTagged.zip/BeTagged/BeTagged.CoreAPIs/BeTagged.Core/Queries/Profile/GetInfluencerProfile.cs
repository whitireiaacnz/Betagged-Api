﻿using System.Threading;
using BeTagged.Core.Dtos;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Storage;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Queries.Profile;

public static class GetInfluencerProfile
{
    public class Query : IRequest<InfluencerProfileDto>
    {
    }

    public class Handler : IRequestHandler<Query, InfluencerProfileDto>
    {
        private readonly ICurrentInfluencer _currentInfluencer;

        private readonly IReadOnlyRepository<Data.Entities.Influencer> _influencerRepo;

        private readonly IStorageService _storageService;

        public Handler(ICurrentInfluencer currentInfluencer, IReadOnlyRepository<Influencer> influencerRepo,
            IStorageService storageService)
        {
            _currentInfluencer = currentInfluencer;
            _influencerRepo = influencerRepo;
            _storageService = storageService;
        }

        public async Task<InfluencerProfileDto> Handle(Query request, CancellationToken cancellationToken)
        {
            var influencerProfileSpec = new GetInfluencerProfileSpec(_currentInfluencer.InfluencerId);
            var profile = await _influencerRepo.SingleOrDefaultAsync(influencerProfileSpec, cancellationToken);

            if (profile is not null)
            {
                profile.ProfilePicUrl = _storageService.GetSignedUrl(profile.ProfilePicUrl);
            }

            return profile;
        }
    }
}
