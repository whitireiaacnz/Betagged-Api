﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Entities;

[Table("system_product_statuses_lut")]
public class SystemProductStatus
{
    public SystemProductStatus()
    {
        BrandProducts = new List<BrandProduct>();
    }

    public SystemProductStatusOption SystemProductStatusId { get; set; }

    [Required, MaxLength(16)]
    public string Name { get; set; }

    // Reverse Navigation
    public ICollection<BrandProduct> BrandProducts { get; set; }
}
