﻿namespace BeTagged.Core.Constants;

public static class BlacklistedEmailDomains
{
    public static readonly string[] BlacklistEmailDomains =
    {
        "gmail.com", "outlook.com", "hotmail.com", "yahoo.com", "aol.com", "aim.com", "yandex.com",
        "protonmail.com", "tutanota.com", "keemail.me", "tuta.io", "tutamail.com", "tuta.io", "icloud.com"
    };
}
