﻿using System;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetBrandOrganizationWithCategoriesSpec : ISingleResultQuerySpecification<BrandOrganization, BrandOrganization>
{
    public GetBrandOrganizationWithCategoriesSpec(int brandOrganizationId)
    {
        Query = q => q
            .Include(x => x.Categories)
            .Where(x => x.BrandOrganizationId == brandOrganizationId);
    }

    public Func<IQueryable<BrandOrganization>, IQueryable<BrandOrganization>> Query { get; }
}
