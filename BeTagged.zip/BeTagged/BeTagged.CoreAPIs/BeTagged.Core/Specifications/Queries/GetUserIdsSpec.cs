﻿using System;
using System.Threading;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetUserIdsSpec : IListResultQuerySpecification<User, int>
{
    public GetUserIdsSpec(IEnumerable<Guid> userKeys)
    {
        Query = async (q, ctx) => await q
            .Where(x => userKeys.Contains(x.UserKey))
            .Select(x => x.UserId).ToListAsync(ctx);
    }

    public Func<IQueryable<User>, CancellationToken, Task<IList<int>>> Query { get; }
}
