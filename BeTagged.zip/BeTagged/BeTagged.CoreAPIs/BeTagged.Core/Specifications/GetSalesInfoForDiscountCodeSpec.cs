﻿using System;
using BeTagged.Core.Dtos;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications;

public class GetSalesInfoForDiscountCodeSpec : ISingleResultQuerySpecification<BrandProductDiscountCode, SaleInfoForDiscountCodeDto>
{
    public GetSalesInfoForDiscountCodeSpec(int brandProductId, string discountCode, DateTime tillDateUtc)
    {
        Query = q => q
            .Include(x => x.BrandProduct)
            .Include(x => x.ProductPromotion)
            .Where(x => x.BrandProductId == brandProductId)
            .Where(x => x.DiscountCode == discountCode)
            .Where(x => x.ProductPromotion != null)
            .Select(x => new SaleInfoForDiscountCodeDto
            {
                BrandOrganizationId = x.BrandProduct.BrandOrganizationId,
                BrandProductId = x.BrandProductId,
                ProductPromotionId = x.ProductPromotion.ProductPromotionId,
                SalesChannel = x.ProductPromotion.SalesChannelId,
                NumberOfSales = x.ProductPromotion.ProductSales.Where(y => y.SoldAtUtc <= tillDateUtc)
                    .Sum(y => y.Quantity),
                SalesCountTillUtc = tillDateUtc,
                Price = x.BrandProduct.Price,
                CommissionPercentage = x.ProductPromotion.CommissionPercentage,
                InfluencerId = x.ProductPromotion.InfluencerId,
                InfluencerCommissionPercentage = x.ProductPromotion.InfluencerCommissionPercentage
            });
    }

    public Func<IQueryable<BrandProductDiscountCode>, IQueryable<SaleInfoForDiscountCodeDto>> Query { get; }
}
