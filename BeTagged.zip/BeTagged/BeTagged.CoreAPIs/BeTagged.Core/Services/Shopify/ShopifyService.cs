﻿using System;
using System.Globalization;
using System.Net.Http;
using System.Text;
using BeTagged.Common.Utils;
using BeTagged.Core.Configurations;
using BeTagged.Core.Dtos;
using BeTagged.Core.Services.ProductSales;
using BeTagged.Core.Services.Promotion;
using BeTagged.Core.Services.Storage;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;
//using EllipticCurve.Utils;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using ShopifySharp;

namespace BeTagged.Core.Services.Shopify;

public class ShopifyService : IShopifyService
{
    private static readonly JsonSerializerSettings JsonSerializerSettings;
    private readonly ShopifyConfiguration _shopifyConfiguration;
    private readonly IRepository<WebhookMappingDetail> _webhookMappingDetailRepository;
    private readonly IBtDb _db;
    private readonly IProductPromotionService _productPromotionService;
    private readonly IProductSalesService _productSaleService;
    private readonly ILogger _logger;
    private readonly IStorageService _storageService;
    private readonly IHttpClientFactory _httpClientFactory;

    static ShopifyService()
    {
        JsonSerializerSettings = new JsonSerializerSettings()
        {
            Converters = new List<JsonConverter>
            {
                new StringEnumConverter()
            }
        };
    }

    public ShopifyService(IOptions<ShopifyConfiguration> shopifyConfiguration, IRepository<WebhookMappingDetail> webhookMappingDetailRepository,
        IBtDb db, IProductPromotionService productPromotionService, ILogger<ShopifyService> logger, IProductSalesService productSaleService, IStorageService storageService, IHttpClientFactory httpClientFactory)
    {
        _shopifyConfiguration = shopifyConfiguration.Value;
        ProductService = new ProductService(_shopifyConfiguration.Url, _shopifyConfiguration.AccessToken);
        _webhookMappingDetailRepository = webhookMappingDetailRepository;
        _db = db;
        _productPromotionService = productPromotionService;
        _logger = logger;
        _productSaleService = productSaleService;
        _storageService = storageService;
        _httpClientFactory = httpClientFactory;
    }

    private ProductService ProductService { get; set; }

    public async Task<(long Id, string Url)> CreateProductAsync(AddBrandProductDto dto, Guid brandProductKey)
    {
        var shopifyProduct = new Product()
        {
            Title = dto.Name,
            BodyHtml = $"<strong>{dto.Description}</strong>",
            Images = new List<ProductImage>
            {
                new ProductImage
                {
                  Src = dto.BannerImageUrl
                }
            },
            Metafields = new List<MetaField>()
            {
                new MetaField()
                {
                    Key = "Brand",
                    Value = brandProductKey.ToString(),
                    Type = "single_line_text_field",
                    Namespace = "Product",
                    Description = "Unique Identifier"
                }
            },
        };

        shopifyProduct = await ProductService.CreateAsync(shopifyProduct);

        await CreateProductVariants(dto, shopifyProduct.Id.Value);

        var domainUrl = await GetShopDomain();
        var url = $"https://{domainUrl}/products/{shopifyProduct.Handle}";

        return (shopifyProduct.Id.Value, url);
    }

    public async Task UpdateProductAsync(BrandProduct brandProduct)
    {
        await ProductService.UpdateAsync(brandProduct.ShopifyProductId.Value, new Product()
        {
            Title = brandProduct.Name,
            BodyHtml = $"<strong>{brandProduct.Description}</strong>"
        });
    }

    public async Task<string> GetShopDomain()
    {
        var service = new ShopService(_shopifyConfiguration.Url, _shopifyConfiguration.AccessToken);

        var shop = await service.GetAsync();

        return shop.Domain;
    }

    public async Task SaveWebhookMappingDetails(string cartToken, string productionPromotionKey)
    {
        await _webhookMappingDetailRepository.AddAsync(new WebhookMappingDetail()
        {
            CartToken = cartToken,
            Key = productionPromotionKey
        });
        await _db.SaveChangesAsync();
    }

    public async Task<WebhookMappingDetail> GetWebhookMappingDetail(string cartToken)
    {
        var webhookMappingInfoSpec = new GetWebhookMappingDetailByCartTokenSpec(cartToken);
        var webhookMappingInfo = await _webhookMappingDetailRepository.SingleOrDefaultAsync(webhookMappingInfoSpec);

        return webhookMappingInfo;
    }

    public async Task SubscribeToWebhooksAsync()
    {
        var service = new WebhookService(_shopifyConfiguration.Url, _shopifyConfiguration.AccessToken);

        Webhook hook = new Webhook()
        {
            Address = _shopifyConfiguration.WebhookUrl,
            CreatedAt = DateTime.Now,
            Format = "json",
            MetafieldNamespaces = new List<string>() { "Product" },
            Topic = "orders/create",
        };

        try
        {
            await service.CreateAsync(hook);
        }
        catch (ShopifyException ex)
        {
            if (ex.Message != "(422 Unprocessable Entity) address: for this topic has already been taken")
            {
                _logger.LogError(ex, "Error while subscribing the shopify webhooks");
            }
        }
    }

    public async Task ShopifyWebhookEventHandler(string topic, dynamic payload)
    {
        if (topic == "orders/create")
        {
            await OrderCreateEvent(payload);
        }
    }

    private async Task CreateProductVariants(AddBrandProductDto dto, long id)
    {
        var variants = new List<ProductVariant>();
        var imageService = new ProductImageService(_shopifyConfiguration.Url, _shopifyConfiguration.AccessToken);

        foreach (var variant in dto.ProductIncommDetails.VariantDetails)
        {
            var image = await imageService.CreateAsync(id, new ProductImage()
            {
                Src = _storageService.GetSignedUrl(variant.ProductImageUrls.FirstOrDefault())
            });

            var productVariant = new ProductVariant()
            {
                Option1 = variant.Color,
                Option2 = variant.Size.ToString(),
                ImageId = image.Id.Value,
                InventoryQuantity = variant.OrderUnits,
                Price = dto.Price,
                FulfillmentService = "manual",
                InventoryPolicy = "deny"
            };
            variants.Add(productVariant);
        }

        var client = _httpClientFactory.CreateClient(HttpClients.Shopify);

        using (client)
        {
            var payload = new
            {
                product = new
                {
                    id,
                    options = new List<ProductOption>
                     {
                         new ProductOption
                         {
                             Name = "Color"
                         },
                         new ProductOption
                         {
                             Name = "Size"
                         }
                     },
                    variants
                }
            };

            var content = new StringContent(payload.Serialize(JsonSerializerSettings), Encoding.UTF8, ContentTypes.ApplicationJson);

            await client.PutAsync($"{id}.json", content);
        }
    }

    private async Task OrderCreateEvent(dynamic payload)
    {
        IEnumerable<dynamic> items = payload.line_items;
        if (!items.Any())
        {
            return;
        }

        var webhookMappingInfo = await GetWebhookMappingDetail((string)payload.cart_token);

        if (webhookMappingInfo is null)
        {
            _logger.LogError($"WebhookMappingInfo for cart token {payload.cart_token} is null.");
            return;
        }

        var promotionDetails = await _productPromotionService.GetProductPromotionByKey(webhookMappingInfo.Key);
        IEnumerable<dynamic> lineItems = payload.line_items;
        var influencerPromotedProducts = lineItems.Where(x => x.product_id == promotionDetails.BrandProduct.ShopifyProductId);
        var totalQuantity = influencerPromotedProducts.Sum(x => x.quantity);
        var parseStringPriceToDecimal = new List<decimal>();

        var totalPrice = influencerPromotedProducts.Select(x => decimal.Parse((string)x.price, CultureInfo.InvariantCulture)).Sum();

        // for (int i = 0; i < influencerPromotedProducts.Count(); i++)
        // {
        //     var priceInString = (string)influencerPromotedProducts.ElementAt(i).price;
        //     var price = decimal.Parse(priceInString, CultureInfo.InvariantCulture);
        //     parseStringPriceToDecimal.Add(price);
        // }

        // var totalPrice = parseStringPriceToDecimal.Sum();
        var dto = new AddProductSaleDto()
        {
            ProductPromotionId = promotionDetails.ProductPromotionId,
            BrandProductId = promotionDetails.BrandProductId,
            InfluencerId = promotionDetails.InfluencerId,
            BrandOrganizationId = promotionDetails.BrandProduct.BrandOrganizationId,
            SalesChannelId = promotionDetails.SalesChannelId,
            IsCommissionPaidOff = false,
            SoldAtUtc = DateTime.UtcNow,
            Quantity = totalQuantity,
            Price = totalPrice,
            CommissionPercentage = promotionDetails.BrandProduct.CommissionPercentage,
            InfluencerCommissionPercentage = promotionDetails.BrandProduct.InfluencerCommissionPercentage,
            SalesDataFileId = null,
            SalesSourceId = SystemSalesSourceOption.Incomm,
        };

        await _productSaleService.AddProductSaleAsync(dto);
    }
}
