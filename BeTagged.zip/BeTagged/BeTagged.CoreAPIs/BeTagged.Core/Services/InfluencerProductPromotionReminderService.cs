﻿using System;
using BeTagged.Core.Configurations;
using BeTagged.Core.Services.BackgroundWork;
using BeTagged.Core.Services.Notification;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;
using Microsoft.Extensions.Options;

namespace BeTagged.Core.Services;

internal class InfluencerProductPromotionReminderService : IInfluencerProductPromotionReminderService
{
    private readonly IBackgroundWorker _backgroundWorker;
    private readonly ScheduledJobsDurationConfiguration _configuration;
    private readonly IReadOnlyRepository<ProductPromotion> _productPromotionsReadonlyRepo;
    private readonly IReadOnlyRepository<ProductPromotionRequest> _productPromotionRequestReadonlyRepo;

    public InfluencerProductPromotionReminderService(IOptions<ScheduledJobsDurationConfiguration> configuration, IBackgroundWorker backgroundWorker,
        IReadOnlyRepository<ProductPromotion> productPromotionsReadonlyRepo, IReadOnlyRepository<ProductPromotionRequest> productPromotionRequestReadonlyRepo)
    {
        _configuration = configuration.Value;
        _backgroundWorker = backgroundWorker;
        _productPromotionsReadonlyRepo = productPromotionsReadonlyRepo;
        _productPromotionRequestReadonlyRepo = productPromotionRequestReadonlyRepo;
    }

    public void ScheduleJobToRemindInfluencerToPickProduct(int influencerId)
    {
        _backgroundWorker.Schedule(() => ScheduleJobToRemindInfluencerToPickProductInternal(influencerId, _configuration.HasNotPickedProductReminder1),
            TimeSpan.FromDays(_configuration.HasNotPickedProductReminder1));

        _backgroundWorker.Schedule(() => ScheduleJobToRemindInfluencerToPickProductInternal(influencerId, _configuration.HasNotPickedProductReminder2),
            TimeSpan.FromDays(_configuration.HasNotPickedProductReminder2));
    }

    // ReSharper disable once MemberCanBePrivate.Global
    public async Task ScheduleJobToRemindInfluencerToPickProductInternal(int influencerId,
        int daysWithoutPickingAProduct)
    {
        var isPromotingAnyProductSpec = new IsInfluencerPromotingAnyProductSpec(influencerId);
        var isPromotingAnyProduct = await _productPromotionsReadonlyRepo.AnyAsync(isPromotingAnyProductSpec);

        if (isPromotingAnyProduct)
        {
            return;
        }

        var hasRequestedForPromotionSpec = new HasInfluencerRequestForPromotionSpec(influencerId);
        var hasRequestedForPromotion = await _productPromotionRequestReadonlyRepo.AnyAsync(hasRequestedForPromotionSpec);

        if (hasRequestedForPromotion)
        {
            return;
        }

        _backgroundWorker.Enqueue<INotificationService>(x =>
            x.SendReminderForPickingAProductToInfluencerAsync(influencerId, daysWithoutPickingAProduct));
    }
}
