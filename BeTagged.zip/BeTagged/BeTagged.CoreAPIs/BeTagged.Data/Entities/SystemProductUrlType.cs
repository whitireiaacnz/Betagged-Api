﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Entities;

[Table("system_product_url_types_lut")]
public class SystemProductUrlType
{
    public SystemProductUrlType()
    {
        BrandProducts = new List<BrandProduct>();
    }

    public SystemProductUrlOption SystemProductUrlTypeId { get; set; }

    [Required, MaxLength(32)]
    public string Name { get; set; }

    // Reverse Navigation
    public ICollection<BrandProduct> BrandProducts { get; set; }
}
