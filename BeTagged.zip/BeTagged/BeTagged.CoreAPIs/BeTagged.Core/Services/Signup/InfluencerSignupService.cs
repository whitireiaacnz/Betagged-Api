﻿namespace BeTagged.Core.Services.Signup;
using System.Linq;
using System.Threading;
using BeTagged.Core.Commands.Signup;
using BeTagged.Core.Dtos;
using BeTagged.Core.Models;
using BeTagged.Core.Services.Otp;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Users;

internal class InfluencerSignupService : IInfluencerSignupService
{
    private readonly IBtDb _db;
    private readonly IAuthTokenService _authTokenService;
    private readonly IUserService _userService;
    private readonly IEmailOtpService _emailOtpService;
    private readonly IPhoneOtpService _phoneOtpService;
    private readonly ICompleteSignupReminderService _completeSignupReminderService;

    public InfluencerSignupService(IBtDb db, IAuthTokenService authTokenService,
        IUserService userService, IEmailOtpService emailOtpService, IPhoneOtpService phoneOtpService,
        ICompleteSignupReminderService completeSignupReminderService)
    {
        _db = db;
        _authTokenService = authTokenService;
        _userService = userService;
        _emailOtpService = emailOtpService;
        _phoneOtpService = phoneOtpService;
        _completeSignupReminderService = completeSignupReminderService;
    }

    public async Task<InfluencerSignup.Response> SignupInfluencerAsync(InfluencerSignup.Command command, CancellationToken cancellationToken)
    {
        var response = new InfluencerSignup.Response();

        var userCreationResult = await _userService.CreateUserAsync(new CreateUserDto()
        {
            Email = command.Email,
            Password = command.Password,
            UserType = SystemUserTypeOption.Influencer,
            CountryCode = command.CountryCode,
            Phone = command.Phone,
        });

        if (!userCreationResult.IsSuccess)
        {
            response.Error = userCreationResult.Error;
            response.ErrorMessage = userCreationResult.ErrorMessage;
            return response;
        }

        var user = userCreationResult.Data;
        var influencer = new Influencer() { User = user };
        var email = user.EmailAddresses.First();
        var phone = user.Phones.First();

        _db.Influencers.Add(influencer);

        await _db.SaveChangesAsync(cancellationToken);
        await _emailOtpService.GenerateAndSendEmailOtpAsync(email, SystemOtpUsageTypeOption.Verification);
        await _phoneOtpService.GenerateAndSendPhoneOtpAsync(phone, SystemOtpUsageTypeOption.Verification);

        var token = _authTokenService.GetTokenForInfluencer(influencer);

        _completeSignupReminderService.ScheduleCompleterSignupReminderJob(influencer.UserId);

        return new InfluencerSignup.Response()
        {
            AccessToken = token,

            InfluencerInfo = new InfluencerBasicInfo()
            {
                UserKey = user.UserKey,
                IsInfluencerOnBoarded = influencer.IsOnBoarded(),
                PrimaryEmailAddressId = email.EmailAddressId,
                PrimaryEmailAddress = email.EmailAddress_,
                IsEmailVerified = email.IsVerified,
                PrimaryPhoneId = phone.PhoneId,
                PrimaryPhone = phone.ToString(),
                IsPhoneVerified = phone.IsVerified
            }
        };
    }
}
