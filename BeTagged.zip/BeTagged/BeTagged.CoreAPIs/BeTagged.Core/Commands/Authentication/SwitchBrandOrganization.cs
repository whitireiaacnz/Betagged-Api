﻿using System.Threading;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Commands.Authentication;

public static class SwitchBrandOrganization
{
    public record Command(int BrandId) : IRequest<Response>;

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.BrandId).GreaterThan(0);
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IAuthenticationService _authenticationService;
        private readonly ICurrentBrandMember _currentBrandMember;

        public Handler(ICurrentBrandMember currentBrandMember, IAuthenticationService authenticationService)
        {
            _currentBrandMember = currentBrandMember;
            _authenticationService = authenticationService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var result = await
                _authenticationService.SwitchBrandOrganization(_currentBrandMember.BrandMemberId, request.BrandId);
            return result.Map<Response>();
        }
    }

    public class Response : Result<BrandMemberAuthenticationResponse>
    {
    }
}
