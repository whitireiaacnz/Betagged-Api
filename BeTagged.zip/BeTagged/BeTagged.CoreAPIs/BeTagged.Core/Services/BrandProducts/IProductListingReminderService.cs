﻿namespace BeTagged.Core.Services.BrandProducts;

public interface IProductListingReminderService
{
    void ScheduleProductListingReminderJob(int userId);
}
