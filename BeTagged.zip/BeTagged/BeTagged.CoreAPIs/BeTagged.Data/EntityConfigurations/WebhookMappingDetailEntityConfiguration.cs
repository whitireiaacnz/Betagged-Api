﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

public class WebhookMappingDetailEntityConfiguration : IEntityTypeConfiguration<WebhookMappingDetail>
{
    public void Configure(EntityTypeBuilder<WebhookMappingDetail> builder)
    {
        builder.HasKey(x => x.WebhookMappingDetailId);

        builder.Property(x => x.WebhookMappingDetailId)
            .UseIdentityAlwaysColumn();

        builder.HasIndex(x => x.CartToken).IsUnique();
    }
}
