﻿using System.Threading;
using BeTagged.Core.Dtos;
using BeTagged.Core.Services.Profile;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Queries.Profile;

public static class GetInfluencerBankAccounts
{
    public record Query() : IRequest<IEnumerable<InfluencerBankAccountDto>>;

    public class Handler : IRequestHandler<Query, IEnumerable<InfluencerBankAccountDto>>
    {
        private readonly ICurrentInfluencer _currentInfluencer;
        private readonly IInfluencerService _influencerService;

        public Handler(ICurrentInfluencer currentInfluencer, IInfluencerService influencerService)
        {
            _currentInfluencer = currentInfluencer;
            _influencerService = influencerService;
        }

        public async Task<IEnumerable<InfluencerBankAccountDto>> Handle(Query request, CancellationToken cancellationToken)
        {
            return await _influencerService.GetInfluencerBankAccountsAsync(_currentInfluencer.InfluencerId, cancellationToken);
        }
    }
}
