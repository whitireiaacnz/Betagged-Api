﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

internal class ProductPromotionEntityConfiguration : IEntityTypeConfiguration<ProductPromotion>
{
    public void Configure(EntityTypeBuilder<ProductPromotion> builder)
    {
        builder.HasKey(x => x.ProductPromotionId);

        builder.Property(x => x.ProductPromotionId)
            .UseIdentityAlwaysColumn();

        builder.HasOne(x => x.Influencer)
           .WithMany(x => x.ProductPromotions)
           .HasForeignKey(x => x.InfluencerId);

        builder.HasOne(x => x.SalesChannel)
           .WithMany(x => x.ProductPromotions)
           .HasForeignKey(x => x.SalesChannelId);

        builder.HasOne(x => x.BrandProduct)
           .WithMany(x => x.ProductPromotions)
           .HasForeignKey(x => x.BrandProductId);

        builder.HasOne(x => x.ProductPromotionRequest)
            .WithOne()
            .HasForeignKey<ProductPromotion>(x => x.ProductPromotionRequestId);

        builder.HasOne(x => x.ProductPromotionLink)
            .WithMany()
            .HasForeignKey(x => x.ProductPromotionLinkId);

        builder.HasOne(x => x.DiscountCode)
            .WithOne(x => x.ProductPromotion)
            .HasForeignKey<ProductPromotion>(x => x.DiscountCodeId);

        builder.Property(x => x.ProductPromotionKey)
            .HasColumnType("uuid")
            .HasDefaultValueSql("uuid_generate_v4()");

        builder.HasIndex(x => x.ProductPromotionKey).IsUnique();
    }
}
