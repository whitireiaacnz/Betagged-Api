﻿using System;
using BeTagged.Core.Configurations;
using BeTagged.Core.Services.BackgroundWork;
using BeTagged.Core.Services.Notification;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;
using Microsoft.Extensions.Options;

namespace BeTagged.Core.Services.Signup;

public interface ICompleteOnboardingReminderService
{
    void ScheduleCompleteOnboardingReminderJob(int userId, SystemUserTypeOption userType);
}

internal class CompleteOnboardingReminderService : ICompleteOnboardingReminderService
{
    private readonly IBackgroundWorker _backgroundWorker;
    private readonly ScheduledJobsDurationConfiguration _jobsDurationConfiguration;
    private readonly INotificationService _notificationService;
    private readonly IReadOnlyRepository<Influencer> _influencersReadonlyRepo;
    private readonly IReadOnlyRepository<BrandMember> _brandMembersReadonlyRepo;

    public CompleteOnboardingReminderService(IBackgroundWorker backgroundWorker,
        IOptions<ScheduledJobsDurationConfiguration> jobsDurationConfiguration,
        INotificationService notificationService,
        IReadOnlyRepository<Influencer> influencersReadonlyRepo, IReadOnlyRepository<BrandMember> brandMembersReadonlyRepo)
    {
        _backgroundWorker = backgroundWorker;
        _notificationService = notificationService;
        _influencersReadonlyRepo = influencersReadonlyRepo;
        _brandMembersReadonlyRepo = brandMembersReadonlyRepo;
        _jobsDurationConfiguration = jobsDurationConfiguration.Value;
    }

    public void ScheduleCompleteOnboardingReminderJob(int userId, SystemUserTypeOption userType)
    {
        _backgroundWorker.Schedule(() => SendCompleteOnboardingReminderNotificationAsync(userId, userType),
            TimeSpan.FromDays(_jobsDurationConfiguration.CompleteOnboardingReminderDelayInDays));
    }

    public async Task SendCompleteOnboardingReminderNotificationAsync(int userId, SystemUserTypeOption userType)
    {
        var isOnboarded = false;
        User user = null;

        if (userType == SystemUserTypeOption.Influencer)
        {
            var getInfluencerSpec = new GetInfluencerByUserIdSpec(userId);
            var influencer = await _influencersReadonlyRepo.SingleAsync(getInfluencerSpec);
            isOnboarded = influencer.IsOnBoarded();
            user = influencer.User;
        }

        if (userType == SystemUserTypeOption.BrandMember)
        {
            var getBrandMemberSpec = new GetBrandMemberByUserIdSpec(userId);
            var brandMember = await _brandMembersReadonlyRepo.SingleAsync(getBrandMemberSpec);
            isOnboarded = brandMember.IsOnboarded();
            user = brandMember.User;
        }

        if (isOnboarded)
        {
            return;
        }

        await _notificationService.SendCompleteOnboardingReminderNotificationAsync(user!.UserKey);
    }
}
