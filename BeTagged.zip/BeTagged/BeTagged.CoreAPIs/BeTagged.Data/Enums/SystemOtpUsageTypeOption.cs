﻿namespace BeTagged.Data.Enums;

[EnumLookupTable(typeof(SystemOtpUsageType))]
public enum SystemOtpUsageTypeOption : byte
{
    Verification = 1,
    Login = 2,
    PasswordReset = 3
}
