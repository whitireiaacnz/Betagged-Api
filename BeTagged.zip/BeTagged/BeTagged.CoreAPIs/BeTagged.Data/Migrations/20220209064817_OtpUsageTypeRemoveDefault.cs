﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class OtpUsageTypeRemoveDefault : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AlterColumn<byte>(
            name: "usage_type_id",
            schema: "public",
            table: "otps",
            type: "smallint",
            nullable: false,
            oldClrType: typeof(byte),
            oldType: "smallint",
            oldDefaultValue: (byte)1);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AlterColumn<byte>(
            name: "usage_type_id",
            schema: "public",
            table: "otps",
            type: "smallint",
            nullable: false,
            defaultValue: (byte)1,
            oldClrType: typeof(byte),
            oldType: "smallint");
    }
}
