﻿namespace BeTagged.Data.Entities;

public abstract class ShortenedLink : BaseEntity
{
    public int ShortenedLinkId { get; set; }

    public string Url { get; set; }

    public int ClickCount { get; set; }

    public int EntityId { get; set; }

    public virtual SystemShortenedLinkEntityTypeOption EntityTypeId { get; }

    public SystemShortenedLinkEntityType EntityType { get; set; }
}

public class ProductPromotionLink : ShortenedLink
{
    public override SystemShortenedLinkEntityTypeOption EntityTypeId =>
        SystemShortenedLinkEntityTypeOption.ProductPromotion;
}
