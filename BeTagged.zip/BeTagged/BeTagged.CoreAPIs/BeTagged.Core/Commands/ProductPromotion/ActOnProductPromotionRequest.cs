﻿using System.Threading;
using BeTagged.Core.CQRS;
using BeTagged.Core.Dtos;
using BeTagged.Core.Services.Promotion;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Commands.ProductPromotion;

public static class ActOnProductPromotionRequest
{
    public class Command : ITransactionalRequest<Response>
    {
        public int BrandProductId { get; set; }

        public int ProductPromotionRequestId { get; set; }

        public SystemApprovalStatusOption ApprovalStatus { get; set; }
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.ApprovalStatus).NotEqual(SystemApprovalStatusOption.Pending);
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IProductPromotionService _productPromotionService;
        private readonly ICurrentBrandMember _currentBrandMember;

        public Handler(IProductPromotionService productPromotionService, ICurrentBrandMember currentBrandMember)
        {
            _productPromotionService = productPromotionService;
            _currentBrandMember = currentBrandMember;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var dto = new ActOnProductPromotionRequestDto()
            {
                ProductPromotionRequestId = request.ProductPromotionRequestId,
                ActedByBrandMemberId = _currentBrandMember.BrandMemberId,
                BrandOrganizationId = _currentBrandMember.BrandOrganizationId,
                BrandProductId = request.BrandProductId,
                ApprovalStatus = request.ApprovalStatus,
                IsPeriodExpired = request.ApprovalStatus == SystemApprovalStatusOption.Rejected ? false : null
            };

            var result = await _productPromotionService.ActOnPromotionRequestAsync(dto, cancellationToken);
            return result.Map<Response>();
        }
    }

    public class Response : Result<ProductPromotionRequestDetails>
    {
    }
}
