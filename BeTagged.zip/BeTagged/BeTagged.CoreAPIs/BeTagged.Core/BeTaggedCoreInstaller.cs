﻿using System;
using System.Reflection;
using Amazon;
using Amazon.Runtime;
using Amazon.SQS;
using BeTagged.Common.Configurations;
using BeTagged.Common.Extensions;
using BeTagged.Core.Configurations;
using BeTagged.Core.CQRS.PipelineBehaviors;
using BeTagged.Core.Mapping;
using BeTagged.Core.Services;
using BeTagged.Core.Services.BackgroundWork;
using BeTagged.Core.Services.Brand;
using BeTagged.Core.Services.BrandProducts;
using BeTagged.Core.Services.CDP;
using BeTagged.Core.Services.Clevertap;
using BeTagged.Core.Services.Communication;
using BeTagged.Core.Services.GeoDb;
using BeTagged.Core.Services.Misc;
using BeTagged.Core.Services.Notification;
using BeTagged.Core.Services.Otp;
using BeTagged.Core.Services.ProductSales;
using BeTagged.Core.Services.Profile;
using BeTagged.Core.Services.Promotion;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Shopify;
using BeTagged.Core.Services.Signup;
using BeTagged.Core.Services.SocialMedia;
using BeTagged.Core.Services.Storage;
using BeTagged.Core.Services.UrlUtils;
using BeTagged.Core.Services.Users;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using AwsConfiguration = BeTagged.Core.Configurations.AwsConfiguration;

namespace BeTagged.Core;

public static class BeTaggedCoreInstaller
{
    public static IServiceCollection AddBeTaggedCoreModule(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddAutoMapper(x => x.AddProfile(new MappingProfile(Assembly.GetExecutingAssembly())));
        services.AddMediatr();
        services.AddHttpClientServices(configuration);
        services.AddValidatorsFromAssembly(Assembly.GetAssembly(typeof(BeTaggedCoreInstaller)));
        services.MapConfigToObjects(configuration);
        services.AddServicesToIoC();

        return services;
    }

    public static IServiceCollection AddHttpClientServices(this IServiceCollection services, IConfiguration configuration)
    {
        var shopifyConfig = configuration.GetSection(ShopifyConfiguration.Section)
            .Get<ShopifyConfiguration>();

        services.AddHttpClient(HttpClients.Shopify, c =>
        {
            c.BaseAddress = $"https://{shopifyConfig.Url}/admin/api/2022-07/products/".ToUri();
            c.DefaultRequestHeaders.Add("X-Shopify-Access-Token",
                shopifyConfig.AccessToken);
        });

        services.AddHttpClient(HttpClients.GeoDbCitiesApi, c =>
        {
            c.BaseAddress = configuration.GetValue<string>("GeoDbApiConfig:BaseAddress").ToUri();
            c.DefaultRequestHeaders.Add("x-rapidapi-host",
                configuration.GetValue<string>("GeoDbApiConfig:Host"));
            c.DefaultRequestHeaders.Add("x-rapidapi-key",
                configuration.GetValue<string>("GeoDbApiConfig:ApiKey"));
        }).SetHandlerLifetime(TimeSpan.FromMinutes(5));

        var btUrlShortenerConfig = configuration.GetSection(BtUrlShortenerConfiguration.Section)
            .Get<BtUrlShortenerConfiguration>();

        services.AddHttpClient(HttpClients.BtUrlShortener, c =>
        {
            c.BaseAddress = btUrlShortenerConfig.BaseUrl;
            c.DefaultRequestHeaders.Add("client-id", btUrlShortenerConfig.ClientId);
            c.DefaultRequestHeaders.Add("client-secret", btUrlShortenerConfig.ClientSecret);
        }).SetHandlerLifetime(TimeSpan.FromMinutes(5));

        var clevertapConfiguration = configuration.GetSection(ClevertapConfiguration.Section).Get<ClevertapConfiguration>();
        services.AddHttpClient(HttpClients.Clevertap, c =>
        {
            c.BaseAddress = "https://api.clevertap.com/1/events.json".ToUri();
            c.DefaultRequestHeaders.Add("X-CleverTap-Account-Id", clevertapConfiguration.ProjectId);
            c.DefaultRequestHeaders.Add("X-CleverTap-Passcode", clevertapConfiguration.Passcode);
        });

        return services;
    }

    private static IServiceCollection AddMediatr(this IServiceCollection services)
    {
        services.AddMediatR(typeof(BeTaggedCoreInstaller));

        // Pipeline behaviors
        services.AddTransient(typeof(IPipelineBehavior<,>), typeof(TransactionalBehavior<,>));

        return services;
    }

    private static IServiceCollection MapConfigToObjects(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddConfigurationOption<SecurityConfiguration>(configuration,
            SecurityConfiguration.Section);

        services.AddConfigurationOption<AwsConfiguration>(configuration, AwsConfiguration.Section);

        services.AddConfigurationOption<SendGridConfiguration>(configuration, SendGridConfiguration.Section);

        services.AddConfigurationOption<SendinBlueConfiguration>(configuration, SendinBlueConfiguration.Section);

        services.AddConfigurationOption<TwilioConfiguration>(configuration, TwilioConfiguration.Section);

        services.AddConfigurationOption<SmsConfiguration>(configuration, SmsConfiguration.Section);

        services.AddConfigurationOption<EmailConfiguration>(configuration, EmailConfiguration.Section);

        services.AddConfigurationOption<UrlConfiguration>(configuration, UrlConfiguration.Section);

        services.AddConfigurationOption<BtUrlShortenerConfiguration>(configuration,
            BtUrlShortenerConfiguration.Section);

        services.AddConfigurationOption<ScheduledJobsDurationConfiguration>(configuration,
            ScheduledJobsDurationConfiguration.Section);

        services.AddConfigurationOption<NotificationConfiguration>(configuration,
            NotificationConfiguration.Section);

        services.AddConfigurationOption<ShopifyConfiguration>(configuration, ShopifyConfiguration.Section);

        services.AddConfigurationOption<BetaggedApiConfiguration>(configuration, BetaggedApiConfiguration.Section);

        return services;
    }

    private static IServiceCollection AddServicesToIoC(this IServiceCollection services)
    {
        // Singleton
        services.AddSingleton<ITokenService, TokenService>();
        services.AddSingleton<IPasswordHasher, PasswordHasher>();
        services.AddSingleton<IAuthTokenService, AuthTokenService>();
        services.AddSingleton<IStorageService, S3StorageService>();
        services.AddSingleton<IEmailTransportService, SendinBlueEmailTransportService>();
        services.AddSingleton<IPhoneTransportService, TwilioTransportService>();
        services.AddSingleton<IPhoneService, PhoneService>();
        services.AddSingleton<IGeoDbService, GeoDbService>();
        services.AddSingleton<IExcelDataReaderService, ExcelDataReaderService>();
        services.AddSingleton<IUrlBuilder, UrlBuilder>();
        services.AddSingleton<IUrlShortenerService, BeTaggedUrlShortenerService>();
        services.AddSingleton<IAmazonSQS, AmazonSQSClient>(provider =>
        {
            var awsConfig = provider.GetRequiredService<IOptions<AwsConfiguration>>().Value;
            var awsCredentials = new BasicAWSCredentials(awsConfig.AccessKeyId, awsConfig.AccessKeySecret);
            return new AmazonSQSClient(awsCredentials, RegionEndpoint.APSoutheast1); // Singapore
        });
        services.AddSingleton<ICdpService, ClevertapService>();

        // Scoped
        services.AddScoped<IInfluencerSignupService, InfluencerSignupService>();
        services.AddScoped<IBrandSignupService, BrandSignupService>();
        services.AddScoped<IAuthenticationService, AuthenticationService>();
        services.AddScoped<IUserService, UserService>();
        services.AddScoped<IEmailOtpService, EmailOtpService>();
        services.AddScoped<IPhoneOtpService, PhoneOtpService>();
        services.AddScoped<IBrandMembershipService, BrandMembershipService>();
        services.AddScoped<IPasswordResetService, PasswordResetService>();
        services.AddScoped<IEmailService, EmailService>();
        services.AddScoped<IBackgroundWorker, HangfireBackgroundWorker>();
        services.AddScoped<IProductPromotionService, ProductPromotionService>();
        services.AddScoped<IProductSalesDbSeeder, ProductSalesDbSeeder>();
        services.AddScoped<IBrandProductService, BrandProductService>();
        services.AddScoped<IDiscountCodesImportService, DiscountCodesImportService>();
        services.AddScoped<ISalesDataImportService, SalesDataImportService>();
        services.AddScoped<IInfluencerService, InfluencerService>();
        services.AddScoped<IShopifyService, ShopifyService>();
        services.AddScoped<IProductSalesService, ProductSalesService>();
        services.AddScoped<ISaleDataUploadReminderService, SalesDataUploadReminderService>();
        services.AddScoped<ISocialMediaService, SocialMediaService>();
        services.AddScoped<INotificationService, NotificationService>();
        services.AddScoped<IInAppNotificationService, InAppNotificationService>();
        services.AddScoped<IProductListingReminderService, ProductListingReminderService>();
        services.AddScoped<IInfluencerProductPromotionReminderService, InfluencerProductPromotionReminderService>();
        services.AddScoped<ICompleteSignupReminderService, CompleteSignupReminderService>();
        services.AddScoped<ICompleteOnboardingReminderService, CompleteOnboardingReminderService>();

        return services;
    }
}
