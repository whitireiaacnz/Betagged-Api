﻿namespace BeTagged.Core.Enums;

public enum FileCategory : byte
{
    BrandProduct,
    Misc,
    User,
    Brand
}
