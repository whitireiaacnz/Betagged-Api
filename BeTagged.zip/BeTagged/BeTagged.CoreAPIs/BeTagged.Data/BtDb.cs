﻿using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using BeTagged.Data.Extensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace BeTagged.Data;

internal partial class BtDb : DbContext, IBtDb
{
    private static readonly IEnumerable<IInterceptor> PooledEmptyInterceptors = Enumerable.Empty<IInterceptor>();

    private readonly IEnumerable<IInterceptor> _interceptors;

    public BtDb(DbContextOptions<BtDb> options, IEnumerable<IInterceptor> dbInterceptors) : base(options)
    {
        _interceptors = dbInterceptors ?? PooledEmptyInterceptors;
        ChangeTracker.LazyLoadingEnabled = false;
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.AddInterceptors(_interceptors);
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        foreach (var foreignKey in modelBuilder.Model.GetEntityTypes().SelectMany(e => e.GetForeignKeys()))
        {
            foreignKey.DeleteBehavior = DeleteBehavior.Restrict;
        }

        modelBuilder.HasDefaultSchema("public");
        modelBuilder.HasPostgresExtension("postgis"); // to support spatial data
        modelBuilder.HasPostgresExtension("uuid-ossp");
        modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
        modelBuilder.ApplyGlobalQueryFilters();
    }
}
