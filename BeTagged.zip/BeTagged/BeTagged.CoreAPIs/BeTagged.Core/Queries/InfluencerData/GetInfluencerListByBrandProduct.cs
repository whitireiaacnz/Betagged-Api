﻿using System.Threading;
using BeTagged.Core.Dtos;
using BeTagged.Core.Queries.Shared;
using BeTagged.Core.Services.Storage;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Queries.InfluencerData;

public class GetInfluencerListByBrandProduct
{
    public class ODataQuery : ODataQueryBase, IRequest<PaginatedList<BrandProductInfluencerDto>>
    {
    }

    public class Query : ODataQuery
    {
        public int BrandProductId { get; set; }
    }

    public class Handler : IRequestHandler<Query, PaginatedList<BrandProductInfluencerDto>>
    {
        private readonly IReadOnlyRepository<Data.Entities.ProductPromotion> _productPromotionRepo;
        private readonly IStorageService _storageService;

        public Handler(IReadOnlyRepository<Data.Entities.ProductPromotion> productPromotionRepo, IStorageService storageService)
        {
            _productPromotionRepo = productPromotionRepo;
            _storageService = storageService;
        }

        public async Task<PaginatedList<BrandProductInfluencerDto>> Handle(Query request, CancellationToken cancellationToken)
        {
            var influencersByProductSpec = new GetInfluencerListByProductIdSpec(request.BrandProductId, request.Skip, request.Take);

            var influencerSalesResponse = await _productPromotionRepo
                .ListAsync(influencersByProductSpec, cancellationToken);

            foreach (var influencer in influencerSalesResponse)
            {
                influencer.InfluencerProfilePicUrl = _storageService.GetSignedUrl(influencer.InfluencerProfilePicUrl);
            }

            return new PaginatedList<BrandProductInfluencerDto>(influencerSalesResponse, request.Skip, request.Take);
        }
    }
}
