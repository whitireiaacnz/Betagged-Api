﻿using System;
using System.Threading;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetInfluencerUserKeysPromotingTheProductSpec : IListResultQuerySpecification<ProductPromotion, Guid>
{
    public GetInfluencerUserKeysPromotingTheProductSpec(int productId)
    {
        Query = async (q, ctx) => await q
            .Include(x => x.Influencer.User)
            .Where(x => x.BrandProductId == productId)
            .Select(x => x.Influencer.User.UserKey)
            .ToListAsync(ctx);
    }

    public Func<IQueryable<ProductPromotion>, CancellationToken, Task<IList<Guid>>> Query { get; }
}
