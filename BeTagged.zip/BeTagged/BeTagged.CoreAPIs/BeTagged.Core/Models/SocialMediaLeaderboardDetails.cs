﻿namespace BeTagged.Core.Models;
public class SocialMediaLeaderboardDetails
{
    public MediaPlatformInfo Instagram { get; set; }

    public MediaPlatformInfo Twitter { get; set; }

    public MediaPlatformInfo TikTok { get; set; }

    public MediaPlatformInfo Facebook { get; set; }

    public class MediaPlatformInfo
    {
        public int Sales { get; set; }

        public int Clicks { get; set; }

        public decimal Conversions { get; set; }
    }
}
