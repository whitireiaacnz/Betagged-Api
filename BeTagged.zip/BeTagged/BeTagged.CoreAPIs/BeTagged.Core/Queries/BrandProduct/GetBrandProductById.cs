﻿namespace BeTagged.Core.Queries.BrandProduct;

using System.Threading;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Storage;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;
using Microsoft.EntityFrameworkCore;

public static class GetBrandProductById
{
    public record Query(int Id) : IRequest<BrandProductDetailModel>;

    public class Handler : IRequestHandler<Query, BrandProductDetailModel>
    {
        private readonly ICurrentBrandMember _currentBrandMember;
        private readonly IStorageService _storageService;
        private readonly IReadOnlyRepository<Data.Entities.BrandProduct> _brandProductRepo;
        private readonly IReadOnlyBtDb _db;

        public Handler(ICurrentBrandMember currentBrandMember, IStorageService storageService,
            IReadOnlyRepository<Data.Entities.BrandProduct> brandProductRepo, IReadOnlyBtDb db, IReadOnlyRepository<ProductSale> productSaleRepo)
        {
            _currentBrandMember = currentBrandMember;
            _storageService = storageService;
            _brandProductRepo = brandProductRepo;
            _db = db;
        }

        public async Task<BrandProductDetailModel> Handle(Query request, CancellationToken cancellationToken)
        {
            var productDetailsSpec = new GetBrandProductDetailsForBrandMemberSpec(request.Id, _currentBrandMember.BrandOrganizationId);
            var product = await _brandProductRepo.SingleOrDefaultAsync(productDetailsSpec, cancellationToken);

            if (product is null)
            {
                return new BrandProductDetailModel() { ErrorMessage = ValidationMessages.ProductDoesNotExist, Error = ErrorType.ResourceNotFound };
            }

            product.SetProductUrls();

            if (product.BuyerDiscountPercentage > 0 || _currentBrandMember.BrandOrganizationId == BrandOrganizationIds.GrabOrgId)
            {
                var codeAllocation = await _db.BrandProductDiscountCodes
                    .Include(x => x.ProductPromotion)
                    .Where(x => x.BrandProductId == product.BrandProductId)
                    .GroupBy(x => x.BrandProductId)
                    .Select(x => new
                    {
                        TotalCodes = x.Count(),
                        ExhaustedCodes = x.Count(y => y.ProductPromotion != null)
                    }).SingleOrDefaultAsync(cancellationToken);

                product.DiscountCodesCount = codeAllocation?.TotalCodes ?? 0;
                product.ExhaustedDiscountCodesCount = codeAllocation?.ExhaustedCodes ?? 0;
            }

            product.SignTheUrls(_storageService);
            return product;
        }
    }
}
