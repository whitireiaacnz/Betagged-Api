﻿namespace BeTagged.Data.Entities;

public class BrandProductUrl
{
    public string CompanyProductUrl { get; set; }

    public string EcommercePlatformUrl { get; set; }
}
