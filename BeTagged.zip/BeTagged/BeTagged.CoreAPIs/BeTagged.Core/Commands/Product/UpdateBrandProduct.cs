﻿using System.Threading;
using BeTagged.Common.Extensions;
using BeTagged.Core.CQRS;
using BeTagged.Core.Dtos;
using BeTagged.Core.Services.BrandProducts;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Validators;

namespace BeTagged.Core.Commands.Product;

public static class UpdateBrandProduct
{
    public class Command : UpdateBrandProductDto, ITransactionalRequest<BrandProductModel>
    {
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.Name).NotEmpty();

            RuleFor(x => x.Description).NotEmpty()
                .MinimumLength(25)
                .MaximumLength(1024);

            RuleFor(x => x.BannerImageUrl).NotEmpty()
                .Must(x => x.IsUri())
                .WithMessage(ValidationMessages.LinkMustBeValidUri);

            RuleFor(x => x.ShowCaseMediaUrls).Must(x => x.Count() <= 6)
                .WithMessage("ShowCaseMediaUrls must have less than 6 items.");

            RuleForEach(x => x.ShowCaseMediaUrls).NotEmpty()
                .Must(x => x.IsUri())
                .WithMessage(ValidationMessages.LinkMustBeValidUri);

            RuleFor(x => x.SocialMediaKits).SetValidator(new BrandProductSocialMediaKitValidator());
        }
    }

    public class Handler : IRequestHandler<Command, BrandProductModel>
    {
        private readonly IBrandProductService _brandProductService;
        private readonly ICurrentBrandMember _currentBrandMember;

        public Handler(IBrandProductService brandProductService, ICurrentBrandMember currentBrandMember)
        {
            _brandProductService = brandProductService;
            _currentBrandMember = currentBrandMember;
        }

        public async Task<BrandProductModel> Handle(Command request, CancellationToken cancellationToken)
        {
            return await _brandProductService.UpdateBrandProductAsync(request, _currentBrandMember.BrandOrganizationId, cancellationToken);
        }
    }
}
