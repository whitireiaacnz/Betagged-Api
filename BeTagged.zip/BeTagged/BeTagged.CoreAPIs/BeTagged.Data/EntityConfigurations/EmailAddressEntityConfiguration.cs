﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

internal class EmailAddressEntityConfiguration : IEntityTypeConfiguration<EmailAddress>
{
    public void Configure(EntityTypeBuilder<EmailAddress> builder)
    {
        builder.Property(x => x.EmailAddressId).UseIdentityAlwaysColumn();

        builder.Property(x => x.EmailAddress_).HasColumnName("email_address").IsRequired();

        builder.Property(x => x.NormalizedEmailAddress).IsRequired()
            .HasComputedColumnSql("upper(email_address)", stored: true);

        builder.HasOne(x => x.User)
            .WithMany(x => x.EmailAddresses)
            .HasForeignKey(x => x.UserId);

        builder.HasIndex(x => x.EmailAddress_).IsUnique();
        builder.HasIndex(x => x.NormalizedEmailAddress).IsUnique();
    }
}
