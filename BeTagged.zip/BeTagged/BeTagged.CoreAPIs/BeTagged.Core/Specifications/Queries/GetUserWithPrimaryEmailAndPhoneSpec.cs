﻿using System;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetUserWithPrimaryEmailAndPhoneSpec : ISingleResultQuerySpecification<User, User>
{
    public GetUserWithPrimaryEmailAndPhoneSpec(int userId)
    {
        Query = q => q
            .Include(x => x.EmailAddresses.Where(e => e.IsPrimary))
            .Include(x => x.Phones.Where(p => p.IsPrimary))
            .Where(x => x.UserId == userId);
    }

    public Func<IQueryable<User>, IQueryable<User>> Query { get; }
}
