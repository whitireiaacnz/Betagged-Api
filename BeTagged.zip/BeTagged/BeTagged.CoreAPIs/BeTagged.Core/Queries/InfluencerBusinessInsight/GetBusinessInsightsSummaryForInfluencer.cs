﻿using System;
using System.Threading;
using BeTagged.Core.Services.Security;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Queries.InfluencerBusinessInsight;

public static class GetBusinessInsightsSummaryForInfluencer
{
    public class Query : IRequest<Response>
    {
        public DateTime? From { get; set; }

        public DateTime? To { get; set; }
    }

    public class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.From).LessThan(x => x.To).When(x => x.From is not null);
        }
    }

    public class Handler : IRequestHandler<Query, Response>
    {
        private readonly IReadOnlyBtDb _db;
        private readonly ICurrentInfluencer _currentInfluencer;

        public Handler(IReadOnlyBtDb db, ICurrentInfluencer currentInfluencer)
        {
            _db = db;
            _currentInfluencer = currentInfluencer;
        }

        public async Task<Response> Handle(Query request, CancellationToken cancellationToken)
        {
            var businessInsightsSummary = await _db.ProductSales
                        .Where(x => x.InfluencerId == _currentInfluencer.InfluencerId)
                        .Where(y => request.From == null || (y.SoldAtUtc >= request.From && y.SoldAtUtc <= request.To))
                        .GroupBy(x => x.InfluencerId)
                        .Select(x => new Response()
                        {
                            TotalSalesVolume = x.Sum(y => y.Quantity),
                            TotalSalesValue = x.Sum(y => y.TotalAmount),
                            CommissionEarned = x.Sum(y => y.InfluencerPayableCommission)
                        }).SingleOrDefaultAsync(cancellationToken);

            var influencer = await _db.Influencers
                .Include(x => x.Country)
                .Where(x => x.InfluencerId == _currentInfluencer.InfluencerId)
                .SingleAsync(cancellationToken);

            businessInsightsSummary ??= new Response();

            businessInsightsSummary.CurrencyCode = influencer.Country.CurrencyCode;
            businessInsightsSummary.CurrencySymbol = influencer.Country.CurrencySymbol;

            return businessInsightsSummary;
        }
    }

    public class Response
    {
        public int TotalSalesVolume { get; set; }

        public decimal TotalSalesValue { get; set; }

        public decimal CommissionEarned { get; set; }

        public string CurrencyCode { get; set; }

        public string CurrencySymbol { get; set; }
    }
}
