﻿namespace BeTagged.Core.Models;

public class BrandMemberAuthenticationResponse : Result
{
    public string AccessToken { get; set; }

    public BrandMemberAuthenticationInfo BrandMemberInfo { get; set; }
}
