﻿namespace BeTagged.Core.Dtos;

public class UserPhoneDto
{
    public int Id { get; set; }

    public string Phone { get; set; }

    public bool IsPrimary { get; set; }
}
