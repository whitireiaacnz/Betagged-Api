﻿namespace BeTagged.Core.Services.BrandProducts;

public interface ISaleDataUploadReminderService
{
    void ScheduleSalesDataUploadReminderJob(int brandProductId);

    Task SendSalesDataUploadReminderAsync(int brandProductId);
}
