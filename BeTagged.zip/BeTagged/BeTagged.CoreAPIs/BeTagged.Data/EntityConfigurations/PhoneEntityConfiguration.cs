﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

internal class PhoneEntityConfiguration : IEntityTypeConfiguration<Phone>
{
    public void Configure(EntityTypeBuilder<Phone> builder)
    {
        builder.Property(x => x.PhoneId).UseIdentityAlwaysColumn();

        builder.Property(x => x.PhoneNumber).IsRequired();
        builder.Property(x => x.CountryCode).IsRequired();

        builder.HasOne(x => x.User)
            .WithMany(x => x.Phones)
            .HasForeignKey(x => x.UserId);

        builder.HasIndex(x => new { x.PhoneNumber, x.CountryCode }).IsUnique();
    }
}
