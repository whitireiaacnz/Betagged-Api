﻿namespace BeTagged.Core.Dtos;

public class ActOnProductPromotionRequestsDto
{
    public int InfluencerId { get; set; }

    public IEnumerable<int> ProductPromotionRequestIds { get; set; }

    public int ActedByBrandMemberId { get; set; }

    public int BrandProductId { get; set; }

    public int BrandOrganizationId { get; set; }

    public SystemApprovalStatusOption ApprovalStatus { get; set; }
}
