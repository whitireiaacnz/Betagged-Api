﻿using BeTagged.Data.Constants;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

public class BrandProductDiscountCodeEntityConfiguration : IEntityTypeConfiguration<BrandProductDiscountCode>
{
    public void Configure(EntityTypeBuilder<BrandProductDiscountCode> builder)
    {
        builder.HasKey(x => x.BrandProductDiscountCodeId);

        builder.Property(x => x.BrandProductDiscountCodeId)
            .UseIdentityAlwaysColumn();

        builder.Property(x => x.DiscountCode)
            .IsRequired()
            .HasMaxLength(DbConstants.DiscountCodeLength);

        builder.HasOne(x => x.BrandProduct)
            .WithMany(x => x.DiscountCodes)
            .HasForeignKey(x => x.BrandProductId);

        builder.HasOne(x => x.DiscountCodesFile)
            .WithMany(x => x.DiscountCodes)
            .HasForeignKey(x => x.DiscountCodesFileId);

        builder.HasIndex(x => new { x.DiscountCode, x.BrandProductId })
            .IsUnique();
    }
}
