﻿using System.ComponentModel.DataAnnotations;

namespace BeTagged.Core.Queries.External;

using System.ComponentModel;
using System.Threading;
using System.Threading.Tasks;
using BeTagged.Core.Models;
using BeTagged.Core.Queries.Shared;
using BeTagged.Core.Services.GeoDb;
using MediatR;

public static class GetCities
{
    public class Query : ODataQueryBase, IRequest<PaginatedList<CityLookupItem>>
    {
        [MaxLength(2)]
        public string CountryIso2Code { get; set; }

        [DefaultValue(10)]
        public override int Take { get; set; }
    }

    public class Handler : IRequestHandler<Query, PaginatedList<CityLookupItem>>
    {
        private readonly IGeoDbService _geoDbService;

        public Handler(IGeoDbService geoDbService)
        {
            _geoDbService = geoDbService;
        }

        public async Task<PaginatedList<CityLookupItem>> Handle(Query request, CancellationToken cancellationToken)
        {
            if (request.Take > 10)
            {
                request.Take = 10;
            }

            return await _geoDbService.GetCitiesAsync(request.Skip, request.Take, request.Criteria, request.CountryIso2Code);
        }
    }
}
