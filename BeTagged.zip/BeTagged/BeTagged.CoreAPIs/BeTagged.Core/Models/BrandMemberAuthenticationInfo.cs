﻿using System;

namespace BeTagged.Core.Models;

public class BrandMemberAuthenticationInfo
{
    public BrandMemberAuthenticationInfo()
    {
        UserType = SystemUserTypeOption.BrandMember;
    }

    public Guid UserKey { get; set; }

    public bool IsUserOnBoarded { get; set; }

    public bool IsBrandOnBoarded { get; set; }

    public int PrimaryEmailAddressId { get; set; }

    public string PrimaryEmailAddress { get; set; }

    public bool IsEmailVerified { get; set; }

    public int PrimaryPhoneId { get; set; }

    public string PrimaryPhone { get; set; }

    public bool IsPhoneVerified { get; set; }

    public SystemUserTypeOption UserType { get; }

    public string FullName { get; set; }
}
