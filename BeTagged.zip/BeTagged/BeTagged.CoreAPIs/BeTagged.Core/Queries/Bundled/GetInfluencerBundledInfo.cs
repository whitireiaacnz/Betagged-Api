﻿using System;
using System.Threading;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Storage;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Queries.Bundled;

public static class GetInfluencerBundledInfo
{
    public record Query : IRequest<Response>;

    public class Handler : IRequestHandler<Query, Response>
    {
        private readonly IBtDb _db;
        private readonly ICurrentInfluencer _currentInfluencer;
        private readonly IStorageService _storageService;

        public Handler(ICurrentInfluencer currentInfluencer, IBtDb db, IStorageService storageService)
        {
            _currentInfluencer = currentInfluencer;
            _db = db;
            _storageService = storageService;
        }

        public async Task<Response> Handle(Query request, CancellationToken cancellationToken)
        {
            var response = await _db
                .Influencers
                .Include(x => x.User)
                .Include(x => x.Categories)
                .AsNoTracking()
                .Where(x => x.InfluencerId == _currentInfluencer.InfluencerId)
                .Select(x => new Response()
                {
                    UserKey = x.User.UserKey,
                    Name = x.User.Name,
                    ProfilePicUrl = x.User.ProfilePicPath,
                    Categories =
                            x.Categories.Select(y =>
                                new SystemCategoryLookupItem(y.SystemCategoryId, y.Name, y.CategoryGroupName))
                })
                .SingleAsync(cancellationToken);

            response.ProfilePicUrl = _storageService.GetSignedUrl(response.ProfilePicUrl);

            return response;
        }
    }

    public class Response
    {
        public Guid UserKey { get; set; }

        public string Name { get; set; }

        public string ProfilePicUrl { get; set; }

        public IEnumerable<SystemCategoryLookupItem> Categories { get; set; }
    }
}
