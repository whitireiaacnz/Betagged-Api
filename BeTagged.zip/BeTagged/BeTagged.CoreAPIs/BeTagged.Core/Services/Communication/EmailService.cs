﻿using System;
using BeTagged.Core.Dtos;
using BeTagged.Core.Services.BackgroundWork;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;

namespace BeTagged.Core.Services.Communication;

internal class EmailService : IEmailService
{
    private readonly IBtDb _db;
    private readonly IEmailTransportService _emailTransportService;
    private readonly IBackgroundWorker _backgroundWorker;

    public EmailService(IBtDb db, IEmailTransportService emailTransportService, IBackgroundWorker backgroundWorker)
    {
        _db = db;
        _emailTransportService = emailTransportService;
        _backgroundWorker = backgroundWorker;
    }

    public Task SendOtpEmailAsync(string emailAddress, string otp)
    {
        JObject dynamicData = new JObject();
        dynamicData.Add("OTP", otp);

        SendEmailDto sendEmailConfig = new()
        {
            SendEmail = EmailConstants.EmailFrom,
            TemplateId = EmailConstants.OtpEmailTemplateId,
            DynamicTemplateData = dynamicData
        };

        sendEmailConfig.AddRecipientEmail(emailAddress);

        _backgroundWorker.Enqueue(() => _emailTransportService.SendEmailAsync(sendEmailConfig));

        return Task.CompletedTask;
    }

    public async Task SendProductUnlistedEmailAsync(int brandOrganizationId, int brandProductId)
    {
        var influencerEmailAddresses = await GetInfluencerEmailsAsync(brandOrganizationId, brandProductId);

        if (!influencerEmailAddresses.Any())
        {
            return;
        }

        SendEmailDto sendEmailConfig = new()
        {
            SendEmail = EmailConstants.EmailFrom,
            TemplateId = EmailConstants.OtpEmailTemplateId,
        };

        sendEmailConfig.AddRecipientEmails(influencerEmailAddresses);

        _backgroundWorker.Enqueue(() => _emailTransportService.SendEmailAsync(sendEmailConfig));
    }

    public async Task SendWelcomeEmailAsync(string emailAddress)
    {
        var user = await GetUserByEmailAsync(emailAddress);

        var templateId = user.UserType switch
        {
            SystemUserTypeOption.BrandMember => EmailConstants.BrandWelcomeTemplateId,
            SystemUserTypeOption.Influencer => EmailConstants.InfluencerWelcomeTemplateId,
            _ => throw new ArgumentOutOfRangeException()
        };

        JObject dynamicData = new JObject
        {
            { "FIRSTNAME", user.Name }
        };

        SendEmailDto sendEmailConfig = new()
        {
            SendEmail = EmailConstants.EmailFrom,
            TemplateId = templateId,
            DynamicTemplateData = dynamicData
        };

        sendEmailConfig.AddRecipientEmail(emailAddress);

        _backgroundWorker.Enqueue(() => _emailTransportService.SendEmailAsync(sendEmailConfig));
    }

    public Task SendBrandMembershipInvitationToNewUserAsync(string emailAddress, string invitationLink)
    {
        JObject dynamicData = new JObject
        {
            { "INVITATIONLINK", invitationLink }
        };

        SendEmailDto sendEmailConfig = new()
        {
            SendEmail = EmailConstants.EmailFrom,
            TemplateId = EmailConstants.BrandSignupTemplateId,
            DynamicTemplateData = dynamicData
        };

        sendEmailConfig.AddRecipientEmail(emailAddress);

        _backgroundWorker.Enqueue(() => _emailTransportService.SendEmailAsync(sendEmailConfig));

        return Task.CompletedTask;
    }

    public Task SendBrandMembershipInvitationToExistingUserAsync(string emailAddress, string invitationLink)
    {
        JObject dynamicData = new JObject();
        dynamicData.Add("INVITATIONLINK", invitationLink);

        SendEmailDto sendEmailConfig = new()
        {
            SendEmail = EmailConstants.EmailFrom,
            TemplateId = EmailConstants.BrandInvitationTemplateId,
            DynamicTemplateData = dynamicData
        };

        sendEmailConfig.AddRecipientEmail(emailAddress);

        _backgroundWorker.Enqueue(() => _emailTransportService.SendEmailAsync(sendEmailConfig));

        return Task.CompletedTask;
    }

    public Task SendBradMemberRemovedFromBrandEmailAsync(string emailAddress, string brandName)
    {
        JObject dynamicData = new JObject();
        dynamicData.Add("BRANDNAME", brandName);

        SendEmailDto sendEmailConfig = new()
        {
            SendEmail = EmailConstants.EmailFrom,
            TemplateId = EmailConstants.MemberRemovalTemplateId,
            DynamicTemplateData = dynamicData
        };

        sendEmailConfig.AddRecipientEmail(emailAddress);

        _backgroundWorker.Enqueue(() => _emailTransportService.SendEmailAsync(sendEmailConfig));

        return Task.CompletedTask;
    }

    private async Task<User> GetUserByEmailAsync(string emailAddress)
    {
        var normalizedEmail = emailAddress.ToUpper();
        var user = await _db.EmailAddresses
            .AsNoTracking()
            .Include(x => x.User)
            .Where(x => x.NormalizedEmailAddress == normalizedEmail)
            .Select(x => x.User).SingleAsync();

        return user;
    }

    private async Task<IEnumerable<string>> GetInfluencerEmailsAsync(int brandOrganizationId, int brandProductId)
    {
        var emailAddresses = await _db.ProductPromotions
            .AsNoTracking()
            .Include(x => x.Influencer)
            .ThenInclude(x => x.User)
            .ThenInclude(x => x.EmailAddresses)
            .Where(x => x.BrandProductId == brandProductId)
            .Where(x => x.BrandProduct.BrandOrganizationId == brandOrganizationId)
            .Select(x => x.Influencer.User.EmailAddresses.Where(y => y.IsPrimary).First().EmailAddress_).Distinct().ToListAsync();

        return emailAddresses;
    }
}
