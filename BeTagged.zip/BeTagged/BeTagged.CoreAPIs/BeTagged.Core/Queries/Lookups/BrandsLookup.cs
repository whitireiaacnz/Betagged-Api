﻿using System.ComponentModel;
using System.Threading;
using BeTagged.Core.Queries.Shared;
using BeTagged.Core.Specifications.Queries.Lookups;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Queries.Lookups;

public static class BrandsLookup
{
    public class Query : ODataQueryBase, IRequest<PaginatedList<LookupItem>>
    {
        [DefaultValue(20)]
        public override int Take { get; set; }
    }

    public class Handler : IRequestHandler<Query, PaginatedList<LookupItem>>
    {
        private readonly IReadOnlyRepository<BrandOrganization> _brandOrganizationRepo;

        public Handler(IReadOnlyRepository<BrandOrganization> brandOrganizationRepo)
        {
            _brandOrganizationRepo = brandOrganizationRepo;
        }

        public async Task<PaginatedList<LookupItem>> Handle(Query request, CancellationToken cancellationToken)
        {
            if (request.Take > 20)
            {
                request.Take = 20;
            }

            var spec = new GetBrandOrganizationsLookupSpec(request.Criteria, request.Skip, request.Take);
            var result = await _brandOrganizationRepo.ListAsync(spec, cancellationToken);

            return new PaginatedList<LookupItem>(result, request.Skip, request.Take);
        }
    }
}
