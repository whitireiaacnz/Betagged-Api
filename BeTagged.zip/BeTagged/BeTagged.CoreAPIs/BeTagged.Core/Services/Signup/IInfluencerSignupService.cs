﻿using System.Threading;
using BeTagged.Core.Commands.Signup;

namespace BeTagged.Core.Services.Signup;

public interface IInfluencerSignupService
{
    Task<InfluencerSignup.Response> SignupInfluencerAsync(InfluencerSignup.Command command, CancellationToken cancellationToken);
}
