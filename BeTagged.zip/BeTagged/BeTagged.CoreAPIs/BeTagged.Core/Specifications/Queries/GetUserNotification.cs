﻿using System;
using BeTagged.Data.Specifications;

namespace BeTagged.Core.Specifications.Queries;

public class GetUserNotification : ISingleResultQuerySpecification<InAppNotification, InAppNotification>
{
    public GetUserNotification(int userId, int userNotificationId)
    {
        Query = q => q.Where(x => x.UserNotificationId == userNotificationId)
            .Where(x => x.UserId == userId);
    }

    public Func<IQueryable<InAppNotification>, IQueryable<InAppNotification>> Query { get; }
}
