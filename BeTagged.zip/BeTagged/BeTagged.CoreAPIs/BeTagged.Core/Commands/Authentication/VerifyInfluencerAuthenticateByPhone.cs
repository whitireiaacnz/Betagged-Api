﻿using System.Threading;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Commands.Authentication;

public static class VerifyInfluencerAuthenticateByPhone
{
    public record Command(string CountryCode, string Phone, string Otp) : IRequest<InfluencerAuthenticationResponse>;

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.CountryCode).NotEmpty();
            RuleFor(x => x.Phone).NotEmpty();
            RuleFor(x => x.Otp).NotEmpty();
        }
    }

    public class Handler : IRequestHandler<Command, InfluencerAuthenticationResponse>
    {
        private readonly IAuthenticationService _authenticationService;

        public Handler(IAuthenticationService authenticationService) => _authenticationService = authenticationService;

        public async Task<InfluencerAuthenticationResponse> Handle(Command request, CancellationToken cancellationToken)
            => await _authenticationService.AuthenticateInfluencerByPhoneAsync(request.CountryCode, request.Phone, request.Otp, cancellationToken);
    }
}
