﻿using System;
using System.Threading;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;
using BeTagged.Data.Services;

namespace BeTagged.Core.Queries.BrandBusinessInsight;

public static class GetBrandOrganizationBusinessInsights
{
    public class Query : IRequest<Response>
    {
        public byte CountryId { get; set; }

        public DateTime? From { get; set; }

        public DateTime? To { get; set; }
    }

    public class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.From).LessThan(x => x.To).When(x => x.From is not null);
            RuleFor(x => x.CountryId).GreaterThan((byte)0);
        }
    }

    public class Handler : IRequestHandler<Query, Response>
    {
        private readonly ICurrentBrandMember _currentBrandMember;
        private readonly IQueryService _queryService;
        private readonly IReadOnlyRepository<SystemCountry> _countriesRepository;

        public Handler(ICurrentBrandMember currentBrandMember, IQueryService queryService,
            IReadOnlyRepository<SystemCountry> countriesRepository)
        {
            _currentBrandMember = currentBrandMember;
            _queryService = queryService;
            _countriesRepository = countriesRepository;
        }

        public async Task<Response> Handle(Query request, CancellationToken cancellationToken)
        {
            var parameters = new
            {
                BrandOrganizationId = _currentBrandMember.BrandOrganizationId,
                FromDate = request.From,
                ToDate = request.To,
                CountrId = request.CountryId
            };

            var getCountrySpec = new GetCountrySpec(request.CountryId);
            var country = await _countriesRepository.SingleOrDefaultAsync(getCountrySpec, cancellationToken);

            if (country is null)
            {
                return new Response() { Error = ErrorType.ValidationError, ErrorMessage = "Country doesn't exists." };
            }

            var response = await _queryService.QueryFirstOrDefault<Response>(
                BtQueryType.GetBrandOrganizationBusinessInsightsSummary,
                null, parameters) ?? new Response();

            response.CurrencyCode = country.CurrencyCode;
            response.CurrencySymbol = country.CurrencySymbol;
            return response;
        }
    }

    public class Response : Result
    {
        public int TotalSalesVolume { get; set; }

        public decimal TotalSalesValue { get; set; }

        public decimal InfluencerCommission { get; set; }

        public string CurrencyCode { get; set; }

        public string CurrencySymbol { get; set; }
    }
}
