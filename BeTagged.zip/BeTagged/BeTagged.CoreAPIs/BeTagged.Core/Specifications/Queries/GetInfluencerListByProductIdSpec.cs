﻿using System;
using System.Threading;
using BeTagged.Core.Dtos;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetInfluencerListByProductIdSpec : IListResultQuerySpecification<ProductPromotion, BrandProductInfluencerDto>
{
    public GetInfluencerListByProductIdSpec(int brandProductId, int skip, int take)
    {
        Query = async (queryable, ct) => await queryable
                .Where(x => x.BrandProductId == brandProductId)
                    .Include(x => x.ProductPromotionLink)
                    .Include(x => x.ProductSales)
                    .Include(x => x.Influencer)
                    .ThenInclude(x => x.User)
                    .GroupBy(x => x.InfluencerId)
                    .Select(x => new BrandProductInfluencerDto()
                    {
                        InfluencerProfilePicUrl = x.First().Influencer.User.ProfilePicPath,
                        Name = x.First().Influencer.User.Name,
                        Sales = x.Sum(y => y.ProductSales.Sum(s => s.Quantity)),
                        Commission = x.Sum(y => y.ProductSales.Sum(s => s.InfluencerPayableCommission)),
                        CurrencySymbol = x.First().Influencer.Country.CurrencySymbol,
                        SalesChannelData = x.GroupBy(y => y.SalesChannelId)
                        .Select(y => new SalesChannelData()
                        {
                            SalesChannel = y.First().SalesChannelId,
                            ClickCount = y.First().ProductPromotionLink.ClickCount,
                            Link = y.First().ProductPromotionLink.Url,
                            Sale = y.First().ProductSales.Sum(s => s.Quantity),
                        })
                    }).Skip(skip).Take(take + 1).OrderByDescending(x => x.Sales).ToListAsync(ct);
    }

    public Func<IQueryable<ProductPromotion>, CancellationToken, Task<IList<BrandProductInfluencerDto>>> Query { get; }
}
