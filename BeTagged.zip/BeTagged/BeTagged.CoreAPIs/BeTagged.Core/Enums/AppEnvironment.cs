﻿namespace BeTagged.Core.Enums;

public enum AppEnvironment : byte
{
    Local,
    Development,
    Staging,
    Production
}
