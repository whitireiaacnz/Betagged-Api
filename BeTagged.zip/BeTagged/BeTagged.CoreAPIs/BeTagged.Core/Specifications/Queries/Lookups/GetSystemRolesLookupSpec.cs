﻿using System;
using System.Threading;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries.Lookups;

public class GetSystemRolesLookupSpec : IListResultQuerySpecification<SystemRole, LookupItem>
{
    public GetSystemRolesLookupSpec()
    {
        Query = async (q, ctx) => await q
            .Select(x => new LookupItem((int)x.SystemRoleId, x.Name))
            .ToListAsync(ctx);
    }

    public Func<IQueryable<SystemRole>, CancellationToken, Task<IList<LookupItem>>> Query { get; }
}
