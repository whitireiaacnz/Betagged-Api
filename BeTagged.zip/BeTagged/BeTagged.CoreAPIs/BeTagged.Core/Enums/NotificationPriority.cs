﻿namespace BeTagged.Core.Enums;

public enum NotificationPriority
{
    Default,
    High
}
