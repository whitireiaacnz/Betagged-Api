﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Entities;

[Table("system_in_app_notification_types_lut")]
public class SystemInAppNotificationType
{
    public SystemInAppNotificationType()
    {
        InAppNotifications = new List<InAppNotification>();
    }

    public SystemInAppNotificationTypeOption SystemInAppNotificationTypeId { get; set; }

    [Required]
    public string Name { get; set; }

    // Reverse navigation
    public ICollection<InAppNotification> InAppNotifications { get; set; }
}
