﻿using System.IO;
using System.Threading;
using BeTagged.Core.Dtos;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Storage;
using BeTagged.Core.Utils;

namespace BeTagged.Core.Commands.Files;

public static class FileUpload
{
    public record Command : IRequest<Response>
    {
        public Stream Stream { get; set; }

        public string ContentType { get; set; }

        public string FileName { get; set; }

        public FileCategory FileCategory { get; set; }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IStorageService _storageService;
        private readonly ICurrentUser _currentUser;

        public Handler(IStorageService storageService, ICurrentUser currentUser)
        {
            _storageService = storageService;
            _currentUser = currentUser;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var isAllowed = FileUtils.IsUserAuthorizedToUploadFile(request.FileCategory, _currentUser);

            var response = new Response();

            if (!isAllowed)
            {
                response.ErrorMessage =
                    $"You're not authorized to upload this file to '{request.FileCategory}' category";
                response.Error = ErrorType.InSufficientPermissions;
                return response;
            }

            var fileUpload = new FileUploadDto
            {
                Stream = request.Stream,
                Category = request.FileCategory,
                FileName = request.FileName,
                ContentType = request.ContentType
            };

            response.FileUrl = await _storageService.UploadFileAsync(fileUpload);
            return response;
        }
    }

    public class Response : Result
    {
        public string FileUrl { get; set; }
    }
}
