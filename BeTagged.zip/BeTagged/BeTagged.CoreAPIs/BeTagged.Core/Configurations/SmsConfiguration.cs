﻿using BeTagged.Core.Enums;

namespace BeTagged.Core.Configurations;

public class SmsConfiguration
{
    public const string Section = "SmsConfiguration";

    public SmsMode SmsMode { get; set; }
}
