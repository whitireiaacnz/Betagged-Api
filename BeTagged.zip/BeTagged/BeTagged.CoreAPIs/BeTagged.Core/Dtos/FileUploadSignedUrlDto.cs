﻿using BeTagged.Core.Enums;

namespace BeTagged.Core.Dtos;

public class FileUploadSignedUrlDto
{
    public long ContentLength { get; set; }

    public string ContentType { get; set; }

    public string FileName { get; set; }

    public FileCategory? Category { get; set; }
}
