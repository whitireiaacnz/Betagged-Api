﻿namespace BeTagged.Core.Services.Security;

public interface ICurrentBrandMember : ICurrentUser
{
    int BrandMemberId { get; }

    int BrandMembershipId { get; }

    SystemRoleOption Role { get; }

    int BrandOrganizationId { get; }
}
