﻿using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Attributes;

internal class JsonbColumnAttribute : ColumnAttribute
{
    public JsonbColumnAttribute()
    {
        TypeName = "jsonb";
    }
}
