﻿namespace BeTagged.Data.Enums;

[EnumLookupTable(typeof(SystemRole))]
public enum SystemRoleOption : byte
{
    Administrator = 1,
    Contributor = 2
}
