﻿using System;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetInfluencerByUserIdSpec : ISingleResultQuerySpecification<Influencer, Influencer>
{
    public GetInfluencerByUserIdSpec(int userId)
    {
        Query = q => q
            .Include(x => x.User)
            .Where(x => x.UserId == userId);
    }

    public Func<IQueryable<Influencer>, IQueryable<Influencer>> Query { get; }
}
