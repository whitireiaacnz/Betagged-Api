﻿using System.Threading;
using BeTagged.Core.Services.Brand;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Commands.BrandTeam;

public static class DeleteBrandMember
{
    public record Command(int Id) : IRequest;

    public class Handler(IBrandMembershipService brandMembershipService, ICurrentBrandMember currentBrandMember) : IRequestHandler<Command>
    {
        private readonly IBrandMembershipService _brandMembershipService = brandMembershipService;
        private readonly ICurrentBrandMember _currentBrandMember = currentBrandMember;

        public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
        {
            await _brandMembershipService.DeleteBrandMemberAsync(_currentBrandMember.BrandOrganizationId,
                request.Id);

            return default;
        }
    }
}
