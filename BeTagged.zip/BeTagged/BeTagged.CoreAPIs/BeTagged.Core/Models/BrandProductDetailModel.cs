﻿using System;
using AutoMapper;
using BeTagged.Core.Mapping;

namespace BeTagged.Core.Models;

public class BrandProductDetailModel : BrandProductModel, ICustomMap<BrandProduct, BrandProductDetailModel>
{
    public int TotalSales { get; set; }

    public decimal TotalSalesAmount { get; set; }

    public int TotalInfluencers { get; set; }

    public decimal PayableCommission { get; set; }

    public int? DiscountCodesCount { get; set; }

    public int? ExhaustedDiscountCodesCount { get; set; }

    public DateTime? SalesDataLastUploadedAtUtc { get; set; }

    public DateTime? SalesAllowedTillUtc => UnlistedAtUtc?.AddDays(5);

    public DateTime? UnlistedAtUtc { get; set; }

    public decimal PlatformCommissionPercentage { get; set; }

    public decimal InfluencerCommissionPercentage { get; set; }

    public void ConfigureMap(IMappingExpression<BrandProduct, BrandProductDetailModel> mapping)
    {
        mapping.IncludeBase<BrandProduct, BrandProductModel>();
    }
}
