﻿using System;
using BeTagged.Core.Configurations;
using BeTagged.Core.Services.BackgroundWork;
using BeTagged.Core.Services.Notification;
using BeTagged.Core.Services.UrlUtils;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;
using Microsoft.Extensions.Options;

namespace BeTagged.Core.Services.BrandProducts;

internal class SalesDataUploadReminderService : ISaleDataUploadReminderService
{
    private readonly IReadOnlyRepository<BrandProduct> _brandProductsRepo;
    private readonly IBackgroundWorker _backgroundWorker;
    private readonly IUrlBuilder _urlBuilder;
    private readonly INotificationService _notificationService;
    private readonly ScheduledJobsDurationConfiguration _scheduledJobDelays;

    public SalesDataUploadReminderService(IReadOnlyRepository<BrandProduct> brandProductsRepo,
        IBackgroundWorker backgroundWorker, IUrlBuilder urlBuilder, INotificationService notificationService,
        IOptions<ScheduledJobsDurationConfiguration> scheduledJobDelays)
    {
        _brandProductsRepo = brandProductsRepo;
        _backgroundWorker = backgroundWorker;
        _urlBuilder = urlBuilder;
        _notificationService = notificationService;
        _scheduledJobDelays = scheduledJobDelays.Value;
    }

    public void ScheduleSalesDataUploadReminderJob(int brandProductId)
    {
        _backgroundWorker.Schedule<ISaleDataUploadReminderService>(x =>
                x.SendSalesDataUploadReminderAsync(brandProductId), DateTime.UtcNow.AddDays(_scheduledJobDelays.SalesDataUploadReminderDurationInDays));
    }

    public async Task SendSalesDataUploadReminderAsync(int brandProductId)
    {
        var brandProductSpec = new GetBrandProductByIdWithUserSpec(brandProductId);
        var brandProduct = await _brandProductsRepo.SingleOrDefaultAsync(brandProductSpec);

        if (brandProduct is null || brandProduct.ProductStatusId != SystemProductStatusOption.Listed)
        {
            return;
        }

        // TODO: handle the scenarios when the User that created the brand product is deactivated.
        if (brandProduct.SalesDataLastUploadedAtUtc is null)
        {
            SendSalesDataUploadReminder(brandProductId, brandProduct.CreatedByUser.UserKey, brandProduct.Name);
            ScheduleJob(brandProductId, DateTime.UtcNow.AddDays(_scheduledJobDelays.SalesDataUploadReminderDurationInDays));
            return;
        }

        var lastSalesDataUploadedAtUtc = brandProduct.SalesDataLastUploadedAtUtc;
        var uploadDifferenceInDays = (DateTime.UtcNow - lastSalesDataUploadedAtUtc.Value).Days;

        // if the difference between last upload date and current ts is less than delay.
        // That means user has already uploaded the sales data.
        // So, we will reschedule the job after (lasSalesDataUploadDate + ScheduleDelay)
        if (uploadDifferenceInDays <= _scheduledJobDelays.SalesDataUploadReminderDurationInDays)
        {
            ScheduleJob(brandProductId, lastSalesDataUploadedAtUtc.Value.AddDays(_scheduledJobDelays.SalesDataUploadReminderDurationInDays));
            return;
        }

        // else the difference is >= Scheduled delay.
        // That means that user still hasn't uploaded the sales data even after sending the reminder.
        SendSalesDataUploadReminder(brandProductId, brandProduct.CreatedByUser.UserKey, brandProduct.Name);
        ScheduleJob(brandProductId, DateTime.UtcNow.AddDays(_scheduledJobDelays.SalesDataUploadReminderDurationInDays));
    }

    private void SendSalesDataUploadReminder(int brandProductId, Guid userKey, string productName)
    {
        var brandProductUrl = _urlBuilder.BuildProductDetailsUrl(brandProductId);
        _notificationService.SendSalesDataNeedsToBeUploadedNotification(userKey, brandProductUrl, brandProductId, productName);
    }

    private void ScheduleJob(int brandProductId, DateTime delay)
        => _backgroundWorker.Schedule<ISaleDataUploadReminderService>(x
            => x.SendSalesDataUploadReminderAsync(brandProductId), delay);
}
