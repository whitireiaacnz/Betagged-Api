﻿namespace BeTagged.Core.Models;

public class BtUrlShortenerEventModel
{
    public string Url { get; set; }
}

public class BtUrlShortenerEventModelValidator : AbstractValidator<BtUrlShortenerEventModel>
{
    public BtUrlShortenerEventModelValidator() => RuleFor(x => x.Url).NotEmpty();
}
