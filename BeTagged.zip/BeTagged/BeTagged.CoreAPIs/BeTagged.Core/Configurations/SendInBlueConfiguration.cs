﻿namespace BeTagged.Core.Configurations;

public class SendinBlueConfiguration
{
    public const string Section = "SendinBlue";

    public string ApiKey { get; set; }
}
