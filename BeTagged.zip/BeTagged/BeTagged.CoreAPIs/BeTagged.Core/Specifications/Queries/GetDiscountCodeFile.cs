﻿using System;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetDiscountCodeFile : ISingleResultQuerySpecification<BrandProductDiscountCodesFile, BrandProductDiscountCodesFile>
{
    public GetDiscountCodeFile(int id)
    {
        Query = queryable => queryable
            .Include(x => x.BrandProduct)
            .Where(x => x.BrandProductDiscountCodesFileId == id);
    }

    public Func<IQueryable<BrandProductDiscountCodesFile>, IQueryable<BrandProductDiscountCodesFile>> Query { get; }
}
