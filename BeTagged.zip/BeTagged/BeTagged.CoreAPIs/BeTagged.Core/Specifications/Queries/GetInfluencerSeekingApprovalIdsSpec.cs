﻿using System;
using System.Threading;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetInfluencerSeekingApprovalIdsSpec : IListResultQuerySpecification<ProductPromotionRequest, int>
{
    public GetInfluencerSeekingApprovalIdsSpec(int brandOrganizationId, int brandProductId, int skip, int take)
    {
        Query = async (queryable, ct) => await queryable
            .Where(x => x.BrandProductId == brandProductId
                        && x.ApprovalStatusId == SystemApprovalStatusOption.Pending
                        && x.BrandOrganizationId == brandOrganizationId)
            .GroupBy(p => p.InfluencerId)
            .Select(x => x.First().InfluencerId)
            .Skip(skip)
            .Take(take + 1)
            .ToListAsync(ct);
    }

    public Func<IQueryable<ProductPromotionRequest>, CancellationToken, Task<IList<int>>> Query { get; }
}
