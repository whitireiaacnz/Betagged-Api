﻿namespace BeTagged.Core.Services.BrandProducts;

public interface IDiscountCodesImportService
{
    Task ImportDiscountCodesAsync(int discountCodeFileId);

    Task<Result<bool>> ValidateDiscountCodesFileAsync(string url);
}
