﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class PasswordResetTokenTable : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(
            name: "password_reset_tokens",
            schema: "public",
            columns: table => new
            {
                password_reset_token_id = table.Column<int>(type: "integer", nullable: false)
                    .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                token = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false),
                valid_till_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                user_id = table.Column<int>(type: "integer", nullable: false),
                created_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                modified_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                is_deleted = table.Column<bool>(type: "boolean", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_password_reset_tokens", x => x.password_reset_token_id);
                table.ForeignKey(
                    name: "fk_password_reset_tokens_users_user_id",
                    column: x => x.user_id,
                    principalSchema: "public",
                    principalTable: "users",
                    principalColumn: "user_id",
                    onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateIndex(
            name: "ix_password_reset_tokens_token",
            schema: "public",
            table: "password_reset_tokens",
            column: "token",
            unique: true);

        migrationBuilder.CreateIndex(
            name: "ix_password_reset_tokens_user_id",
            schema: "public",
            table: "password_reset_tokens",
            column: "user_id");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable(
            name: "password_reset_tokens",
            schema: "public");
    }
}
