﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

internal class UserEntityConfiguration : IEntityTypeConfiguration<User>
{
    public void Configure(EntityTypeBuilder<User> builder)
    {
        builder.HasKey(x => x.UserId);

        builder.Property(x => x.UserId)
            .UseIdentityAlwaysColumn();

        builder.Property(x => x.UserType).IsRequired();

        builder.Property(x => x.PasswordHash).IsRequired();

        builder.Property(x => x.Salt).IsRequired();

        builder.HasOne(x => x.SystemUserType)
            .WithMany(x => x.Users)
            .HasForeignKey(x => x.UserType);

        builder.Property(x => x.UserKey)
            .HasColumnType("uuid")
            .HasDefaultValueSql("uuid_generate_v4()");

        builder.HasIndex(x => x.UserKey).IsUnique();
    }
}
