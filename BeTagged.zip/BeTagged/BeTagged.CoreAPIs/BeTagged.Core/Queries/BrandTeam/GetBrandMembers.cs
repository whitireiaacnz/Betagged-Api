﻿using System.Threading;
using BeTagged.Core.Dtos;
using BeTagged.Core.Queries.Shared;
using BeTagged.Core.Services.Security;
using BeTagged.Data.Services;
using Newtonsoft.Json;

namespace BeTagged.Core.Queries.BrandTeam;

public static class GetBrandMembers
{
    public class Query : ODataQueryBase, IRequest<PaginatedList<Response>>
    {
        public bool OnlyIncludeActiveMembers { get; set; }
    }

    public class Handler : IRequestHandler<Query, PaginatedList<Response>>
    {
        private readonly ICurrentBrandMember _currentBrandMember;
        private readonly IQueryService _queryService;

        public Handler(ICurrentBrandMember currentBrandMember, IQueryService queryService)
        {
            _currentBrandMember = currentBrandMember;
            _queryService = queryService;
        }

        public async Task<PaginatedList<Response>> Handle(Query request, CancellationToken cancellationToken)
        {
            var queryParams = new
            {
                @BrandOrganizationId = _currentBrandMember.BrandOrganizationId,
                @Skip = request.Skip,
                @Take = request.Take,
                @Criteria = request.Criteria,
                @OnlyIncludeActiveMembers = request.OnlyIncludeActiveMembers
            };

            var result = await _queryService.QueryAsync<Response>(BtQueryType.GetBrandMembers,
                null, queryParams);

            if (result.Any())
            {
                return new PaginatedList<Response>(result[0].TotalCount, result, request.Skip, request.Take);
            }

            return new PaginatedList<Response>(0, result, request.Skip, request.Take);
        }
    }

    public class Response : BrandMembershipInvitationResponseDto
    {
        [JsonIgnore]
        public int TotalCount { get; set; }
    }
}
