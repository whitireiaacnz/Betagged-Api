﻿using System;
using BeTagged.Common.Utils;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Services.ProductSales;

public class ProductSalesDbSeeder : IProductSalesDbSeeder
{
    private readonly IBtDb _db;
    private readonly IRepository<BrandProduct> _brandProductRepository;

    public ProductSalesDbSeeder(IBtDb db, IRepository<BrandProduct> brandProductRepository)
    {
        _db = db;
        _brandProductRepository = brandProductRepository;
    }

    public async Task SeedProductSalesAsync(int productPromotionId, int brandOrganizationId, int brandProductId, int influencerId, SystemSalesChannelOption salesChannel)
    {
        List<ProductSale> sales = new();

        var getBrandProductSpec = new GetBrandProductByIdSpec(brandOrganizationId, brandProductId);

        var product = await _brandProductRepository.SingleAsync(getBrandProductSpec);

        DateTime randomDate;

        DateTime start;

        for (int i = 0; i < 150; i++)
        {
            if (i < 50)
            {
                start = DateTime.UtcNow.AddDays(-90);
            }
            else if (i < 100)
            {
                start = DateTime.UtcNow.AddDays(-180);
            }
            else
            {
                start = DateTime.UtcNow.AddDays(-30);
            }

            int range = (DateTime.UtcNow - start).Days;
            randomDate = start.AddDays(ThreadSafeRandom.Next(range));

            ProductSale productSale = new()
            {
                ProductPromotionId = productPromotionId,
                BrandProductId = product.BrandProductId,
                InfluencerId = influencerId,
                BrandOrganizationId = product.BrandOrganizationId,
                SalesChannelId = salesChannel,
                IsCommissionPaidOff = true,
                SoldAtUtc = randomDate,
            };

            productSale.SetSalesInfo(product.Price, 1, product.CommissionPercentage, product.InfluencerCommissionPercentage, SystemSalesSourceOption.SalesDataImport);

            sales.Add(productSale);
        }

        _db.ProductSales.AddRange(sales);

        await _db.SaveChangesAsync();
    }
}
