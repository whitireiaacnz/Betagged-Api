﻿using System;
using BeTagged.Core.Enums;

namespace BeTagged.Core.Configurations;

public class AppConfiguration
{
    private static AppConfiguration _appConfiguration = null;

    public AppConfiguration(string applicationName, string contentPath, AppEnvironment environment, AppServiceType appServiceType)
    {
        ApplicationName = applicationName;
        ContentPath = contentPath;
        Environment = environment;
        AppServiceType = appServiceType;
    }

    public static AppConfiguration AppConfig
    {
        get => _appConfiguration;

        set
        {
            if (value is null)
            {
                throw new InvalidOperationException("Value can't be null");
            }

            _appConfiguration = _appConfiguration is null
                ? value
                : throw new InvalidOperationException($"{nameof(AppConfig)} can only be assign once");
        }
    }

    public string ApplicationName { get; }

    public string ContentPath { get; }

    public AppEnvironment Environment { get; }

    public AppServiceType AppServiceType { get; }

    public bool IsLocalEnvironment => Environment == AppEnvironment.Local;

    public bool IsDevelopmentEnvironment => Environment == AppEnvironment.Development;

    public bool IsProductionEnvironment => Environment == AppEnvironment.Production;
}
