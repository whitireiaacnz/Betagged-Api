﻿namespace BeTagged.Data.Enums;

public enum ImportStatus : byte
{
    Queued = 1,
    InProgress = 2,
    Completed = 3,
    Failed = 4
}
