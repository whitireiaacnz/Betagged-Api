﻿using System;
using System.Text;
using BeTagged.Common.Utils;

namespace BeTagged.Core.Utils;

public static class OtpUtil
{
    public static string GenerateRandomOTP(int otpLength, string[] allowedCharacters)
    {
        StringBuilder bld = new StringBuilder();

        string tempChars = String.Empty;

        for (int i = 0; i < otpLength; i++)
        {
            ThreadSafeRandom.Next(0, allowedCharacters.Length);

            tempChars = allowedCharacters[ThreadSafeRandom.Next(0, allowedCharacters.Length)];

            bld.Append(tempChars);
        }

        return bld.ToString();
    }
}
