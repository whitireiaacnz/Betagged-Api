﻿using System;
using BeTagged.Core.Configurations;
using BeTagged.Core.Services.BackgroundWork;
using BeTagged.Core.Services.Notification;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;
using Microsoft.Extensions.Options;

namespace BeTagged.Core.Services.Signup;

internal class CompleteSignupReminderService : ICompleteSignupReminderService
{
    private readonly IBackgroundWorker _backgroundWorker;
    private readonly INotificationService _notificationService;
    private readonly ScheduledJobsDurationConfiguration _scheduledJobsDuration;
    private readonly IReadOnlyRepository<User> _usersReadonlyRepo;

    public CompleteSignupReminderService(IBackgroundWorker backgroundWorker, INotificationService notificationService,
        IOptions<ScheduledJobsDurationConfiguration> scheduledJobsDuration, IReadOnlyRepository<User> usersReadonlyRepo)
    {
        _backgroundWorker = backgroundWorker;
        _notificationService = notificationService;
        _usersReadonlyRepo = usersReadonlyRepo;
        _scheduledJobsDuration = scheduledJobsDuration.Value;
    }

    public void ScheduleCompleterSignupReminderJob(int userId)
    {
        _backgroundWorker.Schedule(() => SendCompleteSignupReminderNotificationAsync(userId),
            TimeSpan.FromDays(_scheduledJobsDuration.CompleteSignupReminderDelayInDays));
    }

    public async Task SendCompleteSignupReminderNotificationAsync(int userId)
    {
        var getUserSpec = new GetUserWithPrimaryEmailAndPhoneSpec(userId);
        var user = await _usersReadonlyRepo.SingleAsync(getUserSpec);

        var email = user.EmailAddresses.First();

        if (email.IsVerified)
        {
            return;
        }

        await _notificationService.SendCompleteSignupReminderNotificationAsync(user.UserKey);
    }
}
