﻿using System.Threading;
using BeTagged.Core.Services.Profile;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Commands.Profile;

public static class SetBankAccountPrimary
{
    public record Command(int Id) : IRequest<Response>;

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IInfluencerService _influencerService;

        private readonly ICurrentInfluencer _currentInfluencer;

        public Handler(IInfluencerService influencerService, ICurrentInfluencer currentInfluencer)
        {
            _influencerService = influencerService;
            _currentInfluencer = currentInfluencer;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            Result response = await _influencerService.SetPrimaryBankAccount(request.Id, _currentInfluencer.InfluencerId);

            return response.Map<Response>();
        }
    }

    public class Response : Result
    {
    }
}
