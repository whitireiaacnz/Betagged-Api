﻿using System.IO;
using System.Threading;
using BeTagged.Common.Extensions;
using BeTagged.Core.Dtos;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Storage;
using BeTagged.Core.Utils;

namespace BeTagged.Core.Commands.Files;

public static class FileUploadSignedUrl
{
    public record Command : IRequest<Response>
    {
        public Command()
        {
        }

        public string FileName { get; set; }

        public long ContentLength { get; set; }

        public string ContentType { get; set; }

        public FileCategory? FileCategory { get; set; }
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.FileName)
                .NotEmpty()
                .Must(x => Path.GetFileName(x).IsNotNullOrEmpty())
                .WithMessage("FileName must have a valid extension.");
            RuleFor(x => x.ContentLength).GreaterThan(0);
            RuleFor(x => x.ContentType).NotEmpty();
            RuleFor(x => x.FileCategory).NotNull();
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly ICurrentUser _currentUser;
        private readonly IStorageService _storageService;

        public Handler(ICurrentUser currentUser, IStorageService storageService)
        {
            _currentUser = currentUser;
            _storageService = storageService;
        }

        public Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var isAllowed = FileUtils.IsUserAuthorizedToUploadFile(request.FileCategory.Value, _currentUser);

            var response = new Response();

            if (!isAllowed)
            {
                response.ErrorMessage =
                    $"You're not authorized to upload this file to '{request.FileCategory}' category";
                response.Error = ErrorType.InSufficientPermissions;
                return Task.FromResult(response);
            }

            var signedUrlDto = new FileUploadSignedUrlDto()
            {
                FileName = request.FileName,
                Category = request.FileCategory,
                ContentType = request.ContentType,
                ContentLength = request.ContentLength
            };

            response.FileUrl = _storageService.GetUploadSignedUrl(signedUrlDto);
            return Task.FromResult(response);
        }
    }

    public class Response : Result
    {
        public string FileUrl { get; set; }
    }
}
