﻿using System.Reflection;
using Amazon;
using Amazon.Extensions.NETCore.Setup;
using Amazon.Runtime;
using BeTagged.Common.Configurations;
using BeTagged.Common.Extensions;
using Microsoft.Extensions.Configuration;

namespace BeTagged.Common.Utils;

public static class AppConfigurationBuilder
{
    public static IConfiguration Build(Assembly assembly, string envName = "", string basePath = "")
    {
        IConfigurationBuilder configBuilder = new ConfigurationBuilder();

        if (basePath.IsNotNullOrEmpty())
        {
            configBuilder = configBuilder.SetBasePath(basePath);
        }

        configBuilder = configBuilder.AddJsonFile("appsettings.Common.json", true, true)
            .AddJsonFile($"appsettings.Common.{envName}.json", true, true)
            .AddJsonFile("appsettings.json", true, true)
            .AddJsonFile($"appsettings.{envName}.json", true, true)
            .AddUserSecrets(assembly, true, true)
            .AddEnvironmentVariables();

        var intermediateConfig = configBuilder.Build();
        var awsConfig = intermediateConfig.GetSection(AwsConfiguration.Section).Get<AwsConfiguration>();

        if (awsConfig.AccessKeyId.IsNotNullOrEmpty() && awsConfig.AccessKeySecret.IsNotNullOrEmpty())
        {
            var awsOptions = new AWSOptions
            {
                Region = RegionEndpoint.APSoutheast1,
                Credentials = new BasicAWSCredentials(awsConfig.AccessKeyId, awsConfig.AccessKeySecret)
            };

            configBuilder = configBuilder.AddSystemsManager($"/betagged-core-apis/{envName}", awsOptions, true);
        }

        configBuilder = configBuilder.AddEnvironmentVariables();

        return configBuilder.Build();
    }

    public static IConfiguration Build<T>(string envName = "", string basePath = "")
    {
        var assembly = Assembly.GetAssembly(typeof(T));

        if (assembly is null)
        {
            throw new InvalidOperationException("No Assembly found this type");
        }

        return Build(assembly, envName, basePath);
    }
}
