﻿using System;
using BeTagged.Core.Dtos;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetBrandMemberProfileSpec : ISingleResultQuerySpecification<BrandMember, BrandMemberProfileDto>
{
    public GetBrandMemberProfileSpec(int brandMembershipId, int brandMemberId)
    {
        Query = queryable => queryable
                .Include(x => x.User)
                .ThenInclude(x => x.EmailAddresses)
                .Include(x => x.User)
                .ThenInclude(x => x.Phones)
                .Include(x => x.BrandMemberships.Where(x => x.BrandMembershipId == brandMembershipId))
                .Where(x => x.BrandMemberId == brandMemberId)
                .Select(x => new BrandMemberProfileDto()
                {
                    ProfilePicUrl = x.User.ProfilePicPath,
                    MemberSince = x.BrandMemberships.First().CreatedAtUtc,
                    EmailAddresses = x.User.EmailAddresses.Select(y => new UserEmailAddressDto()
                    {
                        Id = y.EmailAddressId,
                        EmailAddress = y.EmailAddress_,
                        IsPrimary = y.IsPrimary
                    }),
                    Phones = x.User.Phones.Select(y => new UserPhoneDto()
                    {
                        Id = y.PhoneId,
                        Phone = $"{y.CountryCode}-{y.PhoneNumber}",
                        IsPrimary = y.IsPrimary
                    }),
                    Role = x.BrandMemberships.First().RoleId
                });
    }

    public Func<IQueryable<BrandMember>, IQueryable<BrandMemberProfileDto>> Query { get; }
}
