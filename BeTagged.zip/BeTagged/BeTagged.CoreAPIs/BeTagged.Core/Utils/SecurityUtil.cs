﻿using System;
using System.Security.Cryptography;

namespace BeTagged.Core.Utils;

public static class SecurityUtil
{
    public static string GenerateSalt(int length)
    {
        var saltBytes = RandomNumberGenerator.GetBytes(length);
        return Convert.ToBase64String(saltBytes)[..length];
    }
}
