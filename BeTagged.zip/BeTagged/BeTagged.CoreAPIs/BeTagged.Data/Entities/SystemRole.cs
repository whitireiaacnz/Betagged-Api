﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Entities;

[Table("system_roles_lut")]
public class SystemRole
{
    public SystemRole()
    {
        BrandMemberships = new List<BrandMembership>();
        BrandMembershipInvitations = new List<BrandMembershipInvitation>();
    }

    public SystemRoleOption SystemRoleId { get; set; }

    [Required, MaxLength(16)]
    public string Name { get; set; }

    // Reverse navigation
    public ICollection<BrandMembership> BrandMemberships { get; set; }

    public ICollection<BrandMembershipInvitation> BrandMembershipInvitations { get; set; }
}
