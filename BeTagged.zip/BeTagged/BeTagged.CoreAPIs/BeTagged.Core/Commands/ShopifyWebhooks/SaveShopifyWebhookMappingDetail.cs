﻿using System.Threading;
using BeTagged.Core.Services.Shopify;

namespace BeTagged.Core.Commands.ShopifyWebhooks;

public static class SaveShopifyWebhookMappingDetail
{
    public record Command(string CartToken, string Key) : IRequest<Response>;

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IShopifyService _shopifyService;

        public Handler(IShopifyService shopifyService)
        {
            _shopifyService = shopifyService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            await _shopifyService.SaveWebhookMappingDetails(request.CartToken, request.Key);
            return new Response();
        }
    }

    public class Response
    {
    }
}
