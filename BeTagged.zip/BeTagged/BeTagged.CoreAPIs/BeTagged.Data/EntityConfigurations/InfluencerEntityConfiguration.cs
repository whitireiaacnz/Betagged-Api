﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

internal class InfluencerEntityConfiguration : IEntityTypeConfiguration<Influencer>
{
    public void Configure(EntityTypeBuilder<Influencer> builder)
    {
        builder.HasKey(x => x.InfluencerId);

        builder.Property(x => x.InfluencerId)
            .UseIdentityAlwaysColumn();

        builder.Property(x => x.City).HasMaxLength(126);

        builder.HasOne(x => x.User)
            .WithOne()
            .HasForeignKey<Influencer>(x => x.UserId);

        builder.HasMany(x => x.Categories)
            .WithMany(x => x.Influencers)
            .UsingEntity<Dictionary<string, object>>("influencer_categories",
                j => j.HasOne<SystemCategory>().WithMany().HasForeignKey("system_category_id"),
                j => j.HasOne<Influencer>().WithMany().HasForeignKey("influencer_id"));

        builder.HasOne(x => x.Country)
            .WithMany(x => x.Influencers)
            .HasForeignKey(x => x.CountryId);
    }
}
