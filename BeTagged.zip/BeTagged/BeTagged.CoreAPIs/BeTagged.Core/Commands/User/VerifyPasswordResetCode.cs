﻿using System.Threading;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Commands.User;

public static class VerifyPasswordResetCode
{
    public record Command(string Email, string Code, SystemUserTypeOption? UserType) : IRequest<Response>;

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.Email).NotEmpty().EmailAddress();
            RuleFor(x => x.Code).NotEmpty();
            RuleFor(x => x.UserType).NotEmpty();
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IPasswordResetService _passwordResetService;

        public Handler(IPasswordResetService passwordResetService) => _passwordResetService = passwordResetService;

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var verificationResult = await _passwordResetService.VerifyResetCode(request.Email, request.Code, request.UserType!.Value);

            var response = new Response();

            if (!verificationResult.IsSuccess)
            {
                response.Error = verificationResult.Error;
                response.ErrorMessage = verificationResult.ErrorMessage;
                return response;
            }

            response.PasswordResetToken = verificationResult.Data;
            return response;
        }
    }

    public class Response : Result
    {
        public string PasswordResetToken { get; set; }
    }
}
