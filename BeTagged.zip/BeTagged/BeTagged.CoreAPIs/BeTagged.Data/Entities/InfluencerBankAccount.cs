﻿using BeTagged.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(InfluencerBankAccountEntityConfiguration))]
public class InfluencerBankAccount : BaseEntity
{
    public int InfluencerBankAccountId { get; set; }

    public string AccountName { get; set; }

    public string AccountNumber { get; set; }

    public string BankName { get; set; }

    public string Branch { get; set; }

    public byte CountryId { get; set; }

    public string SwiftCode { get; set; }

    public string Address { get; set; }

    public int InfluencerId { get; set; }

    public bool IsPrimary { get; set; }

    // Foreign Keys
    public SystemCountry Country { get; set; }

    public Influencer Influencer { get; set; }
}
