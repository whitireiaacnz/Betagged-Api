﻿using AutoMapper;
using BeTagged.Core.Mapping;

namespace BeTagged.Core.Models;

public class Category : ICustomMap<SystemCategory, Category>
{
    public short Id { get; set; }

    public string Name { get; set; }

    public void ConfigureMap(IMappingExpression<SystemCategory, Category> mapping)
    {
        mapping.ForMember(x => x.Id,
            o => o.MapFrom(x => x.SystemCategoryId));
    }
}
