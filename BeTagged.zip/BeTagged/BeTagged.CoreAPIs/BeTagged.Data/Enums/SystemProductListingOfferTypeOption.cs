﻿namespace BeTagged.Data.Enums;

public enum SystemProductListingOfferTypeOption : byte
{
    Open = 1,
    ApprovalBased = 2,
}
