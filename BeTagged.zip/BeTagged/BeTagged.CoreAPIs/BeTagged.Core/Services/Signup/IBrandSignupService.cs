﻿using BeTagged.Core.Commands.Signup;

namespace BeTagged.Core.Services.Signup;

public interface IBrandSignupService
{
    Task<BrandSignup.Response> SignupBrandAsync(BrandSignup.Command command);
}
