﻿using BeTagged.Core.Dtos;

namespace BeTagged.Core.Services.Brand;

public interface IBrandMembershipService
{
    Task<BrandMembership> AddBrandMembershipAsync(int brandMemberId, int brandOrganizationId, int invitedByMemberId,
        SystemRoleOption role, BrandMembershipInvitation invitation = null);

    Task<Result<BrandMembershipInvitationResponseDto>> AddBrandMemberAsync(AddBrandMemberDto dto);

    Task DeleteBrandMemberAsync(int brandOrganizationId, int id);
}
