﻿using System;
using System.Reflection;
using System.Runtime.Serialization;
using AutoMapper;

namespace BeTagged.Core.Mapping;

internal class MappingProfile : Profile
{
    private static readonly Type Map = typeof(IMap<,>);
    private static readonly Type CustomMap = typeof(ICustomMap<,>);

    public MappingProfile(Assembly assembly) => CreateMappingsFromAssembly(assembly);

    private void CreateMappingsFromAssembly(Assembly assembly)
    {
        var mappableTypes = assembly.GetExportedTypes()
            .Where(t => t.GetInterfaces().Any(i => i.IsGenericType
                                                   && (i.GetGenericTypeDefinition() == Map
                                                       || i.GetGenericTypeDefinition() == CustomMap)
                                                   && t.IsClass));

        var createMap = typeof(Profile).GetMethod(nameof(CreateMap), 2, Array.Empty<Type>())!;

        Parallel.ForEach(mappableTypes, type =>
        {
            // Not a good approach to create a instance like this.
            // However, this will work for our case until 'abstract static' interface methods rolls out as general feature.
            var instance = FormatterServices.GetUninitializedObject(type);

            var simpleMappings = type.GetInterfaces()
                .Where(i => i.IsGenericType && (i.GetGenericTypeDefinition() == Map));

            Parallel.ForEach(simpleMappings, map =>
            {
                var mappingTypes = map.GetGenericArguments();
                createMap.MakeGenericMethod(mappingTypes).Invoke(this, null);
            });

            var customMappings = type.GetMethods().Where(x => x.Name == nameof(ICustomMap<object, object>.ConfigureMap));

            Parallel.ForEach(customMappings, method =>
            {
                var requiredParams = method.GetParameters();
                var mappingTypes = requiredParams[0].ParameterType.GenericTypeArguments;
                var configureMap = createMap.MakeGenericMethod(mappingTypes).Invoke(this, null);
                method.Invoke(instance, new[] { configureMap });
            });
        });
    }
}
