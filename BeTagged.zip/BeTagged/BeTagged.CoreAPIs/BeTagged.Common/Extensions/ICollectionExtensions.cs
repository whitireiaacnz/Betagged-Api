﻿namespace BeTagged.Common.Extensions;

public static class ICollectionExtensions
{
    public static void AddRange<T>(this ICollection<T> collection, IEnumerable<T> source)
    {
        foreach (T item in source)
        {
            collection.Add(item);
        }
    }
}
