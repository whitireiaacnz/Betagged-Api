﻿namespace BeTagged.Data.Entities;

public interface IUserEntity
{
    public int CreatedByUserId { get; set; }

    public int ModifiedByUserId { get; set; }

    public User CreatedByUser { get; set; }

    public User ModifiedByUser { get; set; }
}
