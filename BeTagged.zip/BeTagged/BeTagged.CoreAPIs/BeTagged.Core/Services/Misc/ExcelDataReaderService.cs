﻿using System.Data;
using System.IO;
using System.Net.Http;
using BeTagged.Common.Extensions;
using BeTagged.Core.Extensions;
using ExcelDataReader;

namespace BeTagged.Core.Services.Misc;

internal class ExcelDataReaderService : IExcelDataReaderService
{
    private readonly IHttpClientFactory _httpClientFactory;

    public ExcelDataReaderService(IHttpClientFactory httpClientFactory)
    {
        _httpClientFactory = httpClientFactory;
        System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
    }

    /// <summary>
    /// Returns the header of the excel file.
    /// </summary>
    /// <param name="path">directory file path or url of the the excel file</param>
    /// <returns></returns>
    public async Task<DataSet> GetHeaderDataSetAsync(string path)
    {
        var fileStream = await GetExcelFileStream(path);
        await using (fileStream)
        {
            using var reader = ExcelReaderFactory.CreateReader(fileStream);
            reader.Read();
            return reader.AsDataSet();
        }
    }

    public async Task<DataSet> GetExcelDataSetAsync(string path)
    {
        var fileStream = await GetExcelFileStream(path);

        await using (fileStream)
        {
            using var reader = ExcelReaderFactory.CreateReader(fileStream);
            while (reader.Read())
            {
                // Do nothing
            }

            return reader.AsDataSet();
        }
    }

    private async Task<Stream> GetExcelFileStream(string path)
    {
        Stream fileSteam;

        if (path.IsUri())
        {
            fileSteam = await _httpClientFactory.CreateClient().GetFileStream(path);
        }
        else
        {
            fileSteam = File.Open(path, FileMode.Open, FileAccess.Read);
        }

        return fileSteam;
    }
}
