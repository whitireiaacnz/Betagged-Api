﻿namespace BeTagged.Core.Constants;

public static class BrandOrganizationIds
{
    public const int GrabOrgId = 809;
}
