﻿using System;
using System.Threading;
using BeTagged.Common.Extensions;
using BeTagged.Common.Utils;
using BeTagged.Core.Configurations;
using BeTagged.Core.Dtos;
using BeTagged.Core.Enums;
using BeTagged.Core.Exceptions;
using BeTagged.Core.Services.BackgroundWork;
using BeTagged.Core.Services.Notification;
using BeTagged.Core.Services.SocialMedia;
using BeTagged.Core.Services.Storage;
using BeTagged.Core.Services.UrlUtils;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace BeTagged.Core.Services.Promotion;

public class ProductPromotionService : IProductPromotionService
{
    private readonly IBtDb _db;
    private readonly IUrlShortenerService _urlShortenerService;
    private readonly IReadOnlyRepository<Influencer> _influencersRepo;
    private readonly IStorageService _storageService;
    private readonly IRepository<ProductPromotionRequest> _promotionRequestRepository;
    private readonly IBackgroundWorker _backgroundWorker;
    private readonly ScheduledJobsDurationConfiguration _scheduledJobsDurations;
    private readonly IRepository<ProductPromotion> _promotionRepository;
    private readonly IRepository<Influencer> _influencerRepository;
    private readonly ISocialMediaService _socialMediaService;
    private readonly IRepository<BrandProduct> _brandProductsRepo;
    private readonly IReadOnlyRepository<BrandMembership> _brandMembershipReadRepo;
    private readonly IUrlBuilder _urlBuilder;
    private readonly INotificationService _notificationService;

    public ProductPromotionService(IBtDb db, IUrlShortenerService urlShortenerService, IReadOnlyRepository<Influencer> influencersRepo,
        IStorageService storageService, IRepository<ProductPromotionRequest> promotionRequestRepository,
        IBackgroundWorker backgroundWorker, IOptions<ScheduledJobsDurationConfiguration> scheduledJobsDurations,
        IRepository<ProductPromotion> promotionRepository, IRepository<Influencer> influencerRepository, ISocialMediaService socialMediaService,
        IRepository<BrandProduct> brandProductsRepo, IReadOnlyRepository<BrandMembership> brandMembershipReadRepo, IUrlBuilder urlBuilder,
        INotificationService notificationService)
    {
        _db = db;
        _urlShortenerService = urlShortenerService;
        _influencersRepo = influencersRepo;
        _storageService = storageService;
        _promotionRequestRepository = promotionRequestRepository;
        _backgroundWorker = backgroundWorker;
        _scheduledJobsDurations = scheduledJobsDurations.Value;
        _promotionRepository = promotionRepository;
        _influencerRepository = influencerRepository;
        _socialMediaService = socialMediaService;
        _brandProductsRepo = brandProductsRepo;
        _brandMembershipReadRepo = brandMembershipReadRepo;
        _urlBuilder = urlBuilder;
        _notificationService = notificationService;
    }

    public async Task<Result<ProductPromotionDetails>> CreatePromotionAsync(int brandProductId, SystemSalesChannelOption salesChannelId, int influencerId, BrandProduct product, CancellationToken cancellationToken)
    {
        var isHandleValid = await CheckIfHandleExistForSalesChannelAsync(salesChannelId, influencerId);

        if (!isHandleValid.IsSuccess)
        {
            return isHandleValid;
        }

        Result<ProductPromotionDetails> result;

        if (product.IsApprovalBasedOffer)
        {
            result = await CreateProductPromotionRequestAsync(brandProductId, salesChannelId, influencerId, product, cancellationToken);
        }
        else
        {
            result = await CreateProductPromotionAsync(brandProductId, salesChannelId, influencerId, product, cancellationToken);
        }

        return result;
    }

    public async Task<Result<ProductPromotionRequestDetails>> ActOnPromotionRequestAsync(ActOnProductPromotionRequestDto actOnPromotionRequestDto,
        CancellationToken cancellationToken)
    {
        var response = new Result<ProductPromotionRequestDetails>();

        var promotionRequest = await _db.ProductPromotionRequests
            .Include(x => x.BrandProduct)
            .Include(x => x.Influencer.User)
            .Where(x => x.ProductPromotionRequestId == actOnPromotionRequestDto.ProductPromotionRequestId)
            .Where(x => x.BrandOrganizationId == actOnPromotionRequestDto.BrandOrganizationId)
            .Where(x => x.BrandProductId == actOnPromotionRequestDto.BrandProductId)
            .SingleOrDefaultAsync(cancellationToken);

        if (promotionRequest is null)
        {
            response.Error = ErrorType.ValidationError;
            response.ErrorMessage = "Promotion request doesn't exists.";
            return response;
        }

        if (promotionRequest.ApprovalStatusId != SystemApprovalStatusOption.Pending)
        {
            response.Error = ErrorType.ValidationError;
            response.ErrorMessage = $"You've already {promotionRequest.ApprovalStatusId} this request.";
            return response;
        }

        promotionRequest.IsRejectedDueToPeriodExpiration = actOnPromotionRequestDto.IsPeriodExpired;

        promotionRequest.ApprovalStatusId = actOnPromotionRequestDto.ApprovalStatus;
        promotionRequest.ActedAtUtc = DateTime.UtcNow;
        promotionRequest.ActedByBrandMemberId = actOnPromotionRequestDto.ActedByBrandMemberId;

        var influencer = promotionRequest.Influencer;
        var product = promotionRequest.BrandProduct;
        var productUrl = _urlBuilder.BuildProductDetailsUrl(product.BrandProductId);

        if (actOnPromotionRequestDto.ApprovalStatus == SystemApprovalStatusOption.Approved)
        {
            _ = await CreateProductPromotionAsync(
                promotionRequest.BrandProductId,
                promotionRequest.SalesChannelId,
                promotionRequest.InfluencerId,
                promotionRequest.BrandProduct,
                cancellationToken,
                promotionRequest.ProductPromotionRequestId);
        }

        await _db.SaveChangesAsync(cancellationToken);

        if (actOnPromotionRequestDto.ApprovalStatus == SystemApprovalStatusOption.Approved)
        {
            _notificationService.SendProductRequestApprovedNotification(influencer.User.UserKey, product.BrandProductId, productUrl, product.Name);
        }

        if (actOnPromotionRequestDto.ApprovalStatus == SystemApprovalStatusOption.Rejected)
        {
            _notificationService.SendProductRequestRejectedNotification(influencer.User.UserKey, product.BrandProductId, productUrl, product.Name);
        }

        response.Data = new ProductPromotionRequestDetails()
        {
            ProductPromotionRequestId = promotionRequest.ProductPromotionRequestId,
            ApprovalStatus = promotionRequest.ApprovalStatusId,
            RequestedOnUtc = promotionRequest.RequestedOnUtc,
            ActedOnUtc = promotionRequest.ActedAtUtc,
            SalesChannel = promotionRequest.SalesChannelId,
            IsRejectedDueToPeriodExpiration = promotionRequest.IsRejectedDueToPeriodExpiration
        };

        return response;
    }

    public async Task<Result<InfluencerSeekingApprovalModel>> ActOnPromotionRequestsAsync(ActOnProductPromotionRequestsDto dto)
    {
        var result = new Result<InfluencerSeekingApprovalModel>();

        var getInfluencerSpec = new GetInfluencerSpec(dto.InfluencerId);
        var influencer = await _influencersRepo.SingleOrDefaultAsync(getInfluencerSpec);

        if (influencer is null)
        {
            result.Error = ErrorType.ResourceNotFound;
            result.ErrorMessage = "Influencer doesn't exists.";
            return result;
        }

        result.Data = new InfluencerSeekingApprovalModel()
        {
            InfluencerId = influencer.InfluencerId,
            InfluencerName = influencer.User.Name,
            ProfilePicUrl = _storageService.GetSignedUrl(influencer.User.ProfilePicPath),
        };

        var requestDetails = new List<ProductPromotionRequestDetails>();

        foreach (var requestId in dto.ProductPromotionRequestIds)
        {
            var actDto = new ActOnProductPromotionRequestDto()
            {
                ProductPromotionRequestId = requestId,
                ActedByBrandMemberId = dto.ActedByBrandMemberId,
                BrandProductId = dto.BrandProductId,
                BrandOrganizationId = dto.BrandOrganizationId,
                ApprovalStatus = dto.ApprovalStatus,
                IsPeriodExpired = dto.ApprovalStatus == SystemApprovalStatusOption.Rejected ? false : null
            };

            var actResult = await ActOnPromotionRequestAsync(actDto, CancellationToken.None);

            if (actResult.IsSuccess)
            {
                requestDetails.Add(actResult.Data);
            }
        }

        result.Data.Requests = requestDetails.Select(x => new ApprovalRequest()
        {
            PromotionRequestId = x.ProductPromotionRequestId,
            ApprovalStatus = x.ApprovalStatus!.Value,
            ActedOnUtc = x.ActedOnUtc,
            Followers = ThreadSafeRandom.Next(100, 10000),
            SalesChannel = x.SalesChannel!.Value,
            SocialMediaHandleUrl = _socialMediaService.GetSalesChannelLink(x.SalesChannel!.Value, influencer.SocialMediaAccounts)
        });

        result.Data.RequestedOnUtc = requestDetails.Min(x => x.RequestedOnUtc)!.Value;

        return result;
    }

    public async Task ApproveAllPendingRequestsAsync(int brandProductId, int brandOrganizationId, int actByMemberId, CancellationToken cancellationToken)
    {
        var promotionRequestSpec = new GetPromotionRequestsByProductIdSpec(brandProductId, brandOrganizationId);
        var pendingRequests = await _promotionRequestRepository.ListAsync(promotionRequestSpec, cancellationToken);

        if (!pendingRequests.Any())
        {
            return;
        }

        foreach (var pendingRequest in pendingRequests.ToList())
        {
            var dto = new ActOnProductPromotionRequestDto()
            {
                ProductPromotionRequestId = pendingRequest.ProductPromotionRequestId,
                ActedByBrandMemberId = actByMemberId,
                BrandOrganizationId = brandOrganizationId,
                BrandProductId = pendingRequest.BrandProductId,
                ApprovalStatus = SystemApprovalStatusOption.Approved,
                IsPeriodExpired = null
            };

            await ActOnPromotionRequestAsync(dto, cancellationToken);
        }
    }

    public async Task RejectPendingRequestAsync(int productPromotionRequestId)
    {
        var promotionRequestSpec = new GetPromotionRequestByIdSpec(productPromotionRequestId);
        var promotionRequest = await _promotionRequestRepository.SingleAsync(promotionRequestSpec);

        if (promotionRequest.ApprovalStatusId != SystemApprovalStatusOption.Pending)
        {
            return;
        }

        var dto = new ActOnProductPromotionRequestDto()
        {
            ProductPromotionRequestId = productPromotionRequestId,
            ActedByBrandMemberId = promotionRequest.ActedByBrandMemberId,
            BrandOrganizationId = promotionRequest.BrandOrganizationId,
            BrandProductId = promotionRequest.BrandProductId,
            ApprovalStatus = SystemApprovalStatusOption.Rejected,
            IsPeriodExpired = true
        };

        await ActOnPromotionRequestAsync(dto, CancellationToken.None);
    }

    public async Task<ProductPromotion> GetProductPromotionByKey(string productPromotionKey)
    {
        var promotionSpec = new GetPromotionByKeySpec(productPromotionKey);
        var promotion = await _promotionRepository.SingleOrDefaultAsync(promotionSpec);

        return promotion;
    }

    private static string BuildProductUrl(BrandProduct product, ProductPromotion promotion)
    {
        return $"{product.ProductUrl}?key={promotion.ProductPromotionKey}";
    }

    private async Task<Result<ProductPromotionDetails>> CheckIfHandleExistForSalesChannelAsync(SystemSalesChannelOption salesChannelId, int influencerId)
    {
        var result = new Result<ProductPromotionDetails>();

        var influencerSpec = new GetInfluencerSpec(influencerId);
        var influencer = await _influencerRepository.SingleAsync(influencerSpec);

        if (salesChannelId == SystemSalesChannelOption.Facebook)
        {
            if (string.IsNullOrEmpty(influencer.SocialMediaAccounts.Facebook.Username))
            {
                result.Error = ErrorType.ValidationError;
                result.ErrorMessage = "You haven't provided a handle for Facebook.";
                return result;
            }
        }
        else if (salesChannelId == SystemSalesChannelOption.Instagram)
        {
            if (string.IsNullOrEmpty(influencer.SocialMediaAccounts.Instagram.Username))
            {
                result.Error = ErrorType.ValidationError;
                result.ErrorMessage = "You haven't provided a handle for Instagram.";
                return result;
            }
        }
        else if (salesChannelId == SystemSalesChannelOption.Twitter)
        {
            if (string.IsNullOrEmpty(influencer.SocialMediaAccounts.Twitter.Username))
            {
                result.Error = ErrorType.ValidationError;
                result.ErrorMessage = "You haven't provided a handle for Twitter.";
                return result;
            }
        }
        else
        {
            if (string.IsNullOrEmpty(influencer.SocialMediaAccounts.TikTok.Username))
            {
                result.Error = ErrorType.ValidationError;
                result.ErrorMessage = "You haven't provided a handle for TikTok.";
                return result;
            }
        }

        return result;
    }

    private async Task<Result<ProductPromotionDetails>> CreateProductPromotionAsync(int brandProductId,
        SystemSalesChannelOption salesChannelId, int influencerId, BrandProduct product,
        CancellationToken cancellationToken, int? productPromotionRequestId = null)
    {
        var result = new Result<ProductPromotionDetails>();

        var promotion = new ProductPromotion()
        {
            BrandProductId = brandProductId,
            InfluencerId = influencerId,
            SalesChannelId = salesChannelId,
            CommissionPercentage = product.CommissionPercentage,
            ProductPromotionRequestId = productPromotionRequestId,
            PlatformCommissionPercentage = product.PlatformCommissionPercentage,
            InfluencerCommissionPercentage = product.InfluencerCommissionPercentage
        };

        // TODO: Remove this later
        if (product.BuyerDiscountPercentage > 0 ||
            product.BrandOrganizationId == BrandOrganizationIds.GrabOrgId)
        {
            promotion.DiscountCode = await _db.BrandProductDiscountCodes
                .Include(x => x.ProductPromotion)
                .Where(x => x.ProductPromotion == null && x.BrandProductId == product.BrandProductId)
                .FirstOrDefaultAsync(cancellationToken);

            _backgroundWorker.Schedule(() => SendDiscountCodeExhaustionNotificationIfNeededAsync(brandProductId), TimeSpan.FromSeconds(10));

            // This will be only be the case when brand-member is trying to approve the requests and discount codes are exhausted.
            if (promotion.DiscountCode is null)
            {
                throw new DiscountCodesExhaustedException();
            }
        }

        _db.ProductPromotions.Add(promotion);
        await _db.SaveChangesAsync(cancellationToken);

        var productUrlWithKey = BuildProductUrl(product, promotion);
        var promotionLink = new ProductPromotionLink()
        {
            Url = product.ProductUrl is not null ? await _urlShortenerService.ShortenUrlAsync(productUrlWithKey.ToUri())
            : $"https://bta.gd/{ThreadSafeRandom.Next(1000000)}",
            ClickCount = 0,
            EntityId = promotion.ProductPromotionId
        };

        promotion.ProductPromotionLink = promotionLink;
        _db.ProductPromotionLinks.Add(promotionLink);

        await _db.SaveChangesAsync(cancellationToken);

        result.Data = new ProductPromotionDetails()
        {
            ProductPromotionId = promotion.ProductPromotionId,
            ClickCount = promotionLink.ClickCount,
            DiscountCode = promotion.DiscountCode?.DiscountCode,
            ProductLink = promotionLink.Url,
        };

        return result;
    }

    private async Task<Result<ProductPromotionDetails>> CreateProductPromotionRequestAsync(int brandProductId, SystemSalesChannelOption salesChannelId,
        int influencerId, BrandProduct product, CancellationToken cancellationToken)
    {
        var result = new Result<ProductPromotionDetails>();

        var promotionRequest = new ProductPromotionRequest()
        {
            BrandProductId = brandProductId,
            InfluencerId = influencerId,
            BrandOrganizationId = product.BrandOrganizationId,
            SalesChannelId = salesChannelId,
            ApprovalStatusId = SystemApprovalStatusOption.Pending,
            CommissionPercentage = product.CommissionPercentage,
            RequestedOnUtc = DateTime.UtcNow,
        };

        _db.ProductPromotionRequests.Add(promotionRequest);
        await _db.SaveChangesAsync(cancellationToken);

        result.Data = new ProductPromotionDetails()
        {
            Request = new ProductPromotionRequestDetails
            {
                ProductPromotionRequestId = promotionRequest.ProductPromotionRequestId,
                RequestedOnUtc = DateTime.UtcNow,
                ApprovalStatus = SystemApprovalStatusOption.Pending,
                ActedOnUtc = null,
                IsRejectedDueToPeriodExpiration = null,
            }
        };

        _backgroundWorker.Schedule(() => RejectPendingRequestAsync(promotionRequest.ProductPromotionRequestId),
            DateTime.Now.AddDays(_scheduledJobsDurations.RequestAutoRejectTimeDurationInDays));

        return result;
    }

#pragma warning disable SA1202
    public async Task SendDiscountCodeExhaustionNotificationIfNeededAsync(int brandProductId)
#pragma warning restore SA1202
    {
        var discountCodeExhaustionInfoSpec = new GetDiscountCodeExhaustionInfoWithProductSpec(brandProductId);
        var exhaustionInfo = await _brandProductsRepo.SingleAsync(discountCodeExhaustionInfoSpec);
        var exhaustionPercentage = exhaustionInfo.ExhaustionPercentage;
        var product = exhaustionInfo.BrandProduct;
        var allBrandMembersSpec = new GetAllBrandMembersUserKeyForOrganizationSpec(product.BrandOrganizationId);

        var allMembersKeys = await _brandMembershipReadRepo.ListAsync(allBrandMembersSpec);
        var productUrl = _urlBuilder.BuildProductDetailsUrl(brandProductId);

        if (exhaustionPercentage is >= 60 and < 80 && product.LastDiscountCodeExhaustionNotificationPercentage != 60)
        {
            _notificationService.SendXPercentageCouponExhaustedNotification(allMembersKeys, 60, productUrl, brandProductId, product.Name);

            product.LastDiscountCodeExhaustionNotificationPercentage = 60;

            await _db.SaveChangesAsync();
            return;
        }

        if (exhaustionPercentage is >= 80 and < 100 && product.LastDiscountCodeExhaustionNotificationPercentage != 80)
        {
            _notificationService.SendXPercentageCouponExhaustedNotification(allMembersKeys, 80, productUrl, brandProductId, product.Name);

            product.LastDiscountCodeExhaustionNotificationPercentage = 80;
            await _db.SaveChangesAsync();
        }

        if (exhaustionPercentage == 100 && product.LastDiscountCodeExhaustionNotificationPercentage != 100)
        {
            _notificationService.SendXPercentageCouponExhaustedNotification(allMembersKeys, 100, productUrl, brandProductId, product.Name);

            product.LastDiscountCodeExhaustionNotificationPercentage = 100;
        }

        await _db.SaveChangesAsync();
    }

    public class Influencers
    {
        public int InfluencerId { get; set; }

        public string InfluencerName { get; set; }
    }

    public record BrandMembers(int BrandMemberId, string BrandMemberName);

    public class Demo
    {
        public int DemoId { get; set; }

        public static void CreateInfluencer()
        {
            var influencer = new Influencers()
            {
                InfluencerId = 1,
                InfluencerName = "John Doe"
            };

            influencer.InfluencerId = 2;

            var member = new BrandMembers(1, "John Doe");
        }
    }
}
