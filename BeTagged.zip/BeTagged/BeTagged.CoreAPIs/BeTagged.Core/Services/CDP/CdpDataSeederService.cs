﻿using System;
using BeTagged.Core.Dtos;

namespace BeTagged.Core.Services.CDP;

public class CdpDataSeederService
{
    private const string TestProductName = "TEST_PRODUCT";

    private readonly ICdpService _cdpService;

    public CdpDataSeederService(ICdpService cdpService)
    {
        _cdpService = cdpService;
    }

    public async Task Seed()
    {
        var defaultInfluencerKey = Guid.Parse("00000000-0000-0000-0000-000000000000");
        var defaultBrandMemberKey = Guid.Parse("11111111-1111-1111-1111-111111111111");
        var defaultUrl = "https://incom.betagged.co";

        var user = new CreateUserDto()
        {
            Name = "Betagged User",
            UserType = SystemUserTypeOption.Influencer,
            Phone = "1111111111",
            CountryCode = "91"
        };

        var influencerCreateTask = _cdpService.CreateUserProfileAsync(defaultInfluencerKey, user);

        user.UserType = SystemUserTypeOption.BrandMember;
        var brandMemberCreateTask = _cdpService.CreateUserProfileAsync(defaultBrandMemberKey, user);
        var signupCompletedTask = _cdpService.AddHasCompletedSignupUserAttributeAsync(defaultInfluencerKey);
        var onboardingCompletedTask = _cdpService.AddHasCompletedOnboardingUserAttributeAsync(defaultInfluencerKey);
        var listedAProductTask = _cdpService.AddHasListedAProductUserAttributeAsync(defaultBrandMemberKey);
        var incrementProductsSoldCountTask = _cdpService.IncrementProductsSoldCountAsync(defaultInfluencerKey, 100);
        var decrementProductsSoldCountTask = _cdpService.IncrementProductsSoldCountAsync(defaultInfluencerKey, 50);

        // Events
        var signupCompletedEventTask = _cdpService.SendSignupCompletedEventAsync(defaultInfluencerKey);
        var onboardingCompletedEventTask = _cdpService.SendOnboardingCompletedEventAsync(defaultInfluencerKey);
        var productListedEventTask = _cdpService.SendProductListedEventAsync(defaultBrandMemberKey, "https://incom.betagged.co",
            0, TestProductName);
        var sixtyPercentCouponExhaustedEventTask = _cdpService
            .SendXPercentageCouponExhaustedEventAsync(new[] { defaultBrandMemberKey }, 60, defaultUrl, 0, TestProductName);
        var eightyPercentCouponExhaustedEventTask = _cdpService
            .SendXPercentageCouponExhaustedEventAsync(new[] { defaultBrandMemberKey }, 80, defaultUrl, 0, TestProductName);
        var salesDataUploadReminderEventTask = _cdpService
            .SendSalesDataNeedsToBeUploadedEventAsync(defaultBrandMemberKey, defaultUrl, 0, TestProductName);
        var productSoldEventTask = _cdpService.SendProductSoldEventAsync(defaultInfluencerKey);
        var productRequestApprovedEventTask =
            _cdpService.SendProductRequestApprovedEventAsync(defaultInfluencerKey, 0, defaultUrl, TestProductName);
        var productRequestRejectedEventTask =
            _cdpService.SendProductRequestRejectedEventAsync(defaultInfluencerKey, 0, defaultUrl, TestProductName);
        var productUnlistedEventTask =
            _cdpService.SendProductUnlistedEventAsync(new[] { defaultInfluencerKey }, 0, defaultUrl, TestProductName);
        var listAProductEventTask = _cdpService.SendProductListingReminderEventAsync(defaultBrandMemberKey, 14);
        var influencerSeekingApprovalEventTask =
            _cdpService.SendInfluencerSeekingApprovalEventAsync(new[] { defaultBrandMemberKey }, 0, defaultUrl,
                TestProductName);
        var pickingAProductReminderEventTask =
            _cdpService.SendReminderForPickingAProductToInfluencerAsync(defaultInfluencerKey, 14);
        var completeSignupReminderTask = _cdpService.SendCompleteSignupReminderEventAsync(defaultBrandMemberKey);
        var completeOnboardingReminderEventTask =
            _cdpService.SendCompleteOnboardingReminderEventAsync(defaultBrandMemberKey);

        await Task.WhenAll(influencerCreateTask,
            brandMemberCreateTask,
            signupCompletedTask,
            onboardingCompletedTask,
            listedAProductTask,
            incrementProductsSoldCountTask,
            decrementProductsSoldCountTask,
            signupCompletedEventTask,
            onboardingCompletedEventTask,
            productListedEventTask,
            sixtyPercentCouponExhaustedEventTask,
            eightyPercentCouponExhaustedEventTask,
            salesDataUploadReminderEventTask,
            productSoldEventTask,
            productRequestApprovedEventTask,
            productRequestRejectedEventTask,
            productUnlistedEventTask,
            listAProductEventTask,
            influencerSeekingApprovalEventTask,
            pickingAProductReminderEventTask,
            completeSignupReminderTask,
            completeOnboardingReminderEventTask);
    }
}
