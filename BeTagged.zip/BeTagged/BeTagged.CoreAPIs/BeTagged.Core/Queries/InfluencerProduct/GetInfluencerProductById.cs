﻿using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Queries.InfluencerProduct;

using System;
using System.Linq;
using System.Threading;
using AutoMapper;
using BeTagged.Core.Enums;
using BeTagged.Core.Mapping;
using BeTagged.Core.Models;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Storage;
using MediatR;

public static class GetInfluencerProductById
{
    public record Query(int Id) : IRequest<Response>;

    public class Handler : IRequestHandler<Query, Response>
    {
        private readonly IStorageService _storageService;
        private readonly IMapper _mapper;
        private readonly ICurrentInfluencer _currentInfluencer;
        private readonly IReadOnlyRepository<Data.Entities.BrandProduct> _productsRepo;
        private readonly IReadOnlyRepository<Influencer> _influencersRepo;
        private readonly IReadOnlyRepository<Data.Entities.BrandProductDiscountCode> _discountcodeRepository;

        public Handler(IStorageService storageService, IMapper mapper, ICurrentInfluencer currentInfluencer,
            IReadOnlyRepository<Data.Entities.BrandProduct> productsRepo, IReadOnlyRepository<Influencer> influencersRepo, IReadOnlyRepository<BrandProductDiscountCode> discountcodeRepository)
        {
            _storageService = storageService;
            _mapper = mapper;
            _currentInfluencer = currentInfluencer;
            _productsRepo = productsRepo;
            _influencersRepo = influencersRepo;
            _discountcodeRepository = discountcodeRepository;
        }

        public async Task<Response> Handle(Query request, CancellationToken cancellationToken)
        {
            var influencerCountryIdSpec = new GetInfluencerCountryIdSpec(_currentInfluencer.InfluencerId);
            var countryId = await _influencersRepo.SingleAsync(influencerCountryIdSpec, cancellationToken);

            var spec = new GetInfluencerProductByIdSpec(_currentInfluencer.InfluencerId, request.Id, countryId!.Value);

            var product = await _productsRepo.SingleOrDefaultAsync(spec, cancellationToken);

            if (product is null)
            {
                return new Response() { ErrorMessage = ValidationMessages.ProductDoesNotExist, Error = ErrorType.ResourceNotFound };
            }

            var response = _mapper.Map<Data.Entities.BrandProduct, Response>(product);

            response.SetProductUrls();

            if (product.ProductPromotionRequests.Any() || product.ProductPromotions.Any())
            {
                PopulateSalesChannel(product, response);
            }

            if (product.BuyerDiscountPercentage > 0)
            {
                var discountcodeAvailableSpec = new AreDiscountCodesAvailableSpec(product.BrandProductId);
                var isDicountcodeAvailable = await _discountcodeRepository.AnyAsync(discountcodeAvailableSpec, cancellationToken);

                response.HasAllCodesExhausted = !isDicountcodeAvailable;
            }

            response.SignTheUrls(_storageService);
            return response;
        }

        private static void PopulateSalesChannel(Data.Entities.BrandProduct product, Response response)
        {
            foreach (SystemSalesChannelOption channel in Enum.GetValues(typeof(SystemSalesChannelOption)))
            {
                var promotionRequest = product.ProductPromotionRequests.FirstOrDefault(x => x.SalesChannelId == channel);
                var promotion = product.ProductPromotions.FirstOrDefault(x => x.SalesChannelId == channel);

                var productPromotionData = new ProductPromotionDetails()
                {
                    DiscountCode = promotion?.DiscountCode?.DiscountCode,
                    ProductLink = promotion?.ProductPromotionLink?.Url,
                    ClickCount = promotion?.ProductPromotionLink?.ClickCount,
                    ProductPromotionId = promotion?.ProductPromotionId,
                };

                if (promotionRequest is not null)
                {
                    productPromotionData.Request = new()
                    {
                        ApprovalStatus = promotionRequest.ApprovalStatusId,
                        RequestedOnUtc = promotionRequest.RequestedOnUtc,
                        ActedOnUtc = promotionRequest.ActedAtUtc,
                        ProductPromotionRequestId = promotionRequest.ProductPromotionRequestId,
                        IsRejectedDueToPeriodExpiration = promotionRequest.IsRejectedDueToPeriodExpiration,
                    };
                }

                switch (channel)
                {
                    case SystemSalesChannelOption.Facebook:
                        response.PromotionalInfo.Facebook = productPromotionData;
                        break;

                    case SystemSalesChannelOption.Instagram:
                        response.PromotionalInfo.Instagram = productPromotionData;
                        break;

                    case SystemSalesChannelOption.Twitter:
                        response.PromotionalInfo.Twitter = productPromotionData;
                        break;

                    case SystemSalesChannelOption.TikTok:
                        response.PromotionalInfo.TikTok = productPromotionData;
                        break;
                }
            }
        }
    }

    public class Response : BrandProductModel, ICustomMap<Data.Entities.BrandProduct, Response>
    {
        public Response()
        {
            PromotionalInfo = new();
        }

        public ProductInfluencerPromotionalInfo PromotionalInfo { get; set; }

        public double CommissionEarned { get; set; }

        public string BrandName { get; set; }

        public bool HasAllCodesExhausted { get; set; }

        public DateTime? UnlistedAtUtc { get; set; }

        public DateTime? SalesAllowedTillUtc { get; set; }

        public void ConfigureMap(IMappingExpression<Data.Entities.BrandProduct, Response> mapping)
        {
            mapping.IncludeBase<Data.Entities.BrandProduct, BrandProductModel>();

            mapping.ForMember(x => x.PromotionalInfo, map => map.Ignore());

            mapping.ForMember(d => d.BrandName, o => o.MapFrom(s => s.BrandOrganization.LegalName));

            mapping.ForMember(x => x.CommissionPercentage, o => o.MapFrom(s => s.InfluencerCommissionPercentage));
        }
    }
}
