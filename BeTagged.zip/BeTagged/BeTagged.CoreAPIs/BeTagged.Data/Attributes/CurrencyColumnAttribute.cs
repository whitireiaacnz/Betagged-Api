﻿using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Attributes;

internal class CurrencyColumnAttribute : ColumnAttribute
{
    public CurrencyColumnAttribute()
    {
        TypeName = "decimal(14, 2)";
    }

    public CurrencyColumnAttribute(int precision, int scale)
    {
        TypeName = $"decimal({precision}, {scale})";
    }
}
