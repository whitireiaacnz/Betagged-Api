﻿namespace BeTagged.Core.Services.Security;

public interface IPasswordResetService
{
    Task<Result<bool>> SendResetCode(string email, SystemUserTypeOption userType);

    Task<Result<string>> VerifyResetCode(string email, string code, SystemUserTypeOption userType);

    Task<Result<bool>> ResetPassword(string email, string password, string passwordResetToken, SystemUserTypeOption userType);
}
