﻿namespace BeTagged.Core.Configurations;

public class SecurityConfiguration
{
    public const string Section = "Security";

    public string TokenIssuer { get; set; }

    public string TokenAudience { get; set; }

    public string TokenSecretKey { get; set; }

    public string PasswordHashingSecret { get; set; }

    public int OtpValidityInMinutes { get; set; }
}
