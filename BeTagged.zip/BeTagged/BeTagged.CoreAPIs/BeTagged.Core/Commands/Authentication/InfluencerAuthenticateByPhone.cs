﻿using System.Threading;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Otp;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Core.Utils;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Commands.Authentication;

public static class InfluencerAuthenticateByPhone
{
    public record Command(string CountryCode, string Phone) : IRequest<Response>;

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.CountryCode).NotEmpty();
            RuleFor(x => x.Phone).NotEmpty();
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IPhoneOtpService _phoneOtpService;
        private readonly IReadOnlyRepository<Phone> _phoneRepository;

        public Handler(IPhoneOtpService phoneOtpService, IReadOnlyRepository<Phone> phoneRepository)
        {
            _phoneOtpService = phoneOtpService;
            _phoneRepository = phoneRepository;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var response = new Response();
            var isValidPhone = PhoneUtil.IsValidPhone(request.CountryCode, request.Phone);

            if (!isValidPhone)
            {
                response.ErrorMessage = "Phone is not valid.";
                response.Error = ErrorType.ValidationError;
                return response;
            }

            var getPhoneSpec =
                new GetPhoneSpecForUserType(request.CountryCode, request.Phone, SystemUserTypeOption.Influencer);

            var phone = await _phoneRepository.SingleOrDefaultAsync(getPhoneSpec, cancellationToken);

            if (phone is null)
            {
                response.ErrorMessage = "Phone does not exist.";
                response.Error = ErrorType.ValidationError;
                return response;
            }

            await _phoneOtpService.GenerateAndSendPhoneOtpAsync(phone, SystemOtpUsageTypeOption.Login);
            return response;
        }
    }

    public class Response : Result
    {
    }
}
