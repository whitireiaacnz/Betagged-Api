﻿namespace BeTagged.Data.Enums;

[EnumLookupTable(typeof(SystemShortenedLinkEntityType))]
public enum SystemShortenedLinkEntityTypeOption : byte
{
    ProductPromotion = 1
}
