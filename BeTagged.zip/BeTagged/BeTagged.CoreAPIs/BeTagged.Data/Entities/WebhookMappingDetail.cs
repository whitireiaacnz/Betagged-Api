﻿using BeTagged.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(WebhookMappingDetailEntityConfiguration))]
public class WebhookMappingDetail : BaseEntity
{
    public int WebhookMappingDetailId { get; set; }

    public string CartToken { get; set; }

    public string Key { get; set; }
}
