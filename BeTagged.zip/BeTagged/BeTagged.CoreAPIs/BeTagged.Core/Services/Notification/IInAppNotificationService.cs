﻿using System;

namespace BeTagged.Core.Services.Notification;

public interface IInAppNotificationService
{
    Task SendProductListedNotificationAsync(Guid userKey, int productId, string productUrl, string productName);

    Task SendXPercentCouponExhaustedNotificationAsync(IEnumerable<Guid> userKeys, int productId, string productUrl,
        string productName, int percentage);

    Task SendSalesDataNeedsTobeUploadedAsync(Guid userKey, int productId, string productUrl, string productName);

    Task SendProductRequestApprovedNotificationAsync(Guid userKey, int productId, string productUrl, string productName);

    Task SendProductRequestRejectedNotificationAsync(Guid userKey, int productId, string productUrl, string productName);

    Task SendProductUnlistedNotificationAsync(IEnumerable<Guid> userKeys, int productId, string productUrl,
        string productName);

    Task SendProductListingReminderNotificationAsync(Guid userKey, int daysWithoutListingProduct);

    Task SendInfluencerSeekingApprovalNotificationAsync(IEnumerable<Guid> userKeys, int productId, string productUrl,
        string productName);

    Task SendReminderForPickProductToInfluencerAsync(int userId, int daysWithoutPickingAProduct);
}
