﻿using System;
using Newtonsoft.Json;

namespace BeTagged.Core.Dtos;

public class AddBrandProductDto : BrandProductModel
{
    [JsonIgnore]
    public override int BrandProductId { get; set; } = 0;

    [JsonIgnore]
    public override DateTime? ListedOnUtc { get; set; }

    public new IEnumerable<int> Categories { get; set; }

    public new byte Country { get; set; }

    public LocationPoint Location { get; set; }

    public string DiscountCodesFileUrl { get; set; }
}
