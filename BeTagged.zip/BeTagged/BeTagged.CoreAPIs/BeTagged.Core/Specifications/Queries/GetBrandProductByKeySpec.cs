﻿using System;
using BeTagged.Data.Specifications;

namespace BeTagged.Core.Specifications.Queries;

public class GetBrandProductByKeySpec : ISingleResultQuerySpecification<BrandProduct, BrandProduct>
{
    public GetBrandProductByKeySpec(Guid brandProductkey)
    {
        Query = queryable => queryable
            .Where(x => x.BrandProductKey == brandProductkey);
    }

    public Func<IQueryable<BrandProduct>, IQueryable<BrandProduct>> Query { get; }
}
