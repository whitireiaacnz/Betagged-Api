﻿using BeTagged.Core.Dtos;

namespace BeTagged.Core.Services.ProductSales;

public interface IProductSalesService
{
    Task AddProductSaleAsync(AddProductSaleDto productSaleDto);
}
