﻿using System;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries.Lookups;

public class GetBrandMemberWithUserSpec : ISingleResultQuerySpecification<BrandMember, BrandMember>
{
    public GetBrandMemberWithUserSpec(string emailAddress)
    {
        var normalizedEmail = emailAddress.ToUpper();

        Query = q => q
            .Include(x => x.User)
            .Where(x => x.User.EmailAddresses.Any(y => y.NormalizedEmailAddress == normalizedEmail));
    }

    public Func<IQueryable<BrandMember>, IQueryable<BrandMember>> Query { get; }
}
