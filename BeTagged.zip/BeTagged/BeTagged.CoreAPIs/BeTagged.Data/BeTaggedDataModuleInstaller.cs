﻿using System;
using BeTagged.Data.Interceptors;
using BeTagged.Data.Repositories;
using BeTagged.Data.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace BeTagged.Data;

public static class BeTaggedDataModuleInstaller
{
    public static IServiceCollection AddBeTaggedPersistenceModule(this IServiceCollection services, IConfiguration configuration)
    {
        AddBeTaggedDb(services, configuration);
        AddServicesToIoc(services);
        AddRepositories(services);

        return services;
    }

    private static IServiceCollection AddBeTaggedDb(IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("BeTaggedDb");

        Action<DbContextOptionsBuilder> dbContextOptions = options =>
        {
            options.UseNpgsql(connectionString, o =>
            {
                o.ExecutionStrategy(dependencies => new BeTaggedSqlExecutionStrategy(dependencies));
                o.UseNetTopologySuite();
            }).UseSnakeCaseNamingConvention();
        };

        services.AddDbContext<BtDb>(dbContextOptions);

        return services;
    }

    private static IServiceCollection AddServicesToIoc(IServiceCollection services)
    {
        services.AddScoped<IBtDb>(provider => provider.GetRequiredService<BtDb>());
        services.AddScoped<IReadOnlyBtDb, ReadOnlyBtDb>();
        services.AddScoped<IInterceptor, BtSaveChangesInterceptor>();
        services.AddScoped<IQueryService, QueryService>();

        return services;
    }

    private static IServiceCollection AddRepositories(IServiceCollection services)
    {
        services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
        services.AddScoped(typeof(IReadOnlyRepository<>), typeof(ReadOnlyRepository<>));

        return services;
    }
}
