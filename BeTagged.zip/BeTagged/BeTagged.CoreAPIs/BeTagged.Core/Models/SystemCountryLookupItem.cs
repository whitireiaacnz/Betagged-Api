﻿namespace BeTagged.Core.Models;

public record SystemCountryLookupItem(int Id, string Name) : LookupItem(Id, Name)
{
    public string IsoCode { get; set; }

    public string IsdCode { get; set; }

    public string Iso3Code { get; set; }

    public string CurrencyCode { get; set; }

    public string CurrencySymbol { get; set; }
}
