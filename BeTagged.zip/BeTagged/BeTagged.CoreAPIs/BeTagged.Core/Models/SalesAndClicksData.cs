﻿namespace BeTagged.Core.Models;

public class SalesAndClicksData
{
    public int BrandProductId { get; set; }

    public int Sales { get; set; }

    public int Clicks { get; set; }
}
