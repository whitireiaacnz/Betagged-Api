﻿namespace BeTagged.Core.Models;

public record SystemCurrencyCodeLookupItem(int Id, string Name, string Symbol) : LookupItem(Id, Name);
