﻿namespace BeTagged.Core.Services.SocialMedia;

public interface ISocialMediaService
{
    string GetSalesChannelLink(SystemSalesChannelOption salesChannelId, InfluencerMediaAccounts socialMediaAccounts);
}
