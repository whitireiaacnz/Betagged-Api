﻿namespace BeTagged.Core.Models;

public class InfluencerAuthenticationResponse : Result
{
    public string AccessToken { get; set; }

    public InfluencerBasicInfo InfluencerInfo { get; set; }
}
