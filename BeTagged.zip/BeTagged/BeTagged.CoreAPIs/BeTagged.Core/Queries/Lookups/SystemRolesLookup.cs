﻿using System.Threading;
using BeTagged.Core.Specifications.Queries.Lookups;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Queries.Lookups;

public static class SystemRolesLookup
{
    public record Query : IRequest<IEnumerable<LookupItem>>;

    public class Handler : IRequestHandler<Query, IEnumerable<LookupItem>>
    {
        private readonly IReadOnlyRepository<SystemRole> _systemRolesRepo;

        public Handler(IReadOnlyRepository<SystemRole> systemRolesRepo)
        {
            _systemRolesRepo = systemRolesRepo;
        }

        public async Task<IEnumerable<LookupItem>> Handle(Query request, CancellationToken cancellationToken)
        {
            var getRolesSpec = new GetSystemRolesLookupSpec();
            return await _systemRolesRepo.ListAsync(getRolesSpec, cancellationToken);
        }
    }
}
