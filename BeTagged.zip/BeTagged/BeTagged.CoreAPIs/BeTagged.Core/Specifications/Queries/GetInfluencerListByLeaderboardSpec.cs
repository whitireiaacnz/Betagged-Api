﻿using System;
using System.Threading;
using BeTagged.Core.Dtos;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetInfluencerListByLeaderboardSpec : IListResultQuerySpecification<ProductPromotion, InfluencerLeaderboardDto>
{
    public GetInfluencerListByLeaderboardSpec(int brandProductId, int skip, int take, int currentInfluencerId)
    {
        Query = async (queryable, ct) => await queryable
                    .Where(x => x.BrandProductId == brandProductId)
                    .Include(x => x.Influencer)
                    .ThenInclude(x => x.Country)
                    .Include(x => x.Influencer)
                    .ThenInclude(x => x.User)
                    .GroupBy(x => x.InfluencerId)
                    .Select(x => new InfluencerLeaderboardDto()
                    {
                        InfluencerProfilePicUrl = x.First().Influencer.User.ProfilePicPath,
                        InfluencerId = x.First().InfluencerId,
                        Name = x.First().Influencer.User.Name,
                        Sales = x.Sum(y => y.ProductSales.Sum(z => z.Quantity)),
                        Commission = x.Sum(y => y.ProductSales.Sum(z => z.InfluencerPayableCommission)),
                        CurrencyCode = x.First().Influencer.Country.CurrencyCode,
                        CurrencySymbol = x.First().Influencer.Country.CurrencySymbol,
                        SalesChannelData = x.GroupBy(y => y.SalesChannelId)
                            .Select(y => new SalesChannelDetails()
                            {
                                SalesChannel = y.First().SalesChannelId,
                                Sale = y.Sum(s => s.ProductSales.Sum(z => z.Quantity)),
                            })
                    }).Skip(skip).Take(take + 1)
                    .OrderByDescending(x => x.Sales)
                    .ThenByDescending(x => x.InfluencerId == currentInfluencerId)
                    .ToListAsync(ct);
    }

    public Func<IQueryable<ProductPromotion>, CancellationToken, Task<IList<InfluencerLeaderboardDto>>> Query { get; }
}
