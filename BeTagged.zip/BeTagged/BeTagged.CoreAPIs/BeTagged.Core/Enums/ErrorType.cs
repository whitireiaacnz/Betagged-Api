﻿namespace BeTagged.Core.Enums;

public enum ErrorType
{
    ResourceNotFound,
    ValidationError,
    Unauthenticated,
    InSufficientPermissions,
    Conflict
}
