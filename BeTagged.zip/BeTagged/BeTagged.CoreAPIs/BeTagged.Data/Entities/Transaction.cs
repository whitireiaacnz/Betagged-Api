﻿using System;
using System.Text.Json;
using BeTagged.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(TransactionEntityConfiguration))]
public class Transaction : BaseEntity, IDisposable
{
    public int TransactionId { get; set; }

    public string ProviderTransactionId { get; set; }

    [JsonbColumn]
    public JsonDocument MetaData { get; set; }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (disposing)
        {
            MetaData?.Dispose();
        }
    }
}
