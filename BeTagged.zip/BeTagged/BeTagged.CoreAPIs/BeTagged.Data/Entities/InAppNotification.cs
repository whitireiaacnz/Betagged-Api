﻿using System;
using BeTagged.Common.Utils;
using BeTagged.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(InAppNotificationEntityConfiguration))]
public class InAppNotification : BaseEntity
{
    public int UserNotificationId { get; set; }

    public string Title { get; set; }

    public string Content { get; set; }

    public bool HasReadByUser { get; set; }

    public DateTime? ReadAtUtc { get; set; }

    [JsonbColumn]
    public string Arguments { get; set; }

    public SystemInAppNotificationTypeOption SystemInAppNotificationTypeId { get; set; }

    public int UserId { get; set; }

    // Foreign Keys
    public User User { get; set; }

    public SystemInAppNotificationType SystemInAppNotificationType { get; set; }

    public void MarkRead()
    {
        HasReadByUser = true;
        ReadAtUtc = DateTime.UtcNow;
    }

    public void SetArguments(object arguments) => Arguments = arguments.Serialize();
}
