﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace BeTagged.Data.Interceptors;

internal class BtSaveChangesInterceptor : SaveChangesInterceptor
{
    public override int SavedChanges(SaveChangesCompletedEventData eventData, int result)
    {
        DoSavingChangesActivities(eventData.Context);
        return base.SavedChanges(eventData, result);
    }

    public override ValueTask<InterceptionResult<int>> SavingChangesAsync(DbContextEventData eventData, InterceptionResult<int> result,
        CancellationToken cancellationToken = new CancellationToken())
    {
        DoSavingChangesActivities(eventData.Context);
        return base.SavingChangesAsync(eventData, result, cancellationToken);
    }

    private static void DoSavingChangesActivities(DbContext context)
    {
        var dbContext = (BtDb)context;

        var changeTracker = dbContext!.ChangeTracker;

        var entries = changeTracker.Entries()
            .Where(e => e.Entity is BaseEntity or IUserEntity)
            .Where(e => e.State is EntityState.Added or EntityState.Modified);

        foreach (var entry in entries)
        {
            var entity = (BaseEntity)entry.Entity;
            var currentTs = DateTime.UtcNow;

            switch (entry.State)
            {
                case EntityState.Added:
                    entity.CreatedAtUtc = currentTs;
                    entity.ModifiedAtUtc = currentTs;
                    break;

                case EntityState.Modified:
                    entity.ModifiedAtUtc = currentTs;
                    break;
            }
        }
    }
}
