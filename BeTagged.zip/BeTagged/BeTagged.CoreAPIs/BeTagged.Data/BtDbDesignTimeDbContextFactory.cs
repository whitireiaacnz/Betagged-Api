﻿using System;
using System.Linq;
using BeTagged.Common.Extensions;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Configuration;

namespace BeTagged.Data;

internal class BtDbDesignTimeDbContextFactory : IDesignTimeDbContextFactory<BtDb>
{
    public static BtDb CreateDbContextFromConnection(string connectionString)
    {
        if (connectionString.IsNullOrEmpty())
        {
            throw new InvalidOperationException("DB connection string can't be null or empty");
        }

        var optionsBuilder = new DbContextOptionsBuilder<BtDb>();

        optionsBuilder.UseNpgsql(connectionString, o =>
        {
            o.ExecutionStrategy(dependencies => new BeTaggedSqlExecutionStrategy(dependencies));
            o.UseNetTopologySuite();
        }).UseSnakeCaseNamingConvention();

        return new BtDb(optionsBuilder.Options, Enumerable.Empty<IInterceptor>());
    }

    public BtDb CreateDbContext(string[] args)
    {
        var configuration = new ConfigurationBuilder()
            .AddJsonFile("datasettings.json", optional: true)
            .AddEnvironmentVariables()
            .AddUserSecrets<BtDbDesignTimeDbContextFactory>(optional: true)
            .Build();

        var connectionString = configuration.GetConnectionString(args.FirstOrDefault() ?? "Local");

        return CreateDbContextFromConnection(connectionString);
    }
}
