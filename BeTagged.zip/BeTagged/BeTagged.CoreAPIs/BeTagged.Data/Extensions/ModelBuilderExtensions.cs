﻿using System.Linq;
using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data.Extensions;

internal static class ModelBuilderExtensions
{
    public static ModelBuilder ApplyGlobalQueryFilters(this ModelBuilder builder)
    {
        var baseType = typeof(BaseEntity);

        var entities = builder.Model.GetEntityTypes()
            .Where(x => (x.ClrType.BaseType == baseType || x.ClrType.BaseType is null) // To filter out TPH
                        && baseType.IsAssignableFrom(x.ClrType));

        foreach (var entity in entities)
        {
            var isDeletedProperty = entity.FindProperty(nameof(BaseEntity.IsDeleted));

            if (isDeletedProperty is null || isDeletedProperty.ClrType != typeof(bool))
            {
                continue;
            }

            var parameter = Expression.Parameter(entity.ClrType, "x");
            var leftExpression = Expression.Property(parameter, isDeletedProperty.PropertyInfo);
            var finalFilter = Expression.MakeBinary(ExpressionType.Equal, leftExpression, Expression.Constant(false));
            var filter = Expression.Lambda(finalFilter, parameter);
            entity.SetQueryFilter(filter);
        }

        return builder;
    }
}
