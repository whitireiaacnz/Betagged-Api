﻿using AutoMapper;

namespace BeTagged.Core.Mapping;

internal interface ICustomMap<TSource, TDestination>
{
    void ConfigureMap(IMappingExpression<TSource, TDestination> mapping);
}
