﻿namespace BeTagged.Data.Enums;

[EnumLookupTable(typeof(SystemProductStatus))]
public enum SystemProductStatusOption : byte
{
    Draft = 1,
    Listed = 2,
    Unlisted = 3,
}
