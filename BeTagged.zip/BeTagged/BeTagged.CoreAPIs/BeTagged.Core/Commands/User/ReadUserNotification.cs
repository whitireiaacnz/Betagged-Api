﻿using System.Threading;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Commands.User;

public static class ReadUserNotification
{
    public record Command(int UserNotificationId) : IRequest<Response>;

    public class Validator : AbstractValidator<Command>
    {
        public Validator() => RuleFor(x => x.UserNotificationId).GreaterThan(0);
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly ICurrentUser _currentUser;
        private readonly IRepository<InAppNotification> _userNotificationsRepo;
        private readonly IBtDb _btDb;

        public Handler(IRepository<InAppNotification> userNotificationsRepo, ICurrentUser currentUser, IBtDb btDb)
        {
            _userNotificationsRepo = userNotificationsRepo;
            _currentUser = currentUser;
            _btDb = btDb;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var notification = await _userNotificationsRepo
                .SingleOrDefaultAsync(new GetUserNotification(_currentUser.UserId, request.UserNotificationId),
                    cancellationToken);

            var response = new Response();

            if (notification is null)
            {
                response.Error = ErrorType.ResourceNotFound;
                response.ErrorMessage = "Notification does not exists";
                return response;
            }

            notification.MarkRead();
            await _btDb.SaveChangesAsync(cancellationToken);

            response.NotificationId = notification.UserNotificationId;
            response.Title = notification.Title;
            response.Content = notification.Content;
            response.HasReadByUser = notification.HasReadByUser;
            response.ArgumentsString = notification.Arguments;
            response.NotificationType = notification.SystemInAppNotificationTypeId;

            return response;
        }
    }

    public class Response : InAppNotificationModel
    {
    }
}
