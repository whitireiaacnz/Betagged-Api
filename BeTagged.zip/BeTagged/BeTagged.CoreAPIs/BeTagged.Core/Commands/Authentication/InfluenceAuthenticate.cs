﻿using System.Threading;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Commands.Authentication;

public static class InfluenceAuthenticate
{
    public class Command : IRequest<InfluencerAuthenticationResponse>
    {
        public string Email { get; set; }

        public string Password { get; set; }
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.Email).NotEmpty().EmailAddress();
            RuleFor(x => x.Password).NotEmpty();
        }
    }

    public class Handler : IRequestHandler<Command, InfluencerAuthenticationResponse>
    {
        private readonly IAuthenticationService _authenticationService;

        public Handler(IAuthenticationService authenticationService)
        {
            _authenticationService = authenticationService;
        }

        public async Task<InfluencerAuthenticationResponse> Handle(Command request, CancellationToken cancellationToken)
        {
            return await _authenticationService.AuthenticateInfluencerAsync(request.Email, request.Password);
        }
    }
}
