﻿using System.Threading;
using BeTagged.Core.Dtos;
using BeTagged.Core.Services.Profile;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Utils;
using Newtonsoft.Json;

namespace BeTagged.Core.Commands.Profile;

public static class AddInfluencerBankAccount
{
    public class Command : InfluencerBankAccountDto, IRequest<InfluencerBankAccountDto>
    {
        [JsonIgnore]
        public override int Id { get; set; }

        [JsonIgnore]
        public override bool IsPrimary { get; set; }
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.AccountName).NotEmpty().Matches(PropertyValidationUtil.OnlyAlphabetRegex)
                .WithMessage("Account name must only contain alphabets.");
            RuleFor(x => x.AccountNumber).NotEmpty().Matches(PropertyValidationUtil.AlphNumericRegex)
                .WithMessage("Account number must only contain alphanumeric characters.");
            RuleFor(x => x.SwiftCode).NotEmpty().Matches(PropertyValidationUtil.AlphNumericRegex)
                .WithMessage("Swift code must only contain alphanumeric characters.");
            RuleFor(x => x.BankName).NotEmpty().Matches(PropertyValidationUtil.AlphNumericRegex)
                .WithMessage("Swift code must only contain alphanumeric characters.");
            RuleFor(x => x.Branch).Matches(PropertyValidationUtil.AlphNumericRegex)
                .WithMessage("Branch must only contain alphanumeric characters.");
        }
    }

    public class Handler : IRequestHandler<Command, InfluencerBankAccountDto>
    {
        private readonly ICurrentInfluencer _currentInfluencer;
        private readonly IInfluencerService _influencerService;

        public Handler(ICurrentInfluencer currentInfluencer, IInfluencerService influencerService)
        {
            _currentInfluencer = currentInfluencer;
            _influencerService = influencerService;
        }

        public async Task<InfluencerBankAccountDto> Handle(Command request, CancellationToken cancellationToken)
        {
            var response = await _influencerService.AddBankAccountAsync(_currentInfluencer.InfluencerId,
                request);

            return response;
        }
    }
}
