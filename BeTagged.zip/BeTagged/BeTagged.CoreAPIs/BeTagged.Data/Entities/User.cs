﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using BeTagged.Data.Constants;
using BeTagged.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(UserEntityConfiguration))]
public class User : BaseEntity
{
    public User()
    {
        EmailAddresses = new List<EmailAddress>();
        Phones = new List<Phone>();
        PasswordResetTokens = new List<PasswordResetToken>();
        Notifications = new List<InAppNotification>();
    }

    public int UserId { get; set; }

    public Guid UserKey { get; set; }

    [MaxLength(64)]
    public string Name { get; set; }

    public string PasswordHash { get; set; }

    public SystemUserTypeOption UserType { get; set; }

    public DateTime? LastLoginAtUtc { get; set; }

    public DateTime? LastActivityAtUtc { get; set; }

    public DateTime? LastPasswordChangeAtUtc { get; set; }

    [MaxLength(DbConstants.UserSaltLength)]
    public string Salt { get; set; }

    public string ProfilePicPath { get; set; }

    // Foreign keys
    public SystemUserType SystemUserType { get; set; }

    // Reverse navigation
    public ICollection<EmailAddress> EmailAddresses { get; set; }

    public ICollection<Phone> Phones { get; set; }

    public ICollection<PasswordResetToken> PasswordResetTokens { get; set; }

    public ICollection<InAppNotification> Notifications { get; set; }
}
