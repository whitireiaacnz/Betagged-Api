﻿namespace BeTagged.Core.Services.GeoDb;
using System.Threading.Tasks;
using BeTagged.Core.Models;

public interface IGeoDbService
{
    Task<PaginatedList<CityLookupItem>> GetCitiesAsync(int skip, int take, string search, string countryIso2Code = null);
}
