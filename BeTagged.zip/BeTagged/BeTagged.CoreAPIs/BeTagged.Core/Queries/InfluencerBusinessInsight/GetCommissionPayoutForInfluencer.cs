﻿using System;
using System.Threading;
using BeTagged.Core.Queries.Shared;

namespace BeTagged.Core.Queries.InfluencerBusinessInsight;

public static class GetCommissionPayoutForInfluencer
{
    public class Query : ODataQueryBase, IRequest<PaginatedList<Response>>
    {
        public DateTime From { get; set; }

        public DateTime To { get; set; }
    }

    public class Handler : IRequestHandler<Query, PaginatedList<Response>>
    {
        public Task<PaginatedList<Response>> Handle(Query request, CancellationToken cancellationToken)
        {
            // TODO: Get Real time Commission Payout Data.
            List<Response> commissionPayoutData = new();

            return Task.FromResult(new PaginatedList<Response>(commissionPayoutData, 0, 0));
        }
    }

    public class Response
    {
        public DateTime TransactionForMonth { get; set; }

        public decimal Commission { get; set; }

        public DateTime? PaidOnUtc { get; set; }

        public string TransactionId { get; set; }

        public string CurrencyCode { get; set; }

        public string CurrencySymbol { get; set; }
    }
}
