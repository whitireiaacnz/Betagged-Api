﻿using System;

namespace BeTagged.Core.Services.Notification;

public interface INotificationService
{
    void SendSignupCompletedNotification(Guid userKey);

    void SendOnBoardingCompletedNotification(Guid userKey);

    void SendProductListedNotification(Guid userKey, int brandProductId, string brandProductUrl, string productName);

    void SendXPercentageCouponExhaustedNotification(IEnumerable<Guid> userKeys, int percentage,
        string brandProductUrl, int brandProductId, string productName);

    void SendSalesDataNeedsToBeUploadedNotification(Guid userKey, string brandProductUrl, int brandProductId, string productName);

    Task SendProductSoldNotificationAsync(Guid userKey);

    void SendProductRequestApprovedNotification(Guid userKey, int productId, string productUrl, string productName);

    void SendProductRequestRejectedNotification(Guid userKey, int productId, string productUrl, string productName);

    Task SendProductUnlistedNotificationAsync(int productId, string productUrl, string productName);

    Task SendProductListingReminderNotificationAsync(int userId, int daysDelayed);

    Task SendInfluencerSeekingApprovalNotificationAsync();

    Task SendReminderForPickingAProductToInfluencerAsync(int influencerId, int daysWithoutPickingAProduct);

    Task SendCompleteSignupReminderNotificationAsync(Guid userKey);

    Task SendCompleteOnboardingReminderNotificationAsync(Guid userKey);
}
