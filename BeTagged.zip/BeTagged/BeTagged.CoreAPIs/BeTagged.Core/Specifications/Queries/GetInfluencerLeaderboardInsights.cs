﻿using System.Threading;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Security;
using BeTagged.Data.Repositories;
using BeTagged.Data.Services;

namespace BeTagged.Core.Specifications.Queries;

public static class GetInfluencerLeaderboardInsights
{
    public record Query(int Id) : IRequest<Response>;

    public class Handler : IRequestHandler<Query, Response>
    {
        private readonly IQueryService _queryService;

        private readonly ICurrentInfluencer _currentInfluencer;

        private readonly IReadOnlyRepository<Data.Entities.BrandProduct> _brandProductsRepository;

        public Handler(IQueryService queryService, ICurrentInfluencer currentInfluencer, IReadOnlyRepository<BrandProduct> brandProductsRepository)
        {
            _queryService = queryService;
            _currentInfluencer = currentInfluencer;
            _brandProductsRepository = brandProductsRepository;
        }

        public async Task<Response> Handle(Query request, CancellationToken cancellationToken)
        {
            var response = new Response();

            var doesProductExistsSpec =
                new DoesBrandProductExistsSpec(request.Id);

            var doesProductExists = await _brandProductsRepository.AnyAsync(doesProductExistsSpec, cancellationToken);

            if (!doesProductExists)
            {
                response.Error = ErrorType.ValidationError;
                response.ErrorMessage = ValidationMessages.ProductDoesNotExist;
                return response;
            }

            var parameters = new
            {
                @InfluencerId = _currentInfluencer.InfluencerId,
                @BrandProductId = request.Id
            };

            var queryResult = await _queryService.QueryMultipleAsync(BtQueryType.GetInfluencerLeaderboardInsights,
                null, parameters);

            using (queryResult)
            {
                response.Position = queryResult.ReadFirstOrDefault<int>();
                response.TotalInfluencers = queryResult.ReadFirstOrDefault<int>();

                response.SocialMediaDetails = new SocialMediaLeaderboardDetails()
                {
                    Facebook = queryResult.ReadFirstOrDefault<SocialMediaLeaderboardDetails.MediaPlatformInfo>(),
                    TikTok = queryResult.ReadFirstOrDefault<SocialMediaLeaderboardDetails.MediaPlatformInfo>(),
                    Instagram = queryResult.ReadFirstOrDefault<SocialMediaLeaderboardDetails.MediaPlatformInfo>(),
                    Twitter = queryResult.ReadFirstOrDefault<SocialMediaLeaderboardDetails.MediaPlatformInfo>(),
                };
            }

            return response;
        }
    }

    public class Response : Result
    {
        public int Position { get; set; }

        public int TotalInfluencers { get; set; }

        public SocialMediaLeaderboardDetails SocialMediaDetails { get; set; }
    }
}
