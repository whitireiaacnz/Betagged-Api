﻿using System;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Misc;
using BeTagged.Core.Services.Storage;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Core.Utils;
using BeTagged.Data.Constants;
using BeTagged.Data.Repositories;
using BeTagged.Data.Services;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;

namespace BeTagged.Core.Services.BrandProducts;

internal class DiscountCodesImportService : IDiscountCodesImportService
{
    private readonly IStorageService _storageService;
    private readonly IRepository<BrandProductDiscountCodesFile> _discountCodesFileRepo;
    private readonly IExcelDataReaderService _excelDataReader;
    private readonly IBtDb _db;
    private readonly IQueryService _queryService;
    private readonly ILogger _logger;

    public DiscountCodesImportService(IStorageService storageService, IRepository<BrandProductDiscountCodesFile> discountCodesFileRepo,
        IExcelDataReaderService excelDataReader, IBtDb db, IQueryService queryService, ILogger<DiscountCodesImportService> logger)
    {
        _storageService = storageService;
        _discountCodesFileRepo = discountCodesFileRepo;
        _excelDataReader = excelDataReader;
        _db = db;
        _queryService = queryService;
        _logger = logger;
    }

    public async Task ImportDiscountCodesAsync(int discountCodeFileId)
    {
        var discountCodeSpec = new GetDiscountCodeFile(discountCodeFileId);
        var discountCodeFile = await _discountCodesFileRepo.SingleAsync(discountCodeSpec);
        var product = discountCodeFile.BrandProduct;

        discountCodeFile.ImportStatusId = ImportStatus.InProgress;

        await _db.SaveChangesAsync();
        try
        {
            var excelUrl = _storageService.GetSignedUrl(discountCodeFile.FilePath);

            IList<object> discountCodes = new List<object>();

            var excelData = await _excelDataReader.GetExcelDataSetAsync(excelUrl);
            var rows = excelData.Tables[0].Rows;
            int i = 1;

            while (i < rows.Count)
            {
                var val = Double.NaN;

                if (val > 0)
                {
                    //
                }

                string discountCode = rows[i].ItemArray[0]!.ToString();

                if (discountCode.IsNullOrEmpty() || discountCode!.Length > DbConstants.DiscountCodeLength)
                {
                    continue;
                }

                discountCodes.Add(new
                {
                    @Code = discountCode,
                    @BrandProductId = discountCodeFile.BrandProductId,
                    @DiscountCodeFileId = discountCodeFileId
                });

                i++;
            }

            await _queryService.ExecuteAsync(BtQueryType.InsertDiscountCode, discountCodes);

            discountCodeFile.ImportStatusId = ImportStatus.Completed;
            discountCodeFile.BrandProduct.ProductStatusId = SystemProductStatusOption.Listed;

            product.LastDiscountCodeExhaustionNotificationPercentage = null;
        }
        catch (Exception e)
        {
            _logger.LogError(e, "Something went wrong while importing discount codes. {@Info}",
                new { DiscountFileId = discountCodeFileId, ExceptionMesgae = e.Message });

            discountCodeFile.ImportStatusId = ImportStatus.Failed;
            discountCodeFile.ImportError = e.ToString();
        }
        finally
        {
            await _db.SaveChangesAsync();
        }
    }

    public async Task<Result<bool>> ValidateDiscountCodesFileAsync(string url)
    {
        var result = new Result<bool>();

        if (!PropertyValidationUtil.IsExcelFile(url))
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = ValidationMessages.DiscountCodesFileMustBeExcelFile;
            return result;
        }

        var header = await _excelDataReader.GetHeaderDataSetAsync(url);
        var table = header.Tables[0];
        var rowCount = table.Rows.Count;

        if (rowCount == 0)
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = "Discount codes excel file doesn't have any row.";
            return result;
        }

        if ((string)table.Rows[0].ItemArray[0] != "Codes")
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = "Discount Codes excel file doesn't have 'Codes' column at index 1." +
                                  " Please download the sample file to know the structure.";
            return result;
        }

        if (rowCount == 1)
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = "Discount code excel file doesn't have any discount code.";
            return result;
        }

        if (rowCount > 500)
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = "You can upload at most 500 discount codes at once.";
            return result;
        }

        return result;
    }
}
