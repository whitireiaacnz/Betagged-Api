﻿using System;
using BeTagged.Data.Specifications;

namespace BeTagged.Core.Specifications.Queries;

public class GetInfluencerBankAccountSpec : ISingleResultQuerySpecification<InfluencerBankAccount, InfluencerBankAccount>
{
    public GetInfluencerBankAccountSpec(int influencerId, int bankAccountId)
    {
        Query = q => q
            .Where(x => x.InfluencerBankAccountId == bankAccountId)
            .Where(x => x.InfluencerId == influencerId);
    }

    public Func<IQueryable<InfluencerBankAccount>, IQueryable<InfluencerBankAccount>> Query { get; }
}
