﻿namespace BeTagged.Core.Constants;

public static class EmailConstants
{
    public const string DummyOtp = "123456";
    public const string EmailName = "Betagged";
    public const string EmailFrom = "diah@betagged.co";
    public const long BrandWelcomeTemplateId = 1;
    public const long InfluencerWelcomeTemplateId = 2;
    public const long OtpEmailTemplateId = 3;
    public const long BrandSignupTemplateId = 9;
    public const long BrandInvitationTemplateId = 10;
    public const long MemberRemovalTemplateId = 13;
}
