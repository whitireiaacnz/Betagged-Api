﻿using System.Threading;
using BeTagged.Core.CQRS;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Otp;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Utils;
using BeTagged.Data.Queries;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Commands.User;

public static class ChangeOtpInfo
{
    public class Command : ITransactionalRequest<Response>
    {
        public string Email { get; set; }

        public string CountryCode { get; set; }

        public string Phone { get; set; }
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator(ICurrentUser currentUser)
        {
            RuleFor(x => x.Email)
                .Cascade(CascadeMode.Stop)
                .NotEmpty().EmailAddress()
                .Must(x => !BlacklistedEmailDomains.BlacklistEmailDomains.Contains(EmailUtil.GetDomain(x)))
                .When(_ => currentUser.UserType == SystemUserTypeOption.BrandMember)
                .WithMessage(ValidationMessages.BlacklistedEmailMessage);

            RuleFor(x => x.CountryCode).NotEmpty();
            RuleFor(x => x.Phone).NotEmpty();
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly ICurrentUser _currentUser;
        private readonly IBtDb _db;
        private readonly IEmailOtpService _emailOtpService;
        private readonly IPhoneOtpService _phoneOtpService;

        public Handler(ICurrentUser currentUser, IBtDb db, IEmailOtpService emailOtpService, IPhoneOtpService phoneOtpService)
        {
            _currentUser = currentUser;
            _db = db;
            _emailOtpService = emailOtpService;
            _phoneOtpService = phoneOtpService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var response = new Response();

            // Check if email already exists and taken by another user.
            var dbEmailAddress = await _db.EmailAddresses.AsNoTracking().GetEmailAddressAsync(request.Email);
            if (dbEmailAddress is not null && dbEmailAddress.UserId != _currentUser.UserId)
            {
                response.Error = ErrorType.ValidationError;
                response.ErrorMessage = "Email is already taken.";
                return response;
            }

            // Check if phone is valid.
            var isValidPhone = PhoneUtil.IsValidPhone(request.CountryCode, request.Phone);
            if (!isValidPhone)
            {
                response.Error = ErrorType.ValidationError;
                response.ErrorMessage = "Phone is not valid.";
                return response;
            }

            var (countryCode, phoneNumber) = PhoneUtil.ParsePhone(request.CountryCode, request.Phone);

            // Check if phone is already exists and take by another user.
            var dbPhone = await _db.Phones.AsNoTracking().GetPhoneAsync(countryCode, phoneNumber);
            if (dbPhone is not null && dbPhone.UserId != _currentUser.UserId)
            {
                response.Error = ErrorType.ValidationError;
                response.ErrorMessage = "Phone is already taken.";
                return response;
            }

            var user = await _db.Users
                .Include(x => x.EmailAddresses.Where(y => y.IsPrimary))
                .Include(x => x.Phones.Where(y => y.IsPrimary))
                .Where(x => x.UserId == _currentUser.UserId)
                .SingleAsync(cancellationToken);

            var email = user.EmailAddresses.First();
            var phone = user.Phones.First();

            if (email.NormalizedEmailAddress != request.Email.ToUpper())
            {
                email.EmailAddress_ = request.Email;
                email.IsVerified = false;
            }

            if (phone.CountryCode != countryCode || phone.PhoneNumber != phoneNumber)
            {
                phone.CountryCode = countryCode;
                phone.PhoneNumber = phoneNumber;
                phone.IsVerified = false;
            }

            await _db.SaveChangesAsync(cancellationToken);

            // Send OTPs
            await _emailOtpService.GenerateAndSendEmailOtpAsync(email, SystemOtpUsageTypeOption.Verification);
            await _phoneOtpService.GenerateAndSendPhoneOtpAsync(phone, SystemOtpUsageTypeOption.Verification);

            response.PrimaryEmailAddress = request.Email;
            response.PrimaryEmailAddressId = email.EmailAddressId;
            response.IsEmailVerified = email.IsVerified;

            response.PrimaryPhone = phone.ToString();
            response.PrimaryPhoneId = phone.PhoneId;
            response.IsPhoneVerified = phone.IsVerified;

            return response;
        }
    }

    public class Response : Result
    {
        public string PrimaryEmailAddress { get; set; }

        public int PrimaryEmailAddressId { get; set; }

        public bool IsEmailVerified { get; set; }

        public string PrimaryPhone { get; set; }

        public int PrimaryPhoneId { get; set; }

        public bool IsPhoneVerified { get; set; }
    }
}
