﻿using System;
using BeTagged.Core.Dtos;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetInfluencerProfileSpec : ISingleResultQuerySpecification<Influencer, InfluencerProfileDto>
{
    public GetInfluencerProfileSpec(int influencerId)
    {
        Query = queryable => queryable
                .Include(x => x.Country)
                .Include(x => x.User)
                .ThenInclude(x => x.EmailAddresses)
                .Include(x => x.User)
                .ThenInclude(x => x.Phones)
                .Include(x => x.ProductSales)
                .Where(x => x.InfluencerId == influencerId)
                .Select(x => new InfluencerProfileDto()
                {
                    ProfilePicUrl = x.User.ProfilePicPath,
                    InfluencerName = x.User.Name,
                    InfluencerSinceUtc = x.CreatedAtUtc,
                    CurrencyCode = x.Country.CurrencyCode,
                    CurrencySymbol = x.Country.CurrencySymbol,
                    Sales = x.ProductSales.Sum(y => y.Quantity),
                    Commission = x.ProductSales.Sum(y => y.InfluencerPayableCommission),
                    SocialMedia = new InfluencerMediaAccountsModel()
                    {
                        Facebook = x.SocialMediaAccounts.Facebook.Username,
                        TikTok = x.SocialMediaAccounts.TikTok.Username,
                        Twitter = x.SocialMediaAccounts.Twitter.Username,
                        Instagram = x.SocialMediaAccounts.Instagram.Username
                    },
                    EmailAddresses = x.User.EmailAddresses.Select(y => new UserEmailAddressDto()
                    {
                        Id = y.EmailAddressId,
                        EmailAddress = y.EmailAddress_,
                        IsPrimary = y.IsPrimary
                    }),
                    Phones = x.User.Phones.Select(y => new UserPhoneDto()
                    {
                        Id = y.PhoneId,
                        Phone = $"{y.CountryCode}-{y.PhoneNumber}",
                        IsPrimary = y.IsPrimary
                    }),
                });
    }

    public Func<IQueryable<Influencer>, IQueryable<InfluencerProfileDto>> Query { get; }
}
