﻿using System.Threading;
using BeTagged.Core.CQRS;
using BeTagged.Core.Services.Notification;
using BeTagged.Core.Services.Otp;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Signup;

namespace BeTagged.Core.Commands.User;

public static class VerifyPhoneAndEmail
{
    public class Command : ITransactionalRequest<Response>
    {
        public int PhoneId { get; set; }

        public string PhoneOtp { get; set; }

        public int EmailAddressId { get; set; }

        public string EmailOtp { get; set; }
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.PhoneId).GreaterThan(0);
            RuleFor(x => x.EmailAddressId).GreaterThan(0);
            RuleFor(x => x.PhoneOtp).NotEmpty();
            RuleFor(x => x.EmailOtp).NotEmpty();
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly ICurrentUser _currentUser;
        private readonly IPhoneOtpService _phoneOtpService;
        private readonly IEmailOtpService _emailOtpService;
        private readonly INotificationService _notificationService;
        private readonly ICompleteOnboardingReminderService _completeOnboardingReminderService;

        public Handler(ICurrentUser currentUser, IPhoneOtpService phoneOtpService,
            IEmailOtpService emailOtpService, INotificationService notificationService,
            ICompleteOnboardingReminderService completeOnboardingReminderService)
        {
            _currentUser = currentUser;
            _phoneOtpService = phoneOtpService;
            _emailOtpService = emailOtpService;
            _notificationService = notificationService;
            _completeOnboardingReminderService = completeOnboardingReminderService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var phoneVerificationResult = await _phoneOtpService.VerifyPhoneAsync(
                _currentUser.UserId,
                request.PhoneId,
                request.PhoneOtp,
                SystemOtpUsageTypeOption.Verification);

            var response = new Response();

            if (!phoneVerificationResult.IsSuccess)
            {
                response.ErrorMessage = phoneVerificationResult.ErrorMessage;
                response.Error = phoneVerificationResult.Error;
                return response;
            }

            var emailVerificationResult = await _emailOtpService.VerifyEmailAsync(
                _currentUser.UserId,
                request.EmailAddressId,
                request.EmailOtp,
                SystemOtpUsageTypeOption.Verification);

            if (!emailVerificationResult.IsSuccess)
            {
                response.ErrorMessage = emailVerificationResult.ErrorMessage;
                response.Error = emailVerificationResult.Error;
                return response;
            }

            _notificationService.SendSignupCompletedNotification(_currentUser.UserKey);
            _completeOnboardingReminderService.ScheduleCompleteOnboardingReminderJob(_currentUser.UserId, _currentUser.UserType);

            return response;
        }
    }

    public class Response : Result
    {
    }
}
