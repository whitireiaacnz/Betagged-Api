﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class AddedAuditColumnToBrandProduct : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AddColumn<int>(
            name: "created_by_user_id",
            schema: "public",
            table: "brand_products",
            type: "integer",
            nullable: false,
            defaultValue: 0);

        migrationBuilder.AddColumn<int>(
            name: "modified_by_user_id",
            schema: "public",
            table: "brand_products",
            type: "integer",
            nullable: false,
            defaultValue: 0);

        migrationBuilder.CreateIndex(
            name: "ix_brand_products_created_by_user_id",
            schema: "public",
            table: "brand_products",
            column: "created_by_user_id");

        migrationBuilder.CreateIndex(
            name: "ix_brand_products_modified_by_user_id",
            schema: "public",
            table: "brand_products",
            column: "modified_by_user_id");

        migrationBuilder.AddForeignKey(
            name: "fk_brand_products_users_created_by_user_id",
            schema: "public",
            table: "brand_products",
            column: "created_by_user_id",
            principalSchema: "public",
            principalTable: "users",
            principalColumn: "user_id",
            onDelete: ReferentialAction.Restrict);

        migrationBuilder.AddForeignKey(
            name: "fk_brand_products_users_modified_by_user_id",
            schema: "public",
            table: "brand_products",
            column: "modified_by_user_id",
            principalSchema: "public",
            principalTable: "users",
            principalColumn: "user_id",
            onDelete: ReferentialAction.Restrict);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropForeignKey(
            name: "fk_brand_products_users_created_by_user_id",
            schema: "public",
            table: "brand_products");

        migrationBuilder.DropForeignKey(
            name: "fk_brand_products_users_modified_by_user_id",
            schema: "public",
            table: "brand_products");

        migrationBuilder.DropIndex(
            name: "ix_brand_products_created_by_user_id",
            schema: "public",
            table: "brand_products");

        migrationBuilder.DropIndex(
            name: "ix_brand_products_modified_by_user_id",
            schema: "public",
            table: "brand_products");

        migrationBuilder.DropColumn(
            name: "created_by_user_id",
            schema: "public",
            table: "brand_products");

        migrationBuilder.DropColumn(
            name: "modified_by_user_id",
            schema: "public",
            table: "brand_products");
    }
}
