﻿using System;
using BeTagged.Data.Specifications;

namespace BeTagged.Core.Specifications.Queries;

public class GetBrandPlatformCommissionPercentageSpec : ISingleResultQuerySpecification<BrandOrganization, int>
{
    public GetBrandPlatformCommissionPercentageSpec(int brandOrganizationId)
    {
        Query = q => q.Where(x => x.BrandOrganizationId == brandOrganizationId)
            .Select(x => x.PlatformCommissionPercentage);
    }

    public Func<IQueryable<BrandOrganization>, IQueryable<int>> Query { get; }
}
