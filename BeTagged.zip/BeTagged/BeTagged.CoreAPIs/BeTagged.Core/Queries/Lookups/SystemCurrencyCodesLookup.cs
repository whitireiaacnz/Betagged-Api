﻿using System.Threading;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Queries.Lookups;

public static class SystemCurrencyCodesLookup
{
    public record Query : IRequest<IEnumerable<SystemCurrencyCodeLookupItem>>;

    public class Handler : IRequestHandler<Query, IEnumerable<SystemCurrencyCodeLookupItem>>
    {
        private readonly IBtDb _db;

        public Handler(IBtDb db)
        {
            _db = db;
        }

        public async Task<IEnumerable<SystemCurrencyCodeLookupItem>> Handle(Query request, CancellationToken cancellationToken)
        {
            return await _db.SystemCurrencyCodes
                .AsNoTracking()
                .OrderBy(x => x.SystemCurrencyCodeId)
                .Select(x => new SystemCurrencyCodeLookupItem((int)x.SystemCurrencyCodeId, x.Name, x.Symbol))
                .ToListAsync(cancellationToken);
        }
    }
}
