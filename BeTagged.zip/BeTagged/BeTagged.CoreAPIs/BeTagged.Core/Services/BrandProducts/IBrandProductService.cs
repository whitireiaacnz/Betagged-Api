﻿using System.Threading;
using BeTagged.Core.Dtos;

namespace BeTagged.Core.Services.BrandProducts;

public interface IBrandProductService
{
    Task<BrandProductModel> AddBrandProductAsync(AddBrandProductDto dto, CancellationToken cancellationToken = default);

    Task<BrandProductModel> UpdateBrandProductAsync(UpdateBrandProductDto brandProductDto, int brandOrganizationId, CancellationToken cancellationToken = default);

    Task<Result<string>> UploadDiscountCodes(int brandProductId, string fileUrl);

    Task<Result<bool>> UnlistProductAsync(int brandOrganizationId, int brandProductId);

    Task<IEnumerable<LookupItem>> GetBrandProductCountries(int brandOrganizationId, CancellationToken cancellationToken = default);

    Task<Result<UploadSalesDataResponseDto>> UploadSalesData(int brandProductId, string fileUrl);
}
