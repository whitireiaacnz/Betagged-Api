﻿using System.Collections.Generic;
using BeTagged.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(BrandProductsSaleDataFileEntityConfiguration))]
public class BrandProductsSalesDataFile : BaseEntity
{
    public BrandProductsSalesDataFile()
    {
        ProductSales = new List<ProductSale>();
    }

    public int BrandProductsSaleDataFileId { get; set; }

    public string FilePath { get; set; }

    public int BrandProductId { get; set; }

    public int UploadedByMemberId { get; set; }

    public ImportStatus ImportStatusId { get; set; }

    public string ImportError { get; set; }

    // Foreign Keys
    public BrandProduct BrandProduct { get; set; }

    public BrandMember UploadedByMember { get; set; }

    // Reverse navigation
    public ICollection<ProductSale> ProductSales { get; set; }
}
