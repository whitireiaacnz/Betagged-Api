﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Entities;

[Table("system_product_approval_statuses_lut")]
public class SystemApprovalStatus
{
    public SystemApprovalStatus()
    {
        ProductPromotionRequests = new List<ProductPromotionRequest>();
    }

    public SystemApprovalStatusOption SystemApprovalStatusId { get; set; }

    [Required, MaxLength(32)]
    public string Name { get; set; }

    // Reverse Navigation
    public ICollection<ProductPromotionRequest> ProductPromotionRequests { get; set; }
}
