﻿namespace BeTagged.Core.Configurations;

public class SendGridConfiguration
{
    public const string Section = "SendGrid";

    public string ApiKey { get; set; }
}
