﻿using System.Collections.Generic;
using BeTagged.Common.Extensions;
using BeTagged.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(BrandMemberEntityConfiguration))]
public class BrandMember : BaseEntity
{
    public BrandMember()
    {
        BrandMemberships = new List<BrandMembership>();
        BrandProductsSaleDataFiles = new List<BrandProductsSalesDataFile>();
        SentBrandMembershipInvitations = new List<BrandMembershipInvitation>();
    }

    public int BrandMemberId { get; set; }

    public int UserId { get; set; }

    public int? PrimaryBrandOrganizationId { get; set; }

    // Foreign keys
    public User User { get; set; }

    public BrandOrganization PrimaryBrandOrganization { get; set; }

    // Reverse navigation
    public ICollection<BrandMembership> BrandMemberships { get; set; }

    public ICollection<BrandProductsSalesDataFile> BrandProductsSaleDataFiles { get; set; }

    public ICollection<BrandMembershipInvitation> SentBrandMembershipInvitations { get; set; }

    public bool IsOnboarded()
    {
        return User.Name.IsNotNullOrEmpty();
    }
}
