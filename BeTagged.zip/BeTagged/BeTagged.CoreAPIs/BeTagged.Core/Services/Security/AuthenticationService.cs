﻿using BeTagged.Common.Extensions;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Services.Security;

using System;
using System.Linq;
using System.Threading;
using BeTagged.Core.Enums;
using BeTagged.Core.Models;
using BeTagged.Core.Services.Otp;
using BeTagged.Core.Utils;
using Microsoft.EntityFrameworkCore;

internal class AuthenticationService : IAuthenticationService
{
    private readonly IBtDb _db;
    private readonly IPasswordHasher _passwordHasher;
    private readonly IAuthTokenService _authTokenService;
    private readonly IPhoneOtpService _phoneOtpService;
    private readonly IReadOnlyRepository<BrandMembershipInvitation> _brandMembershipInvitationsRepo;
    private readonly IReadOnlyRepository<BrandMembership> _brandMembershipsRepo;

    public AuthenticationService(IBtDb db, IPasswordHasher passwordHasher, IAuthTokenService authTokenService,
        IPhoneOtpService phoneOtpService, IReadOnlyRepository<BrandMembershipInvitation> brandMembershipInvitationsRepo, IReadOnlyRepository<BrandMembership> brandMembershipsRepo)
    {
        _db = db;
        _passwordHasher = passwordHasher;
        _authTokenService = authTokenService;
        _phoneOtpService = phoneOtpService;
        _brandMembershipInvitationsRepo = brandMembershipInvitationsRepo;
        _brandMembershipsRepo = brandMembershipsRepo;
        _phoneOtpService = phoneOtpService;
    }

    public async Task<InfluencerAuthenticationResponse> AuthenticateInfluencerAsync(string emailAddress, string password)
    {
        var response = new InfluencerAuthenticationResponse();

        var normalizedEmail = emailAddress.ToUpper();

        var email = await _db.EmailAddresses
            .AsNoTracking()
            .SingleOrDefaultAsync(x => x.NormalizedEmailAddress == normalizedEmail && x.IsPrimary);

        if (email is null)
        {
            response.Error = ErrorType.ValidationError;
            response.ErrorMessage = ValidationMessages.EmailDoesNotExists;
            return response;
        }

        var influencer = await _db.Influencers
            .Include(x => x.User)
            .Include(x => x.Categories)
            .Where(x => x.User.UserId == email.UserId)
            .Where(x => x.User.UserType == SystemUserTypeOption.Influencer)
            .Where(x => x.UserId == email.UserId)
            .SingleOrDefaultAsync();

        if (influencer is null || influencer.User.PasswordHash != _passwordHasher.GetHashedPassword(password, influencer.User.Salt))
        {
            response.ErrorMessage = "Invalid email or password";
            response.Error = ErrorType.Unauthenticated;
            return response;
        }

        return await GetInfluencerAuthenticationResponse(email.UserId!.Value, CancellationToken.None);
    }

    public async Task<BrandMemberAuthenticationResponse> AuthenticateBrandMemberAsync(string emailAddress,
        string password, string invitationKey)
    {
        var response = new BrandMemberAuthenticationResponse();

        var normalizedEmail = emailAddress.ToUpper();

        var email = await _db.EmailAddresses
            .AsNoTracking()
            .SingleOrDefaultAsync(x => x.NormalizedEmailAddress == normalizedEmail && x.IsPrimary);

        if (email is null)
        {
            response.Error = ErrorType.ValidationError;
            response.ErrorMessage = ValidationMessages.EmailDoesNotExists;
            return response;
        }

        var brandMember = await _db.BrandMembers
            .AsNoTracking()
            .Include(x => x.User)
            .Where(x => x.User.UserType == SystemUserTypeOption.BrandMember)
            .Where(x => x.UserId == email.UserId)
            .SingleOrDefaultAsync();

        if (brandMember is null || brandMember.User.PasswordHash != _passwordHasher.GetHashedPassword(password, brandMember.User.Salt))
        {
            response.ErrorMessage = "Invalid email or password";
            response.Error = ErrorType.Unauthenticated;
            return response;
        }

        return await GetBrandMemberAuthenticationResponse(email.UserId!.Value, invitationKey);
    }

    public async Task<BrandMemberAuthenticationResponse> AuthenticateBrandMemberByPhoneAsync(string countryCode, string phoneNumber, string otp,
        string invitationKey, CancellationToken cancellationToken = default)
    {
        var response = new BrandMemberAuthenticationResponse();

        var isValidPhone = PhoneUtil.IsValidPhone(countryCode, phoneNumber);
        if (!isValidPhone)
        {
            response.ErrorMessage = "Phone is not valid.";
            response.Error = ErrorType.ValidationError;
            return response;
        }

        var (parsedCountryCode, parsedPhoneNumber) = PhoneUtil.ParsePhone(countryCode, phoneNumber);

        var phone = await _db.Phones.Where(x => x.PhoneNumber == parsedPhoneNumber && x.CountryCode == parsedCountryCode)
            .SingleOrDefaultAsync(cancellationToken);

        if (phone is null)
        {
            response.ErrorMessage = "Phone does not exist.";
            response.Error = ErrorType.ValidationError;
            return response;
        }

        var verificationResult = await _phoneOtpService.VerifyPhoneAsync(phone.UserId!.Value, phone.PhoneId, otp, SystemOtpUsageTypeOption.Login);
        if (!verificationResult.IsSuccess)
        {
            response.ErrorMessage = verificationResult.ErrorMessage;
            response.Error = verificationResult.Error;
            return response;
        }

        return await GetBrandMemberAuthenticationResponse(phone.UserId.Value, invitationKey, cancellationToken);
    }

    public async Task<InfluencerAuthenticationResponse> AuthenticateInfluencerByPhoneAsync(string countryCode, string phoneNumber, string otp,
        CancellationToken cancellationToken = default)
    {
        var response = new InfluencerAuthenticationResponse();

        var isValidPhone = PhoneUtil.IsValidPhone(countryCode, phoneNumber);
        if (!isValidPhone)
        {
            response.ErrorMessage = "Phone is not valid.";
            response.Error = ErrorType.ValidationError;
            return response;
        }

        var (parsedCountryCode, parsedPhoneNumber) = PhoneUtil.ParsePhone(countryCode, phoneNumber);

        var phone = await _db.Phones.Where(x => x.PhoneNumber == parsedPhoneNumber && x.CountryCode == parsedCountryCode)
            .SingleOrDefaultAsync(cancellationToken);

        if (phone is null)
        {
            response.ErrorMessage = "Phone does not exist.";
            response.Error = ErrorType.ValidationError;
            return response;
        }

        var verificationResult = await _phoneOtpService.VerifyPhoneAsync(phone.UserId.Value, phone.PhoneId, otp,
            SystemOtpUsageTypeOption.Login);

        if (!verificationResult.IsSuccess)
        {
            response.ErrorMessage = verificationResult.ErrorMessage;
            response.Error = verificationResult.Error;
            return response;
        }

        return await GetInfluencerAuthenticationResponse(phone.UserId.Value, cancellationToken);
    }

    public async Task<BrandMemberAuthenticationResponse> GetBrandMemberAuthenticationResponse(int userId, string invitationKey,
        CancellationToken cancellationToken = default)
    {
        var response = new BrandMemberAuthenticationResponse();

        var brandMember = await _db.BrandMembers
            .Include(x => x.User)
            .ThenInclude(x => x.Phones.Where(y => y.IsPrimary))
            .Include(x => x.User)
            .ThenInclude(x => x.EmailAddresses.Where(e => e.IsPrimary))
            .Where(x => x.User.UserId == userId)
            .Where(x => x.User.UserType == SystemUserTypeOption.BrandMember)
            .Where(x => x.UserId == userId)
            .SingleOrDefaultAsync(cancellationToken);

        var user = brandMember!.User;
        var email = user.EmailAddresses.First();
        var phone = user.Phones.First();

        BrandMembership brandMembership;

        BrandMembershipInvitation invitation = null;

        if (invitationKey is not null)
        {
            var getInvitationSpec = new GetBrandMembershipInvitationForSigninSpec(userId, invitationKey);
            invitation = await _brandMembershipInvitationsRepo.SingleOrDefaultAsync(getInvitationSpec, cancellationToken);
        }

        // If invitation is not null then log them to the invitation's brand membership by default.
        if (invitation?.BrandMembership is not null)
        {
            brandMembership = invitation.BrandMembership;
        }
        else if (brandMember.PrimaryBrandOrganizationId.HasValue)
        {
            brandMembership = await _db.BrandMemberships.AsNoTracking()
                .Include(x => x.BrandOrganization)
                .ThenInclude(x => x.Categories)
                .Where(x => x.BrandMemberId == brandMember.BrandMemberId)
                .Where(x => x.BrandOrganizationId == brandMember.PrimaryBrandOrganizationId.Value)
                .Where(x => !x.IsDisabled)
                .SingleOrDefaultAsync(cancellationToken);
        }
        else
        {
            brandMembership = await _db.BrandMemberships.AsNoTracking()
                .Include(x => x.BrandOrganization)
                .ThenInclude(x => x.Categories)
                .Where(x => x.BrandMemberId == brandMember.BrandMemberId)
                .Where(x => !x.IsDisabled)
                .FirstOrDefaultAsync(cancellationToken);
        }

        // If brand membership is null when we reach here that means, member is not a part of any organization
        if (brandMembership is null)
        {
            brandMembership = new BrandMembership()
            {
                RoleId = SystemRoleOption.Administrator,
                BrandOrganization = new BrandOrganization()
            };
        }

        brandMember.User.LastActivityAtUtc = DateTime.UtcNow;
        brandMember.User.LastLoginAtUtc = DateTime.UtcNow;

        await _db.SaveChangesAsync(cancellationToken);

        response.AccessToken = _authTokenService.GetTokenForBrandMember(brandMember, brandMembership);

        var brandOrganization = brandMembership!.BrandOrganization;

        response.BrandMemberInfo = new BrandMemberAuthenticationInfo()
        {
            UserKey = brandMember.User.UserKey,
            IsUserOnBoarded = brandMember.IsOnboarded(),
            IsBrandOnBoarded = brandOrganization.IsOnboarded(),
            PrimaryEmailAddressId = email.EmailAddressId,
            IsEmailVerified = email.IsVerified,
            PrimaryEmailAddress = email.EmailAddress_,
            PrimaryPhoneId = phone.PhoneId,
            PrimaryPhone = phone.ToString(),
            IsPhoneVerified = phone.IsVerified,
            FullName = brandMember.User.Name,
        };

        return response;
    }

    public async Task<Result<BrandMemberAuthenticationResponse>> SwitchBrandOrganization(int brandMemberId, int brandOrganizationId)
    {
        var brandMembershipSpec = new GetBrandMembershipForSwitchingBrandSpec(brandMemberId, brandOrganizationId);
        var brandMembership = await _brandMembershipsRepo.SingleOrDefaultAsync(brandMembershipSpec);

        var response = new Result<BrandMemberAuthenticationResponse>();

        if (brandMembership is null)
        {
            response.Error = ErrorType.Unauthenticated;
            response.ErrorMessage = "Brand doesn't exists.";
            return response;
        }

        var brandMember = brandMembership.BrandMember;
        var email = brandMember.User.EmailAddresses.First();
        var phone = brandMember.User.Phones.First();

        response.Data = new BrandMemberAuthenticationResponse
        {
            AccessToken = _authTokenService.GetTokenForBrandMember(brandMember, brandMembership)
        };

        var brandOrganization = brandMembership!.BrandOrganization;

        response.Data.BrandMemberInfo = new BrandMemberAuthenticationInfo()
        {
            UserKey = brandMember.User.UserKey,
            IsUserOnBoarded = brandMember.IsOnboarded(),
            IsBrandOnBoarded = brandOrganization.LegalName.IsNotNullOrEmpty() && brandOrganization.Categories.Count > 0,
            PrimaryEmailAddressId = email.EmailAddressId,
            IsEmailVerified = email.IsVerified,
            PrimaryEmailAddress = email.EmailAddress_,
            PrimaryPhoneId = phone.PhoneId,
            PrimaryPhone = phone.ToString(),
            IsPhoneVerified = phone.IsVerified,
        };

        return response;
    }

    private async Task<InfluencerAuthenticationResponse> GetInfluencerAuthenticationResponse(int userId,
        CancellationToken cancellationToken)
    {
        var response = new InfluencerAuthenticationResponse();

        var influencer = await _db.Influencers
            .Include(x => x.User)
            .ThenInclude(x => x.EmailAddresses.Where(y => y.IsPrimary))
            .Include(x => x.User)
            .ThenInclude(x => x.Phones.Where(y => y.IsPrimary))
            .Include(x => x.Categories)
            .Where(x => x.User.UserId == userId)
            .SingleAsync(cancellationToken);

        influencer.User.LastActivityAtUtc = DateTime.UtcNow;
        influencer.User.LastLoginAtUtc = DateTime.UtcNow;

        await _db.SaveChangesAsync(cancellationToken);

        var email = influencer.User.EmailAddresses.First();
        var phone = influencer.User.Phones.First();

        response.AccessToken = _authTokenService.GetTokenForInfluencer(influencer);

        response.InfluencerInfo = new InfluencerBasicInfo()
        {
            UserKey = influencer.User.UserKey,
            IsInfluencerOnBoarded = influencer.IsOnBoarded(),
            PrimaryEmailAddress = email.EmailAddress_,
            PrimaryEmailAddressId = email.EmailAddressId,
            IsEmailVerified = email.IsVerified,
            PrimaryPhone = phone.ToString(),
            PrimaryPhoneId = phone.PhoneId,
            IsPhoneVerified = phone.IsVerified
        };

        return response;
    }
}
