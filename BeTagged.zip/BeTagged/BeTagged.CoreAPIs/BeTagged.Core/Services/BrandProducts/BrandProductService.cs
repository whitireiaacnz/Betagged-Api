﻿using System;
using System.Threading;
using AutoMapper;
using BeTagged.Core.Dtos;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.BackgroundWork;
using BeTagged.Core.Services.Communication;
using BeTagged.Core.Services.Notification;
using BeTagged.Core.Services.Promotion;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Shopify;
using BeTagged.Core.Services.Storage;
using BeTagged.Core.Services.UrlUtils;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Core.Utils;
using BeTagged.Data.Queries;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Services.BrandProducts;

internal class BrandProductService : IBrandProductService
{
    private readonly IBtDb _db;
    private readonly ICurrentBrandMember _currentBrandMember;
    private readonly IMapper _mapper;
    private readonly IStorageService _storageService;
    private readonly IRepository<SystemCountry> _countriesRepository;
    private readonly IRepository<BrandProduct> _brandProductsRepository;
    private readonly IBackgroundWorker _backgroundWorker;
    private readonly IDiscountCodesImportService _discountCodesImportService;
    private readonly ISalesDataImportService _salesDataImportService;
    private readonly IRepository<SystemCategory> _categoryRepository;
    private readonly IProductPromotionService _productPromotionService;
    private readonly IRepository<BrandOrganization> _brandOrganizationsRepo;
    private readonly IShopifyService _shopifyService;
    private readonly IUrlBuilder _urlBuilder;
    private readonly ISaleDataUploadReminderService _saleDataUploadReminderService;
    private readonly INotificationService _notificationService;

    public BrandProductService(IBtDb db, ICurrentBrandMember currentBrandMember, IMapper mapper, IStorageService storageService,
        IRepository<SystemCountry> countriesRepository, IRepository<BrandProduct> brandProductsRepository,
        IBackgroundWorker backgroundWorker, IDiscountCodesImportService discountCodesImportService,
        IEmailService emailService, ISalesDataImportService salesDataImportService, IRepository<SystemCategory> categoryRepository,
        IProductPromotionService productPromotionService, IRepository<BrandOrganization> brandOrganizationsRepo, IShopifyService shopifyService,
        IUrlBuilder urlBuilder, ISaleDataUploadReminderService saleDataUploadReminderService, INotificationService notificationService)
    {
        _db = db;
        _currentBrandMember = currentBrandMember;
        _mapper = mapper;
        _storageService = storageService;
        _countriesRepository = countriesRepository;
        _brandProductsRepository = brandProductsRepository;
        _backgroundWorker = backgroundWorker;
        _discountCodesImportService = discountCodesImportService;
        _salesDataImportService = salesDataImportService;
        _categoryRepository = categoryRepository;
        _productPromotionService = productPromotionService;
        _brandOrganizationsRepo = brandOrganizationsRepo;
        _shopifyService = shopifyService;
        _urlBuilder = urlBuilder;
        _saleDataUploadReminderService = saleDataUploadReminderService;
        _notificationService = notificationService;
    }

    public string Name { get; set; }

    public static string TwoNumbers()
    {
        return "f";
    }

    public async Task<BrandProductModel> AddBrandProductAsync(AddBrandProductDto dto, CancellationToken cancellationToken = default)
    {
        var getCountrySpec = new GetCountrySpec(dto.Country);

        var country = await _countriesRepository.SingleOrDefaultAsync(getCountrySpec, cancellationToken);

        if (country is null)
        {
            return new BrandProductModel { Error = ErrorType.ValidationError, ErrorMessage = ValidationMessages.InvalidCountry };
        }

        if (dto.ProductUrls.EcommercePlatformUrl is null && dto.ProductUrls.CompanyProductUrl is null && dto.ProductIncommDetails is null)
        {
            return new BrandProductModel { Error = ErrorType.ValidationError, ErrorMessage = "Need to provide at least one selling platform." };
        }

        if (dto.BuyerDiscountPercentage == 0 && dto.ProductIncommDetails == null)
        {
            return new BrandProductModel { Error = ErrorType.ValidationError, ErrorMessage = "Buyer discount percentage 0 is only allowed for product listing on Incomm." };
        }

        if (!IsOnlyOnePlatformProvided(dto))
        {
            return new BrandProductModel { Error = ErrorType.ValidationError, ErrorMessage = "Product could be sold only on one platform." };
        }

        if (dto.BuyerDiscountPercentage > 0)
        {
            var discountCodesValidationResult = await _discountCodesImportService
                .ValidateDiscountCodesFileAsync(_storageService.GetSignedUrl(dto.DiscountCodesFileUrl));

            if (!discountCodesValidationResult.IsSuccess)
            {
                var response = new BrandProductModel()
                {
                    Error = discountCodesValidationResult.Error,
                    ErrorMessage = discountCodesValidationResult.ErrorMessage,
                };

                response.Errors.Add(new ErrorItem(discountCodesValidationResult.ErrorMessage, nameof(dto.DiscountCodesFileUrl)));

                return response;
            }
        }

        var brandOrganization = await
            _brandOrganizationsRepo
                .SingleAsync(new GetBrandOrganizationSpec(_currentBrandMember.BrandOrganizationId), cancellationToken);

        var bannerImageUrl = FileUtils.GetFileAbsolutePath(dto.BannerImageUrl);
        var showCaseMediaUrls = dto.ShowCaseMediaUrls.Select(FileUtils.GetFileAbsolutePath).ToList();

        var mediaKits = new ProductSocialMediaKit()
        {
            InstagramMediaUrl = FileUtils.GetFileAbsolutePath(dto.SocialMediaKits.InstagramMediaUrl),
            FacebookMediaKitUrl = FileUtils.GetFileAbsolutePath(dto.SocialMediaKits.FacebookMediaKitUrl),
            TwitterMediaKitUrl = FileUtils.GetFileAbsolutePath(dto.SocialMediaKits.TwitterMediaKitUrl),
            TikTokMediaKitUrl = FileUtils.GetFileAbsolutePath(dto.SocialMediaKits.TikTokMediaKitUrl)
        };

        var product = new BrandProduct
        {
            Name = dto.Name,
            ProductCode = dto.ProductCode,
            Description = dto.Description,
            Price = dto.Price,
            CommissionPercentage = (int)dto.CommissionPercentage,
            BannerImageUrl = bannerImageUrl,
            ShowCaseMediaUrls = showCaseMediaUrls,
            BrandOrganizationId = _currentBrandMember.BrandOrganizationId,
            BuyerDiscountPercentage = dto.BuyerDiscountPercentage,
            IsApprovalBasedOffer = dto.IsApprovalBasedOffer,
            ProductStatusId = dto.ProductStatus,
            SocialMediaKits = mediaKits,
            Hashtags = dto.Hashtags,
            CreatedByUserId = _currentBrandMember.UserId,
            ModifiedByUserId = _currentBrandMember.UserId,
            Country = country,
            City = dto.City,
        };

        if (dto.ProductStatus == SystemProductStatusOption.Listed)
        {
            product.ListedOnUtc = DateTime.UtcNow;
        }

        if (dto.City is not null && dto.Location is not null)
        {
            product.SetLocation(dto.Location.Longitude, dto.Location.Latitude);
        }

        if (dto.ProductUrls.CompanyProductUrl is not null)
        {
            product.ProductUrlTypeId = SystemProductUrlOption.Company;
            product.ProductUrl = dto.ProductUrls.CompanyProductUrl;
        }
        else if (dto.ProductUrls.EcommercePlatformUrl is not null)
        {
            product.ProductUrlTypeId = SystemProductUrlOption.EcommercePlatform;
            product.ProductUrl = dto.ProductUrls.EcommercePlatformUrl;
        }
        else
        {
            product.ProductUrlTypeId = SystemProductUrlOption.InCommMall;
        }

        if (product.ProductUrlTypeId == SystemProductUrlOption.InCommMall)
        {
            foreach (var variantDetail in dto.ProductIncommDetails.VariantDetails)
            {
                if (!variantDetail.ProductImageUrls.Any())
                {
                    return new BrandProductModel { Error = ErrorType.ValidationError, ErrorMessage = "Please provide image for the product." };
                }

                if (variantDetail is not null)
                {
                    variantDetail.ProductImageUrls = variantDetail.ProductImageUrls.Select(FileUtils.GetFileAbsolutePath).ToList();
                }
            }
        }

        var incommProductDetails = product.ProductUrlTypeId == SystemProductUrlOption.InCommMall ? new ProductIncommDetail()
        {
            IsDeliveredByIncommTeam = dto.ProductIncommDetails.IsDeliveredByIncommTeam,
            IsDeliveredByBrand = dto.ProductIncommDetails.IsDeliveredByBrand,
            VariantDetails = dto.ProductIncommDetails.VariantDetails,
            Dimension = dto.ProductIncommDetails.Dimension,
            Weight = dto.ProductIncommDetails.Weight,
            InventoryLocation = dto.ProductIncommDetails.InventoryLocation,
            ZipCode = dto.ProductIncommDetails.ZipCode,
            ContactPersonNumber = dto.ProductIncommDetails.ContactPersonNumber,
        }
        : null;

        product.ProductIncommDetails = incommProductDetails;

        product.Categories = await _db.SystemCategories.GetCategoriesAsync(dto.Categories, cancellationToken);
        product.SetCommissionPercentage(brandOrganization.PlatformCommissionPercentage, (int)dto.CommissionPercentage);

        _db.BrandProducts.Add(product);

        if (product.ProductUrlTypeId == SystemProductUrlOption.InCommMall)
        {
            (long shopifyProductId, string url) = await _shopifyService.CreateProductAsync(dto, product.BrandProductKey);
            product.ShopifyProductId = shopifyProductId;
            product.ProductUrl = url;
        }

        await _db.SaveChangesAsync(cancellationToken);
        var val = "The square root of 2.0 is " + Math.Sqrt(2.0);
        var createdProduct = _mapper.Map<BrandProduct, BrandProductModel>(product);
        createdProduct.SignTheUrls(_storageService);

        createdProduct.ProductUrls = dto.ProductUrls;

        if (dto.BuyerDiscountPercentage > 0)
        {
            var discountCodeFile = new BrandProductDiscountCodesFile()
            {
                FilePath = FileUtils.GetFileAbsolutePath(dto.DiscountCodesFileUrl),
                ImportStatusId = ImportStatus.Queued
            };

            product.DiscountCodesFiles.Add(discountCodeFile);

            await _db.SaveChangesAsync(cancellationToken);

            _backgroundWorker.Enqueue(() => _discountCodesImportService
                   .ImportDiscountCodesAsync(discountCodeFile.BrandProductDiscountCodesFileId));
        }

        var productUrl = _urlBuilder.BuildProductDetailsUrl(product.BrandProductId);

        _notificationService.SendProductListedNotification(_currentBrandMember.UserKey, product.BrandProductId, productUrl, product.Name);

        if (product.ProductUrlTypeId is not SystemProductUrlOption.InCommMall)
        {
            _saleDataUploadReminderService.ScheduleSalesDataUploadReminderJob(product.BrandProductId);
        }

        return createdProduct;
    }

    public async Task<Result<string>> UploadDiscountCodes(int brandProductId, string fileUrl)
    {
        var getProductSpec = new GetBrandProductByIdSpec(_currentBrandMember.BrandOrganizationId, brandProductId);

        var product = await _brandProductsRepository.SingleOrDefaultAsync(getProductSpec);

        var response = new Result<string>();

        if (product is null)
        {
            response.Error = ErrorType.ValidationError;
            response.ErrorMessage = ValidationMessages.ProductDoesNotExist;
            return response;
        }

        // TODO: remove organization id check
        if (product.BuyerDiscountPercentage == 0 && _currentBrandMember.BrandOrganizationId != BrandOrganizationIds.GrabOrgId) // allow discount codes to be uploaded for a particular org.
        {
            response.Error = ErrorType.ValidationError;
            response.ErrorMessage = "Discount codes can not be uploaded for the products where buyer's discount is 0.";
            return response;
        }

        var excelValidationResult = await _discountCodesImportService
            .ValidateDiscountCodesFileAsync(_storageService.GetSignedUrl(fileUrl));

        if (!excelValidationResult.IsSuccess)
        {
            response.Error = excelValidationResult.Error;
            response.ErrorMessage = excelValidationResult.ErrorMessage;
            return response;
        }

        var discountCodesFile = new BrandProductDiscountCodesFile()
        {
            FilePath = FileUtils.GetFileAbsolutePath(fileUrl),
            BrandProductId = product.BrandProductId,
            ImportStatusId = ImportStatus.Queued
        };

        _db.BrandProductDiscountCodesFiles.Add(discountCodesFile);

        await _db.SaveChangesAsync();

        _backgroundWorker.Enqueue(() => _discountCodesImportService
            .ImportDiscountCodesAsync(discountCodesFile.BrandProductDiscountCodesFileId));
        response.Data = "Discount codes import has been started. The codes will be imported in the background.";
        return response;
    }

    public async Task<Result<bool>> UnlistProductAsync(int brandOrganizationId, int brandProductId)
    {
        var getBrandProductSpec =
            new GetBrandProductByIdSpec(brandOrganizationId, brandProductId);

        var brandProduct = await _brandProductsRepository.SingleOrDefaultAsync(getBrandProductSpec);
        var response = new Result<bool>();

        if (brandProduct is null)
        {
            response.Error = ErrorType.ValidationError;
            response.ErrorMessage = ValidationMessages.ProductDoesNotExist;
            return response;
        }

        brandProduct.Unlist();
        await _db.SaveChangesAsync();

        var brandProductUrl = _urlBuilder.BuildProductDetailsUrl(brandProductId);
        await _notificationService.SendProductUnlistedNotificationAsync(brandProductId, brandProductUrl, brandProduct.Name);

        response.Data = true;
        return response;
    }

    public async Task<IEnumerable<LookupItem>> GetBrandProductCountries(int brandOrganizationId,
        CancellationToken cancellationToken = default)
    {
        var getProductCountriesSpec = new GetBrandProductCountriesSpec(brandOrganizationId);
        var countries = await _brandProductsRepository.ListAsync(getProductCountriesSpec, cancellationToken);
        return countries;
    }

    public async Task<Result<UploadSalesDataResponseDto>> UploadSalesData(int brandProductId, string fileUrl)
    {
        var response = new Result<UploadSalesDataResponseDto>();

        var getProductSpec = new GetBrandProductMinimalSpec(_currentBrandMember.BrandOrganizationId, brandProductId);

        var product = await _brandProductsRepository.SingleOrDefaultAsync(getProductSpec);

        if (product is null)
        {
            response.Error = ErrorType.ValidationError;
            response.ErrorMessage = ValidationMessages.ProductDoesNotExist;
            return response;
        }

        if (product.ProductUrlTypeId == SystemProductUrlOption.InCommMall)
        {
            response.Error = ErrorType.ValidationError;
            response.ErrorMessage = "Cannot upload sales data for product listed on Incomm.";
            return response;
        }

        var saleDataFileValidationResult = await _salesDataImportService
            .ValidateSalesDataFileAsync(_storageService.GetSignedUrl(fileUrl));

        if (!saleDataFileValidationResult.IsSuccess)
        {
            response.Error = saleDataFileValidationResult.Error;
            response.ErrorMessage = saleDataFileValidationResult.ErrorMessage;
            return response;
        }

        var salesDataFile = new BrandProductsSalesDataFile()
        {
            FilePath = FileUtils.GetFileAbsolutePath(fileUrl),
            BrandProductId = brandProductId,
            UploadedByMemberId = _currentBrandMember.BrandMemberId,
            ImportStatusId = ImportStatus.Queued
        };

        _db.BrandProductsSalesDataFiles.Add(salesDataFile);

        product.SalesDataLastUploadedAtUtc = DateTime.UtcNow;

        await _db.SaveChangesAsync();

        _backgroundWorker.Enqueue(() =>
            _salesDataImportService.ImportSalesDataAsync(salesDataFile.BrandProductsSaleDataFileId));

        response.Data = new UploadSalesDataResponseDto()
        {
            Data = "Sales upload has been started and will be processed in background.",
            SalesDataLastUploadedAtUtc = product.SalesDataLastUploadedAtUtc.Value
        };

        return response;
    }

    public async Task<BrandProductModel> UpdateBrandProductAsync(UpdateBrandProductDto brandProductDto, int brandOrganizationId, CancellationToken cancellationToken = default)
    {
        var getBrandProductSpec =
            new GetBrandProductByIdSpec(brandOrganizationId, brandProductDto.BrandProductId);

        var brandProduct = await _brandProductsRepository.SingleOrDefaultAsync(getBrandProductSpec, cancellationToken);

        if (brandProduct is null)
        {
            return new BrandProductModel { Error = ErrorType.ValidationError, ErrorMessage = ValidationMessages.ProductDoesNotExist };
        }

        var isApprovalBasedOffer = brandProduct.IsApprovalBasedOffer;
        brandProduct.Name = brandProductDto.Name;
        brandProduct.BannerImageUrl = FileUtils.GetFileAbsolutePath(brandProductDto.BannerImageUrl);
        brandProduct.ShowCaseMediaUrls = brandProductDto.ShowCaseMediaUrls.Select(FileUtils.GetFileAbsolutePath).ToList();

        var mediaKits = new ProductSocialMediaKit()
        {
            InstagramMediaUrl = FileUtils.GetFileAbsolutePath(brandProductDto.SocialMediaKits.InstagramMediaUrl),
            FacebookMediaKitUrl = FileUtils.GetFileAbsolutePath(brandProductDto.SocialMediaKits.FacebookMediaKitUrl),
            TwitterMediaKitUrl = FileUtils.GetFileAbsolutePath(brandProductDto.SocialMediaKits.TwitterMediaKitUrl),
            TikTokMediaKitUrl = FileUtils.GetFileAbsolutePath(brandProductDto.SocialMediaKits.TikTokMediaKitUrl)
        };

        brandProduct.Description = brandProductDto.Description;
        brandProduct.Hashtags = brandProductDto.Hashtags;
        brandProduct.IsApprovalBasedOffer = brandProductDto.IsApprovalBasedOffer;
        brandProduct.SocialMediaKits = mediaKits;

        var getProductCategoriesSpec = new GetCategoriesSpec(brandProductDto.Categories);
        brandProduct.Categories = await _categoryRepository.ListAsync(getProductCategoriesSpec, cancellationToken);

        await _db.SaveChangesAsync(cancellationToken);

        if (brandProduct.ShopifyProductId is not null)
        {
            await _shopifyService.UpdateProductAsync(brandProduct);
        }

        int actByMemberId = _currentBrandMember.BrandMemberId;
        if (isApprovalBasedOffer && !brandProductDto.IsApprovalBasedOffer)
        {
            _backgroundWorker.Enqueue(() => _productPromotionService.ApproveAllPendingRequestsAsync(brandProductDto.BrandProductId, brandProduct.BrandOrganizationId, actByMemberId, CancellationToken.None));
        }

        var updatedProduct = _mapper.Map<BrandProduct, BrandProductModel>(brandProduct);

        updatedProduct.SignTheUrls(_storageService);

        return updatedProduct;
    }

    private static bool IsOnlyOnePlatformProvided(AddBrandProductDto dto)
    {
        string[] all = { dto.ProductUrls.CompanyProductUrl, dto.ProductUrls.EcommercePlatformUrl, dto.ProductIncommDetails?.ToString() };
        return all.Count(s => !string.IsNullOrWhiteSpace(s)) == 1;
    }
}
