﻿using System;
using BeTagged.Common.Utils;
using BeTagged.Core.Configurations;
using BeTagged.Core.Dtos;
using BeTagged.Core.Exceptions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using sib_api_v3_sdk.Api;
using sib_api_v3_sdk.Client;
using sib_api_v3_sdk.Model;
using Threading = System.Threading.Tasks;

namespace BeTagged.Core.Services.Communication;
public class SendinBlueEmailTransportService : IEmailTransportService
{
    private readonly ILogger _logger;

    public SendinBlueEmailTransportService(IOptions<SendinBlueConfiguration> sendInBlueConfiguration,
        ILogger<SendinBlueEmailTransportService> logger)
    {
        _logger = logger;
        Configuration.Default.ApiKey["api-key"] = sendInBlueConfiguration.Value.ApiKey;
    }

    public async Threading.Task SendEmailAsync(SendEmailDto sendEmailConfig)
    {
        var apiInstance = new TransactionalEmailsApi();
        SendSmtpEmailSender emailFrom = new SendSmtpEmailSender(null, EmailConstants.EmailFrom);
        List<SendSmtpEmailTo> to = new();
        foreach (var email in sendEmailConfig.RecipientEmails)
        {
            to.Add(new SendSmtpEmailTo(email));
        }

        try
        {
            var sendSmtpEmail = new SendSmtpEmail(emailFrom, to, null, null, null, null, null, null, null, null, (long)sendEmailConfig.TemplateId,
                sendEmailConfig.DynamicTemplateData, null, null);
            CreateSmtpEmail result = await apiInstance.SendTransacEmailAsync(sendSmtpEmail);
        }
        catch (Exception e)
        {
            _logger.LogError(e, "Error while sending email. {Info}", sendEmailConfig.Serialize());
            throw new EmailTransportException(e.Message, e);
        }
    }
}
