﻿using System.Threading;
using BeTagged.Core.Services.Profile;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Commands.Profile;

public static class DeleteInfluencerBankAccount
{
    public record Command(int Id) : IRequest;

    public class Handler : IRequestHandler<Command>
    {
        private readonly ICurrentInfluencer _currentInfluencer;
        private readonly IInfluencerService _influencerService;

        public Handler(ICurrentInfluencer currentInfluencer, IInfluencerService influencerService)
        {
            _currentInfluencer = currentInfluencer;
            _influencerService = influencerService;
        }

        public async Task<Unit> Handle(Command request, CancellationToken cancellationToken)
        {
            await _influencerService.DeleteInfluencerBankAccountAsync(_currentInfluencer.InfluencerId,
                request.Id);

            return default;
        }
    }
}
