﻿namespace BeTagged.Core.Services.UrlUtils;

public interface IUrlBuilder
{
    string SignupInviteUrl(string email, string invitationKey);

    string BrandInviteUrl(string email, string invitationKey);

    string BuildProductDetailsUrl(int brandProductId);

    string BuildInstagramHandleUrl(string handle);

    string BuildFacebookHandleUrl(string handle);

    string BuildTwitterHandleUrl(string handle);

    string BuildTikTokHandleUrl(string handle);
}
