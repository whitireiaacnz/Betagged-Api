﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Threading;
using BeTagged.Core.Queries.Shared;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Storage;
using BeTagged.Data.Services;
using Newtonsoft.Json;

namespace BeTagged.Core.Queries.BrandProduct;

public static class GetBrandProducts
{
    public class OdataQuery : ODataQueryBase
    {
        // OrderBy -> Price
        private const string OrderByValidationRegex = $"(p|P)rice{OrderByDirectionValidationRegex}";

        [RegularExpression(OrderByValidationRegex), DefaultValue(null)]
        public override string OrderBy { get; set; }
    }

    public class Query : OdataQuery, IRequest<PaginatedList<Response>>
    {
        public IEnumerable<InclusiveIntRange> CommissionPercentage { get; set; }

        public IEnumerable<InclusiveIntRange> Sales { get; set; }

        public IEnumerable<InclusiveIntRange> Influencers { get; set; }

        [DefaultValue(false)]
        public bool OnlyIncludeProductsWithPromotionRequests { get; set; }
    }

    public class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleForEach(x => x.CommissionPercentage)
                .SetValidator(new InclusivePercentageValidator());

            RuleForEach(x => x.Sales).SetValidator(new InclusiveIntRangeValidator());

            RuleForEach(x => x.Influencers).SetValidator(new InclusiveIntRangeValidator());
        }
    }

    public class Handler : IRequestHandler<Query, PaginatedList<Response>>
    {
        private const string SaleCountFilterColumnName =
            "(select count(*) from product_sales ps where ps.brand_product_id = bp.brand_product_id and ps.is_deleted = false)";

        private const string InfluencerCountFilterColumnName =
            "(select count(*) from (select count(*) from product_promotions pp where pp.brand_product_id = bp.brand_product_id and pp.is_deleted = false group by pp.influencer_id) as g)";

        private readonly ICurrentBrandMember _currentBrandMember;
        private readonly IStorageService _storageService;
        private readonly IQueryService _queryService;

        public Handler(ICurrentBrandMember currentBrandMember, IStorageService storageService, IQueryService queryService)
        {
            _currentBrandMember = currentBrandMember;
            _storageService = storageService;
            _queryService = queryService;
        }

        public async Task<PaginatedList<Response>> Handle(Query request, CancellationToken cancellationToken)
        {
            var parameters = new
            {
                BrandOrganizationId = _currentBrandMember.BrandOrganizationId,
                Criteria = request.Criteria,
                Take = request.Take,
                Skip = request.Skip,
                OnlyIncludeProductsWithPromotionRequests = request.OnlyIncludeProductsWithPromotionRequests
            };

            var dynamicFilter = new List<DynamicFilterItem>()
            {
                new("commission_percentage", request.CommissionPercentage),
                new(SaleCountFilterColumnName, request.Sales),
                new(InfluencerCountFilterColumnName, request.Influencers)
            };

            var orderBy = request.OrderBy ?? nameof(Response.BrandProductId) + " desc";

            var products = await _queryService
                .QueryAsync<Response>(BtQueryType.GetBrandProducts, orderBy, parameters, dynamicFilter);

            int totalCount = 0;

            if (products.Count <= 0)
            {
                return new PaginatedList<Response>(totalCount, products, request.Skip, request.Take);
            }

            totalCount = products[0].TotalCount;

            foreach (var product in products)
            {
                product.ShowCaseMediaUrls = product.ShowCaseMediaUrls
                    .Select(x => _storageService.GetSignedUrl(x));
            }

            return new PaginatedList<Response>(totalCount, products, request.Skip, request.Take);
        }
    }

    public class Response : Result
    {
        [JsonIgnore]
        public int TotalCount { get; set; }

        public int BrandProductId { get; set; }

        public string Name { get; set; }

        public string ProductCode { get; set; }

        public SystemProductStatusOption ProductStatus { get; set; }

        public string CurrencyCode { get; set; }

        public string CurrencySymbol { get; set; }

        public decimal Price { get; set; }

        public int InfluencerCount { get; set; }

        public int SalesCount { get; set; }

        public int CommissionPercentage { get; set; }

        public IEnumerable<string> ShowCaseMediaUrls { get; set; }
    }
}
