﻿namespace BeTagged.Data.Enums;

[EnumLookupTable(typeof(SystemOtpEntityType))]
public enum SystemOtpEntityTypeOption : byte
{
    Phone = 1,
    Email = 2
}
