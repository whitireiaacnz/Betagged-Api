﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class IsdCodeCountryCode : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AddColumn<string>(
            name: "isd_code",
            schema: "public",
            table: "system_countries_lut",
            type: "character varying(7)",
            maxLength: 7,
            nullable: true);

        migrationBuilder.AddColumn<string>(
            name: "iso_code",
            schema: "public",
            table: "system_countries_lut",
            type: "character varying(2)",
            maxLength: 2,
            nullable: true);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropColumn(
            name: "isd_code",
            schema: "public",
            table: "system_countries_lut");

        migrationBuilder.DropColumn(
            name: "iso_code",
            schema: "public",
            table: "system_countries_lut");
    }
}
