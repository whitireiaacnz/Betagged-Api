﻿namespace BeTagged.Core.Services.Clevertap;

public static class CdpEvents
{
    public const string SignupCompleted = "Signup Completed";

    public const string OnboardingCompleted = "Onboarding Completed";

    public const string ProductListed = "Product Listed";

    public const string CouponExhausted = "Coupon Exhausted";

    public const string SalesDataUploadReminder = "Sales Data Upload Reminder";

    public const string ProductSold = "Product Sold";

    public const string ProductRequestAccepted = "Product Request Accepted";

    public const string ProductRequestRejected = "Product Request Rejected";

    public const string ProductUnlisted = "Product Unlisted";

    public const string ProductListingReminder = "Product Listing Reminder";

    public const string InfluencersSeekingApproval = "Influencers Seeking Approval";

    public const string ProductPickingReminder = "Product Picking Reminder";

    public const string CompleteSignupReminder = "Complete Signup Reminder";

    public const string CompleteOnboardingReminder = "Complete Onboarding Reminder";
}
