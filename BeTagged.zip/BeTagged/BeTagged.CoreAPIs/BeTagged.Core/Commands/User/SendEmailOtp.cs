﻿using System.Threading;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Otp;
using BeTagged.Core.Services.Security;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Commands.User;

public static class SendEmailOtp
{
    public record Command(int EmailAddressId) : IRequest<Response>;

    public class Validator : AbstractValidator<Command>
    {
        public Validator() => RuleFor(x => x.EmailAddressId).GreaterThan(0);
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IBtDb _db;
        private readonly ICurrentUser _currentUser;
        private readonly IEmailOtpService _emailOtpService;

        public Handler(IBtDb db, ICurrentUser currentUser, IEmailOtpService emailOtpService)
        {
            _db = db;
            _currentUser = currentUser;
            _emailOtpService = emailOtpService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var response = new Response();

            var emailAddress = await _db.EmailAddresses
                .Where(x => x.UserId == null || x.UserId == _currentUser.UserId)
                .Where(x => x.EmailAddressId == request.EmailAddressId)
                .SingleOrDefaultAsync(cancellationToken);

            if (emailAddress is null)
            {
                response.ErrorMessage = ValidationMessages.EmailDoesNotExists;
                response.Error = ErrorType.ValidationError;
                return response;
            }

            await _emailOtpService.GenerateAndSendEmailOtpAsync(emailAddress, SystemOtpUsageTypeOption.Verification);

            return response;
        }
    }

    public class Response : Result
    {
    }
}
