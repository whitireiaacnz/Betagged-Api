﻿using System;

namespace BeTagged.Core.Dtos;

public class InfluencerProfileDto
{
    public string ProfilePicUrl { get; set; }

    public string InfluencerName { get; set; }

    public DateTime InfluencerSinceUtc { get; set; }

    public string CurrencyCode { get; set; }

    public string CurrencySymbol { get; set; }

    public int Sales { get; set; }

    public decimal Commission { get; set; }

    public InfluencerMediaAccountsModel SocialMedia { get; set; }

    public IEnumerable<UserEmailAddressDto> EmailAddresses { get; set; }

    public IEnumerable<UserPhoneDto> Phones { get; set; }
}
