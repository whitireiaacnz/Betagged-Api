﻿using System;
using System.Linq.Expressions;

namespace BeTagged.Core.Services.BackgroundWork;

public interface IBackgroundWorker
{
    string Enqueue(Expression<Action> methodCall);

    string Enqueue(Expression<Func<Task>> methodCall);

    string Enqueue<T>(Expression<Action<T>> methodCall);

    string Enqueue<T>(Expression<Func<T, Task>> methodCall);

    string Schedule(Expression<Action> methodCall, TimeSpan delay);

    string Schedule(Expression<Func<Task>> methodCall, TimeSpan delay);

    string Schedule<T>(Expression<Action<T>> methodCall, TimeSpan delay);

    string Schedule<T>(Expression<Func<T, Task>> methodCall, TimeSpan delay);

    string Schedule(Expression<Func<Task>> methodCall, DateTime dateTime);

    string Schedule<T>(Expression<Func<T, Task>> methodCall, DateTime dateTime);
}
