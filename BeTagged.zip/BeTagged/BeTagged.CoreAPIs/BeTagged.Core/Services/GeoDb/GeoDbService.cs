﻿using BeTagged.Common.Extensions;
using BeTagged.Common.Utils;

namespace BeTagged.Core.Services.GeoDb;

using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using BeTagged.Core.Models;

public class GeoDbService : IGeoDbService
{
    private readonly IHttpClientFactory _httpClientFactory;

    public GeoDbService(IHttpClientFactory httpClientFactory) =>
        _httpClientFactory = httpClientFactory;

    public async Task<PaginatedList<CityLookupItem>> GetCitiesAsync(int skip, int take, string search,
        string countryIso2Code = null)
    {
        HttpResponseMessage httpResponseMessage;
        using (var httpClient = _httpClientFactory.CreateClient(HttpClients.GeoDbCitiesApi))
        {
            var requestUri = $"{httpClient.BaseAddress}v1/geo/cities?limit={take}&namePrefix={search}&offset={skip}&countryIds={countryIso2Code}".ToUri();

            var request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = requestUri,
            };

            httpResponseMessage = await httpClient.SendAsync(request);
        }

        httpResponseMessage.EnsureSuccessStatusCode();

        var cities = await httpResponseMessage.Content.ReadAsStringAsync();

        int totalCount = 0;

        var geodbServiceResponse = cities.Deserialize<GeoDbServiceApiResponse>();

        if (geodbServiceResponse.Metadata.TotalCount > 0)
        {
            totalCount = geodbServiceResponse.Metadata.TotalCount;
        }

        var cityLookupData = geodbServiceResponse.Data.Select(x => new CityLookupItem()
        {
            City = x.City,
            Country = x.Country,
            Region = x.Region,
            Longitude = x.Longitude,
            Latitude = x.Latitude
        });

        var result = new PaginatedList<CityLookupItem>(totalCount, cityLookupData, skip, take);

        return result;
    }

    private sealed class GeoDbServiceApiResponse
    {
        public List<Data> Data { get; set; }

        public Metadata Metadata { get; set; }
    }

    private sealed class Data
    {
        public string City { get; set; }

        public string Region { get; set; }

        public string Country { get; set; }

        public double Latitude { get; set; }

        public double Longitude { get; set; }
    }

    private sealed class Metadata
    {
        public int TotalCount { get; set; }
    }
}
