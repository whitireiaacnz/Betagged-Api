﻿using BeTagged.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(BrandProductDiscountCodeEntityConfiguration))]
public class BrandProductDiscountCode : BaseEntity
{
    public int BrandProductDiscountCodeId { get; set; }

    public string DiscountCode { get; set; }

    public int BrandProductId { get; set; }

    public int DiscountCodesFileId { get; set; }

    // Foreign Keys
    public BrandProduct BrandProduct { get; set; }

    public BrandProductDiscountCodesFile DiscountCodesFile { get; set; }

    // Reverse navigation
    public ProductPromotion ProductPromotion { get; set; }
}
