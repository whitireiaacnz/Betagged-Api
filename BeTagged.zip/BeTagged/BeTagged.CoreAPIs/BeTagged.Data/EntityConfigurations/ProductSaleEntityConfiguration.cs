﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

public class ProductSaleEntityConfiguration : IEntityTypeConfiguration<ProductSale>
{
    public void Configure(EntityTypeBuilder<ProductSale> builder)
    {
        builder.HasKey(x => x.ProductSaleId);

        builder.Property(x => x.ProductSaleId)
            .UseIdentityAlwaysColumn();

        builder.Property(x => x.Quantity).HasDefaultValue(1);

        builder.HasOne(x => x.ProductPromotion)
            .WithMany(x => x.ProductSales)
            .HasForeignKey(x => x.ProductPromotionId);

        builder.HasOne(x => x.Influencer)
           .WithMany(x => x.ProductSales)
           .HasForeignKey(x => x.InfluencerId);

        builder.HasOne(x => x.SalesChannel)
           .WithMany(x => x.ProductSales)
           .HasForeignKey(x => x.SalesChannelId);

        builder.HasOne(x => x.BrandProduct)
           .WithMany(x => x.ProductSales)
           .HasForeignKey(x => x.BrandProductId);

        builder.HasOne(x => x.ImportedThroughSaleDataFile)
            .WithMany(x => x.ProductSales)
            .HasForeignKey(x => x.ImportedThroughSaleDataFileId);

        builder.HasOne(x => x.SystemSalesSource)
            .WithMany(x => x.ProductSales)
            .HasForeignKey(x => x.SystemSalesSourceId);
    }
}
