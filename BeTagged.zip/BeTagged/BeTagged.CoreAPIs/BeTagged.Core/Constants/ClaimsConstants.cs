﻿using System.Security.Claims;

namespace BeTagged.Core.Constants;

public static class ClaimsConstants
{
    public const string UserId = ClaimTypes.NameIdentifier;
    public const string UserType = "UserType";
    public const string InfluencerId = "InfluencerId";
    public const string BrandMemberId = "BrandMemberId";
    public const string BrandMembershipId = "BrandMembershipId";
    public const string Role = ClaimTypes.Role;
    public const string BrandOrganizationId = "BrandOrganizationId";
    public const string UserKey = "UserKey";
}
