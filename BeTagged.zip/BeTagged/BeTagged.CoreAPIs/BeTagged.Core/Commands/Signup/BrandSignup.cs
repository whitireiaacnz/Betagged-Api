﻿using System.Threading;
using BeTagged.Core.CQRS;
using BeTagged.Core.Services.Signup;
using BeTagged.Core.Utils;

namespace BeTagged.Core.Commands.Signup;

public static class BrandSignup
{
    public record Command : ITransactionalRequest<Response>
    {
        public string Email { get; set; }

        public string CountryCode { get; set; }

        public string Phone { get; set; }

        public string Password { get; set; }

        public string InvitationKey { get; set; }
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.Email).NotEmpty().EmailAddress();
            RuleFor(x => x.CountryCode).NotEmpty();
            RuleFor(x => x.Phone).NotEmpty();
            RuleFor(x => x.Password).NotEmpty().Matches(PropertyValidationUtil.PasswordRegex)
                .WithMessage(ValidationMessages.PasswordMustBeValid);
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IBrandSignupService _brandSignupService;

        public Handler(IBrandSignupService brandSignupService)
        {
            _brandSignupService = brandSignupService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken) =>
            await _brandSignupService.SignupBrandAsync(request);
    }

    public class Response : BrandMemberAuthenticationResponse
    {
    }
}
