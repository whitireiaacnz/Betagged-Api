﻿using System.Threading;
using BeTagged.Common.Extensions;
using BeTagged.Core.CQRS;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.BackgroundWork;
using BeTagged.Core.Services.Brand;
using BeTagged.Core.Services.BrandProducts;
using BeTagged.Core.Services.CDP;
using BeTagged.Core.Services.Communication;
using BeTagged.Core.Services.Notification;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Utils;
using BeTagged.Data.Queries;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Commands.OnBoarding;

public static class CompleteBrandOnBoarding
{
    public class Command : ITransactionalRequest<Response>
    {
        public Command() => Categories = Enumerable.Empty<int>();

        public string FullName { get; set; }

        public string BrandLegalName { get; set; }

        public IEnumerable<int> Categories { get; set; }

        public bool HasAcceptedTermsAndCondition { get; set; }
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.FullName)
            .NotEmpty()
            .MinimumLength(2)
            .MaximumLength(64)
            .Matches(PropertyValidationUtil.OnlyAlphabetRegex)
            .WithMessage("Name must only contain alphabets.");
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly ICurrentBrandMember _currentBrandMember;
        private readonly IBtDb _db;
        private readonly IEmailService _emailService;
        private readonly IAuthenticationService _authenticationService;
        private readonly IBrandMembershipService _brandMembershipService;
        private readonly IBackgroundWorker _backgroundWorker;
        private readonly INotificationService _notificationService;
        private readonly IProductListingReminderService _productListingReminderService;

        public Handler(ICurrentBrandMember currentBrandMember, IBtDb db, IEmailService emailService,
            IAuthenticationService authenticationService, IBrandMembershipService brandMembershipService,
            IBackgroundWorker backgroundWorker, INotificationService notificationService, IProductListingReminderService productListingReminderService)
        {
            _currentBrandMember = currentBrandMember;
            _db = db;
            _emailService = emailService;
            _authenticationService = authenticationService;
            _brandMembershipService = brandMembershipService;
            _backgroundWorker = backgroundWorker;
            _notificationService = notificationService;
            _productListingReminderService = productListingReminderService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var response = new Response();

            var brandMember = await _db.BrandMembers
                .Include(x => x.User)
                .ThenInclude(x => x.EmailAddresses.Where(y => y.IsPrimary))
                .Include(x => x.PrimaryBrandOrganization)
                .ThenInclude(x => x.BrandMemberships.Where(y => y.BrandMemberId == _currentBrandMember.BrandMemberId
                             && !y.IsDisabled))
                .Where(x => x.BrandMemberId == _currentBrandMember.BrandMemberId)
                .SingleAsync(cancellationToken);

            var user = brandMember.User;

            user.Name = request.FullName;

            await _db.SaveChangesAsync(cancellationToken);

            _notificationService.SendOnBoardingCompletedNotification(brandMember.User.UserKey);
            _productListingReminderService.ScheduleProductListingReminderJob(brandMember.UserId);

            // If the user is not Admin. We don't need to continue as he's not authorize to perform actions on Brand.
            if (_currentBrandMember.Role != SystemRoleOption.Administrator)
            {
                return response;
            }

            BrandOrganization brandOrganization;

            // Member doesn't have any organization create one on demand.
            if (_currentBrandMember.BrandOrganizationId == 0)
            {
                brandOrganization = brandMember.BrandMemberships.FirstOrDefault()?.BrandOrganization ??
                                    await CreateANewBrandOrganizationAsync(brandMember, cancellationToken);
            }
            else
            {
                brandOrganization = await _db.BrandOrganizations
                    .Where(x => x.BrandOrganizationId == _currentBrandMember.BrandOrganizationId)
                    .SingleAsync(cancellationToken);
            }

            // If we have already completed the on-boarding. Then, we don't need to continue.
            if (brandOrganization.LegalName.IsNotNullOrEmpty())
            {
                return response;
            }

            if (request.BrandLegalName.IsNullOrEmpty())
            {
                const string fieldName = nameof(Command.BrandLegalName);
                response.Errors.Add(new($"'{fieldName}' must not be empty.", fieldName));
                response.Error = ErrorType.ValidationError;
            }

            if (!request.Categories.Any())
            {
                const string fieldName = nameof(Command.Categories);
                response.Errors.Add(new($"'{fieldName}' must not be empty.", fieldName));
                response.Error = ErrorType.ValidationError;
            }

            if (!request.HasAcceptedTermsAndCondition)
            {
                response.Error = ErrorType.ValidationError;
                response.ErrorMessage = ValidationMessages.TermsAndConditionNotAccepted;
                return response;
            }

            if (response.Error.HasValue)
            {
                response.ErrorMessage = "Invalid request.";
                return response;
            }

            brandOrganization.HasAcceptedTermsAndCondition = request.HasAcceptedTermsAndCondition;

            var categories = await _db.SystemCategories.GetCategoriesAsync(request.Categories, cancellationToken);

            brandOrganization.Categories = categories.ToList();
            brandOrganization.LegalName = request.BrandLegalName;

            await _db.SaveChangesAsync(cancellationToken);

            var userEmailAddress = await _db.EmailAddresses
            .Where(x => x.UserId == user.UserId && x.IsPrimary)
            .SingleAsync(cancellationToken);

            await _emailService.SendWelcomeEmailAsync(userEmailAddress.EmailAddress_);

            _backgroundWorker.Enqueue<ICdpService>(x =>
                x.UpdateUserNameAsync(brandMember.User.UserKey, request.FullName));

            var authenticationResponse = await _authenticationService
                .GetBrandMemberAuthenticationResponse(user.UserId, null, cancellationToken);

            response.AccessToken = authenticationResponse.AccessToken;

            return response;
        }

        private async Task<BrandOrganization> CreateANewBrandOrganizationAsync(BrandMember brandMember,
            CancellationToken cancellationToken)
        {
            var user = brandMember.User;

            var brandOrganization = new BrandOrganization()
            {
                EmailDomain = EmailUtil.GetDomain(user.EmailAddresses.First().EmailAddress_),
                OnBoardedByMember = brandMember
            };

            brandMember.PrimaryBrandOrganization = brandOrganization;

            _db.BrandOrganizations.Add(brandOrganization);

            await _db.SaveChangesAsync(cancellationToken);

            await _brandMembershipService.AddBrandMembershipAsync(
                brandMember.BrandMemberId, brandOrganization.BrandOrganizationId, brandMember.BrandMemberId,
                SystemRoleOption.Administrator);

            return brandOrganization;
        }
    }

    public class Response : Result
    {
        public string AccessToken { get; set; }
    }
}
