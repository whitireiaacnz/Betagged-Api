﻿using System;
using System.Threading;
using BeTagged.Core.Dtos;
using BeTagged.Core.Extensions;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetBrandProductsSoldSpec : IListResultQuerySpecification<BrandProduct, BrandProductSalesInfoDto>
{
    public GetBrandProductsSoldSpec(int countryId, int brandOrganizationId, DateTime? from, DateTime? to,
        string criteria, int skip, int take, string orderBy)
    {
        Query = async (queryable, ctx) => await queryable
            .Include(c => c.Country)
            .Where(x => x.CountryId == countryId && x.BrandOrganizationId == brandOrganizationId)
            .Where(x => criteria == null || EF.Functions.ILike(x.Name, $"%{criteria}%"))
            .Select(x => new BrandProductSalesInfoDto()
            {
                BrandProductId = x.BrandProductId,
                ShowCaseMediaUrls = x.ShowCaseMediaUrls,
                ProductName = x.Name,
                Price = x.Price,
                Sales = x.ProductSales.Where(y => from == null || (y.SoldAtUtc >= from && y.SoldAtUtc <= to))
                    .Sum(y => y.Quantity),
                SalesValue =
                    x.ProductSales.Where(y => from == null || (y.SoldAtUtc >= from && y.SoldAtUtc <= to))
                        .Sum(y => y.TotalAmount),
                Commission =
                    x.ProductSales.Where(y => from == null || (y.SoldAtUtc >= from && y.SoldAtUtc <= to))
                        .Sum(y => y.PayableCommission),
                CurrencyCode = x.Country.CurrencyCode,
                CurrencySymbol = x.Country.CurrencySymbol,
                SalesDataLastUploadedAtUtc = x.SalesDataLastUploadedAtUtc,
                ProductListedOn = x.ProductUrlTypeId
            })
            .OrderByDynamic(orderBy, null)
            .Skip(skip)
            .Take(take + 1)
            .ToListAsync(ctx);
    }

    public Func<IQueryable<BrandProduct>, CancellationToken, Task<IList<BrandProductSalesInfoDto>>> Query { get; }
}
