﻿using System;
using BeTagged.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(ProductPromotionRequestEntityConfiguration))]
public class ProductPromotionRequest : BaseEntity, IBrandEntity
{
    public int ProductPromotionRequestId { get; set; }

    public int BrandProductId { get; set; }

    public int InfluencerId { get; set; }

    public int BrandOrganizationId { get; set; }

    public SystemSalesChannelOption SalesChannelId { get; set; }

    public SystemApprovalStatusOption ApprovalStatusId { get; set; }

    public bool? IsRejectedDueToPeriodExpiration { get; set; }

    public int CommissionPercentage { get; set; }

    [PercentageColumn]
    public decimal PlatformCommissionPercentage { get; set; }

    [PercentageColumn]
    public decimal InfluencerCommissionPercentage { get; set; }

    public DateTime RequestedOnUtc { get; set; }

    public DateTime? ActedAtUtc { get; set; }

    public int? ActedByBrandMemberId { get; set; }

    // Foreign Keys
    public BrandProduct BrandProduct { get; set; }

    public Influencer Influencer { get; set; }

    public SystemSalesChannel SalesChannel { get; set; }

    public SystemApprovalStatus ApprovalStatus { get; set; }

    public BrandOrganization BrandOrganization { get; set; }

    public BrandMember ActedByBrandMember { get; set; }
}
