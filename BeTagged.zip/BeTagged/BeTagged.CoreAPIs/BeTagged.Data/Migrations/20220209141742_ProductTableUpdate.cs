﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class ProductTableUpdate : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropForeignKey(
            name: "fk_brand_product_countries_brand_products_brand_product_id",
            schema: "public",
            table: "brand_product_countries");

        migrationBuilder.DropForeignKey(
            name: "fk_brand_product_countries_system_countries_lut_system_country",
            schema: "public",
            table: "brand_product_countries");

        migrationBuilder.DropIndex(
            name: "ix_brand_products_brand_organization_id",
            schema: "public",
            table: "brand_products");

        migrationBuilder.DropColumn(
            name: "be_tagged_mall_url",
            schema: "public",
            table: "brand_products");

        migrationBuilder.DropColumn(
            name: "company_product_url",
            schema: "public",
            table: "brand_products");

        migrationBuilder.DropColumn(
            name: "other_commerce_url",
            schema: "public",
            table: "brand_products");

        migrationBuilder.DropColumn(
            name: "show_case_media_urls",
            schema: "public",
            table: "brand_products");

        migrationBuilder.DropColumn(
            name: "tiktok_commerce_url",
            schema: "public",
            table: "brand_products");

        migrationBuilder.RenameColumn(
            name: "social_media_kit",
            schema: "public",
            table: "brand_products",
            newName: "social_media_kits_social_media_kit");

        migrationBuilder.AlterColumn<decimal>(
            name: "price",
            schema: "public",
            table: "brand_products",
            type: "numeric(7,2)",
            nullable: false,
            oldClrType: typeof(decimal),
            oldType: "numeric");

        migrationBuilder.AddColumn<BrandProductUrl>(
            name: "product_urls",
            schema: "public",
            table: "brand_products",
            type: "jsonb",
            nullable: true);

        migrationBuilder.CreateIndex(
            name: "ix_brand_products_brand_organization_id",
            schema: "public",
            table: "brand_products",
            column: "brand_organization_id");

        migrationBuilder.AddForeignKey(
            name: "fk_brand_product_countries_brand_products_brand_product_id",
            schema: "public",
            table: "brand_product_countries",
            column: "brand_product_id",
            principalSchema: "public",
            principalTable: "brand_products",
            principalColumn: "brand_product_id",
            onDelete: ReferentialAction.Restrict);

        migrationBuilder.AddForeignKey(
            name: "fk_brand_product_countries_system_countries_lut_system_country",
            schema: "public",
            table: "brand_product_countries",
            column: "system_country_id",
            principalSchema: "public",
            principalTable: "system_countries_lut",
            principalColumn: "system_country_id",
            onDelete: ReferentialAction.Restrict);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropForeignKey(
            name: "fk_brand_product_countries_brand_products_brand_product_id",
            schema: "public",
            table: "brand_product_countries");

        migrationBuilder.DropForeignKey(
            name: "fk_brand_product_countries_system_countries_lut_system_country",
            schema: "public",
            table: "brand_product_countries");

        migrationBuilder.DropIndex(
            name: "ix_brand_products_brand_organization_id",
            schema: "public",
            table: "brand_products");

        migrationBuilder.DropColumn(
            name: "product_urls",
            schema: "public",
            table: "brand_products");

        migrationBuilder.RenameColumn(
            name: "social_media_kits_social_media_kit",
            schema: "public",
            table: "brand_products",
            newName: "social_media_kit");

        migrationBuilder.AlterColumn<decimal>(
            name: "price",
            schema: "public",
            table: "brand_products",
            type: "numeric",
            nullable: false,
            oldClrType: typeof(decimal),
            oldType: "numeric(7,2)");

        migrationBuilder.AddColumn<string>(
            name: "be_tagged_mall_url",
            schema: "public",
            table: "brand_products",
            type: "character varying(512)",
            maxLength: 512,
            nullable: true);

        migrationBuilder.AddColumn<string>(
            name: "company_product_url",
            schema: "public",
            table: "brand_products",
            type: "character varying(512)",
            maxLength: 512,
            nullable: true);

        migrationBuilder.AddColumn<string>(
            name: "other_commerce_url",
            schema: "public",
            table: "brand_products",
            type: "character varying(512)",
            maxLength: 512,
            nullable: true);

        migrationBuilder.AddColumn<string>(
            name: "show_case_media_urls",
            schema: "public",
            table: "brand_products",
            type: "character varying(512)",
            maxLength: 512,
            nullable: true);

        migrationBuilder.AddColumn<string>(
            name: "tiktok_commerce_url",
            schema: "public",
            table: "brand_products",
            type: "character varying(512)",
            maxLength: 512,
            nullable: true);

        migrationBuilder.CreateIndex(
            name: "ix_brand_products_brand_organization_id",
            schema: "public",
            table: "brand_products",
            column: "brand_organization_id",
            unique: true);

        migrationBuilder.AddForeignKey(
            name: "fk_brand_product_countries_brand_products_brand_product_id",
            schema: "public",
            table: "brand_product_countries",
            column: "brand_product_id",
            principalSchema: "public",
            principalTable: "brand_products",
            principalColumn: "brand_product_id",
            onDelete: ReferentialAction.Cascade);

        migrationBuilder.AddForeignKey(
            name: "fk_brand_product_countries_system_countries_lut_system_country",
            schema: "public",
            table: "brand_product_countries",
            column: "system_country_id",
            principalSchema: "public",
            principalTable: "system_countries_lut",
            principalColumn: "system_country_id",
            onDelete: ReferentialAction.Cascade);
    }
}
