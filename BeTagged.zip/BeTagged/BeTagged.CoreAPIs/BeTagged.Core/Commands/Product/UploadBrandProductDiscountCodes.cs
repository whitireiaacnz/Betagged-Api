﻿using System.Threading;
using BeTagged.Common.Extensions;
using BeTagged.Core.Services.BrandProducts;
using BeTagged.Core.Utils;

namespace BeTagged.Core.Commands.Product;

public static class UploadBrandProductDiscountCodes
{
    public class Command : IRequest<Response>
    {
        public int BrandProductId { get; set; }

        public string DiscountCodesFileUrl { get; set; }
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.DiscountCodesFileUrl)
                .NotEmpty()
                .Must(x => x.IsUri())
                .WithMessage(ValidationMessages.LinkMustBeValidUri)
                .Must(PropertyValidationUtil.IsExcelFile)
                .WithMessage(ValidationMessages.DiscountCodesFileMustBeExcelFile);
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IBrandProductService _brandProductService;

        public Handler(IBrandProductService brandProductService)
        {
            _brandProductService = brandProductService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var uploadResult =
                await _brandProductService.UploadDiscountCodes(request.BrandProductId, request.DiscountCodesFileUrl);

            return uploadResult.Map<Response>();
        }
    }

    public class Response : Result<string>
    {
    }
}
