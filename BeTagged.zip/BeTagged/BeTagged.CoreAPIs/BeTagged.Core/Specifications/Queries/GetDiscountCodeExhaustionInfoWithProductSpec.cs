﻿using System;
using BeTagged.Core.Dtos;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetDiscountCodeExhaustionInfoWithProductSpec : ISingleResultQuerySpecification<BrandProduct, DiscountCodeExhaustionInfoDto>
{
    public GetDiscountCodeExhaustionInfoWithProductSpec(int brandProductId)
    {
        Query = q => q
            .Include(x => x.ProductPromotions)
            .Include(x => x.DiscountCodes)
            .Where(x => x.BrandProductId == brandProductId)
            .Select(x => new DiscountCodeExhaustionInfoDto()
            {
                BrandProduct = x,
                TotalDiscountCodeCount = x.DiscountCodes.Count,
                ExhaustedDiscountCodeCount = x.DiscountCodes.Count(y => y.ProductPromotion != null)
            });
    }

    public Func<IQueryable<BrandProduct>, IQueryable<DiscountCodeExhaustionInfoDto>> Query { get; }
}
