﻿namespace BeTagged.Core.CQRS;

internal interface ITransactionalRequest<out TResponse> : IRequest<TResponse> where TResponse : Result
{
}
