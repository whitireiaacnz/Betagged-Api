﻿using System;
using System.Threading;
using BeTagged.Core.Dtos;
using BeTagged.Core.Queries.Shared;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Storage;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Queries.BrandBusinessInsight;

public static class GetBrandInsightsInfluencersInfo
{
    public class Query : ODataQueryBase, IRequest<PaginatedList<BrandInsightsInfluencerInfoDto>>
    {
        public int CountryId { get; set; }

        public DateTime? From { get; set; }

        public DateTime? To { get; set; }
    }

    public class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.From).LessThan(x => x.To).When(x => x.From is not null);
            RuleFor(x => x.CountryId).GreaterThan(0);
        }
    }

    public class Handler : IRequestHandler<Query, PaginatedList<BrandInsightsInfluencerInfoDto>>
    {
        private readonly ICurrentBrandMember _currentBrandMember;
        private readonly IReadOnlyRepository<Data.Entities.ProductSale> _productSaleRepo;
        private readonly IStorageService _storageService;

        public Handler(ICurrentBrandMember currentBrandMember, IReadOnlyRepository<ProductSale> productSaleRepo, IStorageService storageService)
        {
            _currentBrandMember = currentBrandMember;
            _productSaleRepo = productSaleRepo;
            _storageService = storageService;
        }

        public async Task<PaginatedList<BrandInsightsInfluencerInfoDto>> Handle(Query request, CancellationToken cancellationToken)
        {
            var influencersByCountrySpec = new GetBrandInsightsInfluencersInfoSpec(request.CountryId, _currentBrandMember.BrandOrganizationId,
                request.From, request.To, request.Skip, request.Take, request.OrderBy);

            var influencers = await _productSaleRepo.ListAsync(influencersByCountrySpec, cancellationToken);

            foreach (var influencer in influencers)
            {
                influencer.InfluencerProfilePicUrl = _storageService.GetSignedUrl(influencer.InfluencerProfilePicUrl);
            }

            return new PaginatedList<BrandInsightsInfluencerInfoDto>(influencers, request.Skip, request.Take);
        }
    }
}
