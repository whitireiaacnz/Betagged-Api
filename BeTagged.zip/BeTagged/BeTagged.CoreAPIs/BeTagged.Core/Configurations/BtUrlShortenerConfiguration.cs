﻿using System;

namespace BeTagged.Core.Configurations;

public class BtUrlShortenerConfiguration
{
    public const string Section = "BtUrlShortenerConfig";

    public Uri BaseUrl { get; set; }

    public string ClientId { get; set; }

    public string ClientSecret { get; set; }
}
