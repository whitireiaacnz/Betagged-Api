﻿using System;
using BeTagged.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(ProductSaleEntityConfiguration))]
public class ProductSale : BaseEntity
{
    public int ProductSaleId { get; set; }

    public int ProductPromotionId { get; set; }

    public int BrandProductId { get; set; }

    public int InfluencerId { get; set; }

    public int BrandOrganizationId { get; set; }

    public SystemSalesChannelOption SalesChannelId { get; set; }

    [CurrencyColumn]
    public decimal TotalAmount { get; set; }

    [CurrencyColumn]
    public decimal PayableCommission { get; set; }

    [CurrencyColumn]
    public decimal InfluencerPayableCommission { get; set; }

    public bool IsCommissionPaidOff { get; set; }

    public DateTime SoldAtUtc { get; set; }

    public int? ImportedThroughSaleDataFileId { get; set; }

    public int Quantity { get; set; }

    public SystemSalesSourceOption SystemSalesSourceId { get; set; }

    // Foreign Keys
    public SystemSalesSource SystemSalesSource { get; set; }

    public ProductPromotion ProductPromotion { get; set; }

    public BrandProduct BrandProduct { get; set; }

    public Influencer Influencer { get; set; }

    public BrandOrganization BrandOrganization { get; set; }

    public SystemSalesChannel SalesChannel { get; set; }

    public BrandProductsSalesDataFile ImportedThroughSaleDataFile { get; set; }

    public void SetSalesInfo(decimal price, int quantity, int commissionPercentage, decimal influencerCommissionPercentage, SystemSalesSourceOption salesSource)
    {
        TotalAmount = price * quantity;
        Quantity = quantity;
        PayableCommission = (price * quantity * commissionPercentage) / 100;
        InfluencerPayableCommission = (price * quantity * influencerCommissionPercentage) / 100;
        SystemSalesSourceId = salesSource;
    }
}
