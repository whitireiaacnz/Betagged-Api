﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

internal class BrandMembershipEntityConfiguration : IEntityTypeConfiguration<BrandMembership>
{
    public void Configure(EntityTypeBuilder<BrandMembership> builder)
    {
        builder.Property(x => x.BrandMembershipId).UseIdentityAlwaysColumn();

        builder.HasOne(x => x.BrandMember)
            .WithMany(x => x.BrandMemberships)
            .HasForeignKey(x => x.BrandMemberId);

        builder.HasOne(x => x.BrandOrganization)
            .WithMany(x => x.BrandMemberships)
            .HasForeignKey(x => x.BrandOrganizationId);

        builder.HasOne(x => x.Role)
            .WithMany(x => x.BrandMemberships)
            .HasForeignKey(x => x.RoleId);

        builder.HasOne(x => x.InvitedByMember)
            .WithMany()
            .HasForeignKey(x => x.InvitedByMemberId);

        builder.HasOne(x => x.Invitation)
            .WithOne(x => x.BrandMembership)
            .HasForeignKey<BrandMembership>(x => x.InvitationId);
    }
}
