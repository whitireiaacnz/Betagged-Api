﻿using System.ComponentModel.DataAnnotations;
using BeTagged.Data.Constants;
using BeTagged.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(EmailAddressEntityConfiguration))]
public class EmailAddress : BaseEntity
{
    public int EmailAddressId { get; set; }

    [MaxLength(DbConstants.EmailAddressFieldLength)]
    public string EmailAddress_ { get; set; }

    [MaxLength(DbConstants.EmailAddressFieldLength)]
    public string NormalizedEmailAddress { get; private set; }

    public bool IsVerified { get; set; }

    public bool IsPrimary { get; set; }

    public int? UserId { get; set; }

    // Foreign keys
    public User User { get; set; }
}
