﻿using System;
using System.Threading;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries.Lookups;

public class GetBrandOrganizationsLookupSpec : IListResultQuerySpecification<BrandOrganization, LookupItem>
{
    public GetBrandOrganizationsLookupSpec(string searchCriteria, int skip, int take)
    {
        Query = async (queryable, ct) => await queryable
            .Where(x => EF.Functions.ILike(x.LegalName, $"%{searchCriteria}%"))
            .OrderBy(x => x.BrandOrganizationId)
            .Skip(skip)
            .Take(take + 1)
            .Select(x => new LookupItem(x.BrandOrganizationId, x.LegalName))
            .ToListAsync(ct);
    }

    public Func<IQueryable<BrandOrganization>, CancellationToken, Task<IList<LookupItem>>> Query { get; }
}
