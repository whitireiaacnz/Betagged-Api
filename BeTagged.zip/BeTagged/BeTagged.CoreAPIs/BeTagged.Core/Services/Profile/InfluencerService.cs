﻿using System.Threading;
using BeTagged.Core.Dtos;
using BeTagged.Core.Enums;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;
using Z.EntityFramework.Plus;

namespace BeTagged.Core.Services.Profile;

public class InfluencerService : IInfluencerService
{
    private readonly IRepository<Influencer> _influencerRepository;
    private readonly IBtDb _db;
    private readonly IRepository<InfluencerBankAccount> _influencerBankAccountRepository;

    public InfluencerService(IRepository<Influencer> influencerRepository, IBtDb db,
        IRepository<InfluencerBankAccount> influencerBankAccountRepository)
    {
        _influencerRepository = influencerRepository;
        _db = db;
        _influencerBankAccountRepository = influencerBankAccountRepository;
    }

    public async Task DeleteInfluencerBankAccountAsync(int influencerId, int id)
    {
        var influencerBankaccountSpec = new GetInfluencerBankAccountSpec(influencerId, id);
        var bankAccount = await _influencerBankAccountRepository.SingleOrDefaultAsync(influencerBankaccountSpec);

        if (bankAccount is null)
        {
            return;
        }

        bankAccount.IsDeleted = true;

        await _db.SaveChangesAsync();
    }

    public async Task<InfluencerBankAccountDto> AddBankAccountAsync(int influencerId, InfluencerBankAccountDto bankAccountInfo)
    {
        var influencerExistingBankAccpunts = await GetInfluencerBankAccountsAsync(influencerId);

        var bankAccount = new InfluencerBankAccount()
        {
            BankName = bankAccountInfo.BankName,
            SwiftCode = bankAccountInfo.SwiftCode,
            AccountNumber = bankAccountInfo.AccountNumber,
            AccountName = bankAccountInfo.AccountName,
            Address = bankAccountInfo?.Address,
            CountryId = bankAccountInfo.CountryId,
            Branch = bankAccountInfo?.Branch,
            InfluencerId = influencerId
        };

        if (!influencerExistingBankAccpunts.Any())
        {
            bankAccount.IsPrimary = true;
        }

        await _influencerBankAccountRepository.AddAsync(bankAccount);
        await _db.SaveChangesAsync();

        var bankAcountResponse = new InfluencerBankAccountDto()
        {
            Id = bankAccount.InfluencerBankAccountId,
            AccountName = bankAccount.AccountName,
            AccountNumber = bankAccount.AccountNumber,
            Address = bankAccount.Address,
            CountryId = bankAccount.CountryId,
            BankName = bankAccount.BankName,
            Branch = bankAccount.Branch,
            SwiftCode = bankAccount.SwiftCode,
            IsPrimary = bankAccount.IsPrimary,
        };

        return bankAcountResponse;
    }

    public async Task<Result<bool>> UpdateSocialMediaHandle(int influencerId, InfluencerMediaAccountsModel socialMediaAccounts)
    {
        var result = new Result<bool>();

        var influencerSpec = new GetInfluencerSpec(influencerId);
        var influencer = await _influencerRepository.SingleAsync(influencerSpec);

        var inflluencerMediaInfo = influencer.SocialMediaAccounts;

        influencer.SocialMediaAccounts = new()
        {
            Facebook = new()
            {
                MetaData = inflluencerMediaInfo.Facebook.MetaData,
                Username = socialMediaAccounts.Facebook,
            },
            Instagram = new()
            {
                MetaData = inflluencerMediaInfo.Instagram.MetaData,
                Username = socialMediaAccounts.Instagram,
            },
            TikTok = new()
            {
                MetaData = inflluencerMediaInfo.TikTok.MetaData,
                Username = socialMediaAccounts.TikTok,
            },
            Twitter = new()
            {
                MetaData = inflluencerMediaInfo.Twitter.MetaData,
                Username = socialMediaAccounts.Twitter,
            }
        };

        await _db.SaveChangesAsync();

        result.Data = true;
        return result;
    }

    public async Task<IEnumerable<InfluencerBankAccountDto>> GetInfluencerBankAccountsAsync(int influencerId, CancellationToken cancellationToken = default)
    {
        var result = new List<InfluencerBankAccountDto>();
        var influencerBankAccountsSpec = new GetInfluencerBankAccountListSpec(influencerId);
        var bankAccounts = await _influencerBankAccountRepository.ListAsync(influencerBankAccountsSpec, cancellationToken);

        if (bankAccounts.Any())
        {
            result = bankAccounts.Select(x => new InfluencerBankAccountDto()
            {
                Id = x.InfluencerBankAccountId,
                AccountName = x.AccountName,
                BankName = x.BankName,
                AccountNumber = x.AccountNumber,
                Address = x.Address,
                Branch = x.Branch,
                CountryId = x.CountryId,
                SwiftCode = x.SwiftCode,
                IsPrimary = x.IsPrimary
            }).ToList();
        }

        return result;
    }

    public async Task<Result<bool>> SetPrimaryBankAccount(int id, int influencerId)
    {
        var result = new Result<bool>();

        var influencerBankaccountSpec = new GetInfluencerBankAccountSpec(influencerId, id);
        var bankAccount = await _influencerBankAccountRepository.SingleOrDefaultAsync(influencerBankaccountSpec);

        if (bankAccount == null)
        {
            result.ErrorMessage = "Bank account does not exists";
            result.Error = ErrorType.ResourceNotFound;
            result.Data = false;
            return result;
        }

        bankAccount.IsPrimary = true;

        await _db.InfluencerBankAccounts.Where(x => x.InfluencerId == influencerId)
            .Where(x => x.InfluencerBankAccountId != id)
            .UpdateAsync(_ => new InfluencerBankAccount() { IsPrimary = false });

        await _db.SaveChangesAsync();

        result.Data = true;
        return result;
    }
}
