﻿using System;
using BeTagged.Common.Utils;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Services.Notification;

internal class InAppNotificationService : IInAppNotificationService
{
    private readonly IRepository<User> _usersRepository;
    private readonly IRepository<InAppNotification> _inAppNotificationsRepo;
    private readonly IBtDb _db;

    public InAppNotificationService(IRepository<User> usersRepository, IRepository<InAppNotification> inAppNotificationsRepo, IBtDb db)
    {
        _usersRepository = usersRepository;
        _inAppNotificationsRepo = inAppNotificationsRepo;
        _db = db;
    }

    public async Task SendProductListedNotificationAsync(Guid userKey, int productId, string productUrl, string productName)
    {
        var userId = await GetUserIdAsync(userKey);

        var notificationPayload = NotificationPayloadUtil.BuildProductListedPayload(productId, productUrl, productName);
        NotificationPayloadUtil.TryGetNotificationType(notificationPayload, out var notificationType);

        var entity = BuildInAppNotificationEntity(userId, notificationType!.Value, "Product Listed",
            "A product has been listed", notificationPayload);

        await _inAppNotificationsRepo.AddAsync(entity);

        await _db.SaveChangesAsync();
    }

    public async Task SendXPercentCouponExhaustedNotificationAsync(IEnumerable<Guid> userKeys, int productId, string productUrl,
        string productName, int percentage)
    {
        var userIds = await GetUserIdsAsync(userKeys);
        var arguments =
            NotificationPayloadUtil.BuildPercentageCouponExhaustedPayload(productId, productUrl, productName, percentage);

        NotificationPayloadUtil.TryGetNotificationType(arguments, out var notificationType);

        foreach (var userid in userIds)
        {
            var entity = BuildInAppNotificationEntity(userid, notificationType!.Value, "Coupon Exhausted",
                $"{percentage}% coupons are exhausted.", arguments);

            await _inAppNotificationsRepo.AddAsync(entity);
        }

        await _db.SaveChangesAsync();
    }

    public async Task SendSalesDataNeedsTobeUploadedAsync(Guid userKey, int productId, string productUrl, string productName)
    {
        var userId = await GetUserIdAsync(userKey);
        var arguments =
            NotificationPayloadUtil.BuildSalesDataNeedsToBeUploadedPayload(productId, productUrl, productName);

        NotificationPayloadUtil.TryGetNotificationType(arguments, out var notificationType);

        var entity = BuildInAppNotificationEntity(userId, notificationType!.Value, "Sales Data Upload Reminder",
            "Sales data needs to be uploaded.", arguments);

        await _inAppNotificationsRepo.AddAsync(entity);

        await _db.SaveChangesAsync();
    }

    public async Task SendProductRequestApprovedNotificationAsync(Guid userKey, int productId, string productUrl, string productName)
    {
        var userId = await GetUserIdAsync(userKey);
        var arguments = NotificationPayloadUtil.BuildProductRequestApprovedPayload(productId, productUrl, productName);

        NotificationPayloadUtil.TryGetNotificationType(arguments, out var notificationType);

        var entity = BuildInAppNotificationEntity(userId, notificationType!.Value, "Product Request Approved",
            "Your product request is approved.", arguments);

        await _inAppNotificationsRepo.AddAsync(entity);

        await _db.SaveChangesAsync();
    }

    public async Task SendProductRequestRejectedNotificationAsync(Guid userKey, int productId, string productUrl, string productName)
    {
        var userId = await GetUserIdAsync(userKey);
        var arguments = NotificationPayloadUtil.BuildProductRequestRejectedPayload(productId, productUrl, productName);

        NotificationPayloadUtil.TryGetNotificationType(arguments, out var notificationType);

        var entity = BuildInAppNotificationEntity(userId, notificationType!.Value, "Product Request Rejected",
            "Your product request is rejected.", arguments);

        await _inAppNotificationsRepo.AddAsync(entity);

        await _db.SaveChangesAsync();
    }

    public async Task SendProductUnlistedNotificationAsync(IEnumerable<Guid> userKeys, int productId, string productUrl, string productName)
    {
        var userIds = await GetUserIdsAsync(userKeys);
        var arguments = NotificationPayloadUtil.BuildProductRequestRejectedPayload(productId, productUrl, productName);

        NotificationPayloadUtil.TryGetNotificationType(arguments, out var notificationType);

        foreach (var userId in userIds)
        {
            var entity = BuildInAppNotificationEntity(userId, notificationType!.Value, "Product Unlisted", "Product you were promoting was unlisted.", arguments);
            await _inAppNotificationsRepo.AddAsync(entity);
        }

        await _db.SaveChangesAsync();
    }

    public async Task SendProductListingReminderNotificationAsync(Guid userKey, int daysWithoutListingProduct)
    {
        var userId = await GetUserIdAsync(userKey);
        var arguments = NotificationPayloadUtil.BuildProductListingReminderPayload(daysWithoutListingProduct);

        NotificationPayloadUtil.TryGetNotificationType(arguments, out var notificationType);

        var entity = BuildInAppNotificationEntity(userId, notificationType!.Value, "Product Listing Reminder",
            "It's been long, list a product", arguments);

        await _inAppNotificationsRepo.AddAsync(entity);

        await _db.SaveChangesAsync();
    }

    public async Task SendInfluencerSeekingApprovalNotificationAsync(IEnumerable<Guid> userKeys, int productId, string productUrl,
        string productName)
    {
        var userIds = await GetUserIdsAsync(userKeys);

        var arguments = NotificationPayloadUtil.BuildInfluencerSeekingApprovalPayload(productId, productUrl, productName);
        NotificationPayloadUtil.TryGetNotificationType(arguments, out var notificationType);

        foreach (var userId in userIds)
        {
            var entity = BuildInAppNotificationEntity(userId, notificationType!.Value, "Influencers Seeking Approval",
                "Influencers Seeking Approval", arguments);

            await _inAppNotificationsRepo.AddAsync(entity);
        }

        await _db.SaveChangesAsync();
    }

    public async Task SendReminderForPickProductToInfluencerAsync(int userId, int daysWithoutPickingAProduct)
    {
        var arguments = NotificationPayloadUtil.BuildReminderForPickingAProductPayload(daysWithoutPickingAProduct);
        NotificationPayloadUtil.TryGetNotificationType(arguments, out var notificationType);

        var entity = BuildInAppNotificationEntity(userId, notificationType!.Value, "Start promoting a product",
            "Start promoting a product", arguments);

        await _inAppNotificationsRepo.AddAsync(entity);

        await _db.SaveChangesAsync();
    }

    private static InAppNotification BuildInAppNotificationEntity(int userId, SystemInAppNotificationTypeOption type, string title,
        string content, Dictionary<string, object> payload)
    {
        var entity = new InAppNotification()
        {
            UserId = userId,
            SystemInAppNotificationTypeId = type,
            Arguments = payload.Serialize(),
            Title = title,
            Content = content
        };

        return entity;
    }

    private async Task<int> GetUserIdAsync(Guid userKey)
    {
        var getUserIdSpec = new GetUserIdSpec(userKey);
        var userId = await _usersRepository.SingleAsync(getUserIdSpec);
        return userId;
    }

    private async Task<IList<int>> GetUserIdsAsync(IEnumerable<Guid> userKeys)
    {
        var getUserIdsSpec = new GetUserIdsSpec(userKeys);
        return await _usersRepository.ListAsync(getUserIdsSpec);
    }
}
