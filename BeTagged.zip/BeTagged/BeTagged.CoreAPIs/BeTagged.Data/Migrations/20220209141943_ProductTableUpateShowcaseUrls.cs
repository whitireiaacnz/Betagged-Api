﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class ProductTableUpateShowcaseUrls : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AddColumn<List<string>>(
            name: "show_case_media_urls",
            schema: "public",
            table: "brand_products",
            type: "text[]",
            nullable: true);

        migrationBuilder.Sql("alter table brand_products add constraint ck_price_gt_zero check ( price >= 0 );");
        migrationBuilder.Sql("alter table brand_products add constraint ck_commission_percentate_range check ( commission_percentage >= 0 AND commission_percentage <= 100 );");
        migrationBuilder.Sql("alter table brand_products add constraint ck_buyer_discount_range check ( buyer_discount_percentage >= 0 AND buyer_discount_percentage <= 100 );");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropColumn(
            name: "show_case_media_urls",
            schema: "public",
            table: "brand_products");

        migrationBuilder.Sql("alter table brand_products drop constraint ck_price_gt_zero;");
        migrationBuilder.Sql("alter table brand_products drop constraint ck_commission_percentate_range;");
        migrationBuilder.Sql("alter table brand_products drop constraint ck_buyer_discount_range;");
    }
}
