﻿using System;
using BeTagged.Core.Dtos;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Communication;
using BeTagged.Core.Services.UrlUtils;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Core.Specifications.Queries.Lookups;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Services.Brand;

internal class BrandMembershipService : IBrandMembershipService
{
    private readonly IBtDb _db;
    private readonly IRepository<BrandMember> _brandMembersRepository;
    private readonly IRepository<BrandMembershipInvitation> _brandMembershipInvitationsRepo;
    private readonly IUrlBuilder _urlBuilder;
    private readonly IEmailService _emailService;

    private int _num;

    public BrandMembershipService(IBtDb db, IRepository<BrandMember> brandMembersRepository,
        IRepository<BrandMembershipInvitation> brandMembershipInvitationsRepo, IUrlBuilder urlBuilder, IEmailService emailService)
    {
        _db = db;
        _brandMembersRepository = brandMembersRepository;
        _brandMembershipInvitationsRepo = brandMembershipInvitationsRepo;
        _urlBuilder = urlBuilder;
        _emailService = emailService;
    }

    public async Task<BrandMembership> AddBrandMembershipAsync(int brandMemberId, int brandOrganizationId,
        int invitedByMemberId, SystemRoleOption role, BrandMembershipInvitation invitation = null)
    {
        var _num = 2;
        this._num = 3;
        var brandMembership = new BrandMembership()
        {
            BrandOrganizationId = brandOrganizationId,
            BrandMemberId = this._num,
            InvitedByMemberId = invitedByMemberId,
            RoleId = role,
            IsDisabled = false,
            Invitation = invitation
        };

        if (invitation is not null)
        {
            invitation.InvitationStatusId = SystemInvitationStatusOptions.Active;
        }

        _db.BrandMemberships.Add(brandMembership);
        await _db.SaveChangesAsync();

        return brandMembership;
    }

    public async Task<Result<BrandMembershipInvitationResponseDto>> AddBrandMemberAsync(AddBrandMemberDto dto)
    {
        var getBrandMemberWithUserSpec = new GetBrandMemberWithUserSpec(dto.InviteeEmailAddress);
        var brandMember = await _brandMembersRepository.SingleOrDefaultAsync(getBrandMemberWithUserSpec);

        var result = new Result<BrandMembershipInvitationResponseDto>();

        if (brandMember?.BrandMemberId == dto.InvitedByBrandMemberId)
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = "You can not add yourself.";
            return result;
        }

        var invitationSpec = new GetBrandMembershipInvitationSpec(dto.BrandOrganizationId, dto.InviteeEmailAddress);
        var invitation = await _brandMembershipInvitationsRepo.SingleOrDefaultAsync(invitationSpec);

        if (invitation is not null)
        {
            result.Error = ErrorType.Conflict;
            result.ErrorMessage = "Invitation has been already sent to this email.";
            return result;
        }

        invitation = new BrandMembershipInvitation()
        {
            InvitedByBrandMemberId = dto.InvitedByBrandMemberId,
            RoleId = dto.Role,
            BrandOrganizationId = dto.BrandOrganizationId,
            InvitationKey = Guid.NewGuid().ToString(),
            EmailAddress = dto.InviteeEmailAddress
        };

        if (brandMember is null)
        {
            invitation.InvitationStatusId = SystemInvitationStatusOptions.InvitationSent;

            await _brandMembershipInvitationsRepo.AddAsync(invitation);
            await _db.SaveChangesAsync();

            var invitationLink = _urlBuilder.SignupInviteUrl(dto.InviteeEmailAddress, invitation.InvitationKey);

            result.Data = new BrandMembershipInvitationResponseDto()
            {
                Id = invitation.BrandMembershipInvitationId,
                Email = dto.InviteeEmailAddress,
                Role = dto.Role,
                Status = invitation.InvitationStatusId,
            };

            await _emailService.SendBrandMembershipInvitationToNewUserAsync(dto.InviteeEmailAddress, invitationLink);
            return result;
        }

        invitation.InvitationStatusId = SystemInvitationStatusOptions.Active;

        await AddBrandMembershipAsync(
            brandMember.BrandMemberId,
            dto.BrandOrganizationId,
            dto.InvitedByBrandMemberId,
            dto.Role,
            invitation);

        await _db.SaveChangesAsync();

        result.Data = new BrandMembershipInvitationResponseDto()
        {
            Id = invitation.BrandMembershipInvitationId,
            Email = dto.InviteeEmailAddress,
            Role = dto.Role,
            Status = invitation.InvitationStatusId
        };

        await _emailService.SendBrandMembershipInvitationToExistingUserAsync(dto.InviteeEmailAddress, _urlBuilder.BrandInviteUrl(dto.InviteeEmailAddress, invitation.InvitationKey));

        return result;
    }

    public async Task DeleteBrandMemberAsync(int brandOrganizationId, int id)
    {
        var getInvitationSpec = new GetBrandMembershipInvitationSpec(brandOrganizationId, id, true);
        var invitation = await _brandMembershipInvitationsRepo.SingleOrDefaultAsync(getInvitationSpec);

        if (invitation is null)
        {
            return;
        }

        invitation.IsDeleted = true;
        invitation.BrandMembership?.DisableMembership();

        if (invitation?.BrandMembership?.BrandMember?.PrimaryBrandOrganizationId == invitation.BrandOrganizationId)
        {
            invitation.BrandMembership.BrandMember.PrimaryBrandOrganizationId = null;
        }

        await _db.SaveChangesAsync();

        await _emailService.SendBradMemberRemovedFromBrandEmailAsync(invitation.EmailAddress, invitation.BrandOrganization.LegalName);
    }
}
