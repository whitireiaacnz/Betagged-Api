﻿namespace BeTagged.Core.Constants;

public static class ValidationMessages
{
    public const string LinkMustBeValidUri = "Link must be a valid URI.";

    public const string EmailDoesNotExists = "Email doesn't exists.";

    public const string PhoneDoesNotExists = "Phone doesn't exists.";

    public const string FileMustBeValidZip = "File must be a valid Zip.";

    public const string DiscountCodesFileMustBeExcelFile = "Discount codes file should be an excel with '.xlsx' extension.";

    public const string SalesDataFileMustBeExcelFile = "Sales data file should be an excel with '.xlsx' extensions.";

    public const string PasswordMustBeValid = "Password must have minimum 8 characters, at least 1 uppercase letter, 1 lowercase letter and a numeric character.";

    public const string ProductDoesNotExist = "Product Doesn't Exists";

    public const string InvalidCountry = "Invalid Country.";

    public const string InvalidCity = "City is not valid.";

    public const string LocationIsRequiredWithCity = "Location is required when city is specified.";

    public const string CountryDoesNotExists = "Country doesn't exists.";

    public const string BlacklistedEmailMessage = "The Email Domain is not Allowed, Please try with another Domain.";

    public const string PhoneIsNotValid = "Phone is not valid.";

    public const string ProfilePictureMustBeImageFile = "Profile Picture must be an image file.";

    public const string ProvideAtLeastOneSocialMediaHandle = "Provide at least one social media handle.";

    public const string InvalidDirectory = "File path is invalid.";

    public const string TermsAndConditionNotAccepted = "Terms and conditions are not accepted.";

    public const string ProductUnlisted = "Product is unlisted";
}
