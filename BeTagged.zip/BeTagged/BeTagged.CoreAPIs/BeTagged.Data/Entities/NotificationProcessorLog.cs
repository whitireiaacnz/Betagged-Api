﻿using System;

namespace BeTagged.Data.Entities;

public class NotificationProcessorLog : BaseEntity
{
    public int NotificationProcessorLogId { get; set; }

    public string Payload { get; set; }

    public Guid IdempotencyKey { get; set; }

    public bool IsProcessed { get; set; }

    public string Error { get; set; }
}
