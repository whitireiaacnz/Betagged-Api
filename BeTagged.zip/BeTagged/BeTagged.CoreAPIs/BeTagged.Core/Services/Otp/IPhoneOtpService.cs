﻿namespace BeTagged.Core.Services.Otp;

public interface IPhoneOtpService
{
    Task GenerateAndSendPhoneOtpAsync(Phone phone, SystemOtpUsageTypeOption otpUsageType);

    Task<Result<bool>> VerifyPhoneAsync(int userId, int phoneId, string otp, SystemOtpUsageTypeOption otpUsageType);
}
