﻿using System;
using System.Threading;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetAllBrandMembersUserKeyForOrganizationSpec : IListResultQuerySpecification<BrandMembership, Guid>
{
    public GetAllBrandMembersUserKeyForOrganizationSpec(int brandOrganizationId)
    {
        Query = async (q, ctx) => await q
            .Include(x => x.BrandMember.User)
            .Where(x => !x.IsDisabled)
            .Where(x => x.BrandOrganizationId == brandOrganizationId)
            .Select(x => x.BrandMember.User.UserKey)
            .ToListAsync(ctx);
    }

    public Func<IQueryable<BrandMembership>, CancellationToken, Task<IList<Guid>>> Query { get; }
}
