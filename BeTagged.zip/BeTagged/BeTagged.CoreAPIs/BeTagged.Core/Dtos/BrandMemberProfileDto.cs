﻿using System;

namespace BeTagged.Core.Dtos;

public class BrandMemberProfileDto
{
    public string ProfilePicUrl { get; set; }

    public DateTime MemberSince { get; set; }

    public SystemRoleOption Role { get; set; }

    public IEnumerable<UserEmailAddressDto> EmailAddresses { get; set; }

    public IEnumerable<UserPhoneDto> Phones { get; set; }
}
