﻿using System;
using BeTagged.Core.Dtos;

namespace BeTagged.Core.Services.CDP;

public interface ICdpService
{
    Task CreateUserProfileAsync(Guid userKey, CreateUserDto userDto);

    Task AddHasCompletedSignupUserAttributeAsync(Guid userKey);

    Task AddHasCompletedOnboardingUserAttributeAsync(Guid userKey);

    Task AddHasListedAProductUserAttributeAsync(Guid userKey);

    Task UpdateUserNameAsync(Guid userKey, string name);

    Task UpdateUserEmailAsync(Guid userKey, string email);

    Task IncrementProductsSoldCountAsync(Guid userKey, int count);

    Task DecrementProductSoldCountAsync(Guid userKey, int count);

    Task UpdateUserPhoneAsync(Guid userKey, string countryCode, string phoneNumber);

    #region Events

    Task SendSignupCompletedEventAsync(Guid userKey);

    Task SendOnboardingCompletedEventAsync(Guid userKey);

    Task SendProductListedEventAsync(Guid userKey, string brandProductUrl, int brandProductId, string productName);

    Task SendXPercentageCouponExhaustedEventAsync(IEnumerable<Guid> userKeys, int percentage, string brandProductUrl,
        int brandProductId, string productName);

    Task SendSalesDataNeedsToBeUploadedEventAsync(Guid userKey, string brandProductUrl, int brandProductId, string productName);

    Task SendProductSoldEventAsync(Guid userKey);

    Task SendProductRequestApprovedEventAsync(Guid userKey, int productId, string productUrl, string productName);

    Task SendProductRequestRejectedEventAsync(Guid userKey, int productId, string productUrl, string productName);

    Task SendProductUnlistedEventAsync(IEnumerable<Guid> userKeys, int productId, string productUrl,
        string productName);

    Task SendProductListingReminderEventAsync(Guid userKey, int daysWithoutListingProduct);

    Task SendInfluencerSeekingApprovalEventAsync(IEnumerable<Guid> userKeys, int productId, string productUrl,
        string productName);

    Task SendReminderForPickingAProductToInfluencerAsync(Guid userKey, int daysWithoutPickingAProduct);

    Task SendCompleteSignupReminderEventAsync(Guid userKey);

    Task SendCompleteOnboardingReminderEventAsync(Guid userKey);

    #endregion
}
