﻿namespace BeTagged.Core.Services.ProductSales;

public interface IProductSalesDbSeeder
{
    public Task SeedProductSalesAsync(int productPromotionId, int brandOrganizationId, int brandProductId, int influencerId, SystemSalesChannelOption salesChannel);
}
