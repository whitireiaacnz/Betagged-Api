﻿using System;

namespace BeTagged.Core.Exceptions;

[Serializable]
public class PhoneTransportException : Exception
{
    public PhoneTransportException(string message, Exception innerException)
        : base(message, innerException)
    {
    }
}
