﻿using System;

namespace BeTagged.Core.Services.Clevertap;

public class ClevertapEvent
{
    public ClevertapEvent()
    {
        Type = "event";
    }

    public Guid Identity { get; set; }

    public string Type { get; }

    public string EvtName { get; set; }

    public Dictionary<string, object> EvtData { get; set; }
}
