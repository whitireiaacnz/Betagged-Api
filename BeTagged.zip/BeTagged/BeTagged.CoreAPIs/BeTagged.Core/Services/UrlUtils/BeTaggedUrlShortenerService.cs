﻿namespace BeTagged.Core.Services.UrlUtils;

using System;
using System.Net.Http;
using System.Text;
using BeTagged.Common.Utils;
using BeTagged.Core.Configurations;

internal class BeTaggedUrlShortenerService : IUrlShortenerService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly AppConfiguration _appConfiguration;

    public BeTaggedUrlShortenerService(IHttpClientFactory httpClientFactory, AppConfiguration appConfiguration)
    {
        _httpClientFactory = httpClientFactory;
        _appConfiguration = appConfiguration;
    }

    public async Task<string> ShortenUrlAsync(Uri uri)
    {
        if (_appConfiguration.IsLocalEnvironment)
        {
            return $"https://bta.gd/{ThreadSafeRandom.Next(1000000)}";
        }

        var client = _httpClientFactory.CreateClient(HttpClients.BtUrlShortener);

        using (client)
        {
            var payload = new
            {
                Url = uri.ToString()
            };

            var content = new StringContent(payload.Serialize(), Encoding.UTF8, ContentTypes.ApplicationJson);
            var response = await client.PostAsync("/api/shortened-urls", content);

            var responseStringContent = await response.Content.ReadAsStringAsync();

            return responseStringContent.Deserialize<Dictionary<string, string>>()["shortenedUrl"];
        }
    }
}
