﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace BeTagged.Core.Utils;

public static class BtHasher
{
    public static string Hash(string input)
    {
        using var sha = SHA256.Create();
        byte[] textBytes = Encoding.UTF8.GetBytes(input);
        byte[] hashBytes = sha.ComputeHash(textBytes);

        return BitConverter
            .ToString(hashBytes)
            .Replace("-", String.Empty);
    }
}
