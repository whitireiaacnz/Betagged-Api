﻿namespace BeTagged.Core.Configurations;

public class ShopifyConfiguration
{
    public const string Section = "ShopifyConfiguration";

    public string Url { get; set; }

    public string AccessToken { get; set; }

    public string WebhookUrl { get; set; }
}
