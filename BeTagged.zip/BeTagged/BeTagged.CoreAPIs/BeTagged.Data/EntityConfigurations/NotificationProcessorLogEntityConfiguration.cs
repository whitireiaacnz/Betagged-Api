﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

public class NotificationProcessorLogEntityConfiguration : IEntityTypeConfiguration<NotificationProcessorLog>
{
    public void Configure(EntityTypeBuilder<NotificationProcessorLog> builder)
    {
        builder.HasKey(x => x.NotificationProcessorLogId);
        builder.Property(x => x.NotificationProcessorLogId).UseIdentityAlwaysColumn();
        builder.HasIndex(x => x.IdempotencyKey);
    }
}
