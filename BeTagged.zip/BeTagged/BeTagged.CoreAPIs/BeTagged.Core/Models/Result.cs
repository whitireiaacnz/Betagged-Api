﻿using BeTagged.Common.Extensions;
using BeTagged.Core.Enums;
using Newtonsoft.Json;

namespace BeTagged.Core.Models;

public abstract class Result
{
    protected Result() => Errors = new List<ErrorItem>();

    [JsonIgnore]
    public bool IsSuccess => Error is null && string.IsNullOrEmpty(ErrorMessage);

    [JsonIgnore]
    public ErrorType? Error { get; set; }

    [JsonIgnore]
    public string ErrorMessage { get; set; }

    [JsonIgnore]
    public IList<ErrorItem> Errors { get; }

    public T Map<T>() where T : Result, new()
    {
        var instance = new T { Error = Error };
        instance.Errors.AddRange(Errors);
        instance.ErrorMessage = ErrorMessage;

        return instance;
    }
}

public class Result<T> : Result
{
    public virtual T Data { get; set; }

    public new TResult Map<TResult>() where TResult : Result<T>, new()
    {
        var instance = base.Map<TResult>();
        instance.Data = Data;
        return instance;
    }
}
