﻿using System.Threading;
using BeTagged.Core.Specifications.Queries.Lookups;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Queries.Lookups;

public static class SystemCountriesLookup
{
    public record Query : IRequest<IEnumerable<SystemCountryLookupItem>>;

    public class Handler : IRequestHandler<Query, IEnumerable<SystemCountryLookupItem>>
    {
        private readonly IReadOnlyRepository<SystemCountry> _systemCountryRepo;

        public Handler(IReadOnlyRepository<SystemCountry> systemCountryRepo)
        {
            _systemCountryRepo = systemCountryRepo;
        }

        public async Task<IEnumerable<SystemCountryLookupItem>> Handle(Query request, CancellationToken cancellationToken)
            => await _systemCountryRepo.ListAsync(new GetSystemCountriesLookupSpec(), cancellationToken);
    }
}
