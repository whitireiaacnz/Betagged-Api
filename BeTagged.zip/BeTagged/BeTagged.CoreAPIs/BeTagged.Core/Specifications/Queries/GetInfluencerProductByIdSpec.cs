﻿using System;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetInfluencerProductByIdSpec : ISingleResultQuerySpecification<BrandProduct, BrandProduct>
{
    public GetInfluencerProductByIdSpec(int influencerId, int brandProductId, byte countryId)
    {
        var statusTypes = new[] { SystemProductStatusOption.Listed, SystemProductStatusOption.Unlisted };
        Query = queryable => queryable
            .Include(x => x.Categories)
            .Include(x => x.Country)
            .Include(x => x.ProductPromotionRequests.Where(y => y.InfluencerId == influencerId
                                                                && y.BrandProductId == brandProductId))
            .Include(x => x.ProductPromotions.Where(y => y.InfluencerId == influencerId
                                                         && y.BrandProductId == brandProductId))
            .ThenInclude(x => x.ProductPromotionLink)
            .Include(x => x.ProductPromotions.Where(y => y.InfluencerId == influencerId
                                                         && y.BrandProductId == brandProductId))
            .ThenInclude(x => x.DiscountCode)
            .Include(x => x.BrandOrganization)
            .AsNoTracking()
            .Where(x => x.BrandProductId == brandProductId)
            .Where(x => x.ProductPromotions.Any(y => y.InfluencerId == influencerId) == false ? x.ProductStatusId == SystemProductStatusOption.Listed : statusTypes.Contains(x.ProductStatusId))
            .Where(x => x.CountryId == countryId);
    }

    public Func<IQueryable<BrandProduct>, IQueryable<BrandProduct>> Query { get; }
}
