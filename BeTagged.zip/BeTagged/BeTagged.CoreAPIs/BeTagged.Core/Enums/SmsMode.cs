﻿namespace BeTagged.Core.Enums;

public enum SmsMode : byte
{
    Test,
    Live
}
