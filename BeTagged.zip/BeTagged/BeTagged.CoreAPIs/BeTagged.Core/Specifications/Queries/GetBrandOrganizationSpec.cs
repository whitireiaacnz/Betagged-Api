﻿using System;
using BeTagged.Data.Specifications;

namespace BeTagged.Core.Specifications.Queries;

public class GetBrandOrganizationSpec : ISingleResultQuerySpecification<BrandOrganization, BrandOrganization>
{
    public GetBrandOrganizationSpec(int brandOrganizationId)
    {
        Query = q => q.Where(x => x.BrandOrganizationId == brandOrganizationId);
    }

    public Func<IQueryable<BrandOrganization>, IQueryable<BrandOrganization>> Query { get; }
}
