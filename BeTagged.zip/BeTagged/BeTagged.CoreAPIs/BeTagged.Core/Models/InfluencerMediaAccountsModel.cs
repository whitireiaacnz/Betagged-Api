﻿namespace BeTagged.Core.Models;
public class InfluencerMediaAccountsModel
{
    public string Instagram { get; set; }

    public string TikTok { get; set; }

    public string Twitter { get; set; }

    public string Facebook { get; set; }
}
