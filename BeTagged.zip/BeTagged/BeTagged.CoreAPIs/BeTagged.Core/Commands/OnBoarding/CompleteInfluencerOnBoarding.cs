﻿using System.Threading;
using BeTagged.Common.Extensions;
using BeTagged.Core.Enums;
using BeTagged.Core.Services;
using BeTagged.Core.Services.BackgroundWork;
using BeTagged.Core.Services.CDP;
using BeTagged.Core.Services.Communication;
using BeTagged.Core.Services.Notification;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Core.Utils;
using BeTagged.Data.Queries;
using BeTagged.Data.Repositories;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Commands.OnBoarding;

public static class CompleteInfluencerOnBoarding
{
    public class Command : IRequest<Response>
    {
        public Command() => Categories = Enumerable.Empty<int>();

        public string FullName { get; set; }

        public string City { get; set; }

        public LocationPoint Location { get; set; }

        public byte Country { get; set; }

        public IEnumerable<int> Categories { get; set; }

        public InfluencerMediaAccountsModel SocialMediaAccounts { get; set; }

        public bool HasAcceptedTermsAndCondition { get; set; }
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.FullName)
           .NotEmpty()
           .MinimumLength(2)
           .MaximumLength(64)
           .Matches(PropertyValidationUtil.OnlyAlphabetRegex)
           .WithMessage("Name must only contain alphabets.");

            RuleFor(x => x.City)
                .Must(PropertyValidationUtil.IsCityValid)
                .When(x => x.City.IsNotNullOrEmpty())
                .WithMessage(ValidationMessages.InvalidCity);

            RuleFor(x => x.Location).NotNull()
                .When(x => x.City.IsNotNullOrEmpty())
                .WithMessage(ValidationMessages.LocationIsRequiredWithCity);

            RuleFor(x => x.Categories).Must(x => x.Any());

            RuleFor(x => x.Country).GreaterThan((byte)0);

            RuleFor(x => x).Must(x => x.SocialMediaAccounts.Facebook != null
                        || x.SocialMediaAccounts.Twitter != null
                        || x.SocialMediaAccounts.TikTok != null
                        || x.SocialMediaAccounts.Instagram != null)
                .WithMessage(ValidationMessages.ProvideAtLeastOneSocialMediaHandle);
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly ICurrentInfluencer _currentInfluencer;
        private readonly IBtDb _db;
        private readonly IEmailService _emailService;
        private readonly IRepository<SystemCountry> _countriesRepository;
        private readonly IBackgroundWorker _backgroundWorker;
        private readonly INotificationService _notificationService;
        private readonly IInfluencerProductPromotionReminderService _influencerProductPromotionReminderService;

        public Handler(ICurrentInfluencer currentInfluencer, IBtDb db, IEmailService emailService,
            IRepository<SystemCountry> countriesRepository,
            IBackgroundWorker backgroundWorker, INotificationService notificationService,
            IInfluencerProductPromotionReminderService influencerProductPromotionReminderService)
        {
            _currentInfluencer = currentInfluencer;
            _db = db;
            _emailService = emailService;
            _countriesRepository = countriesRepository;
            _backgroundWorker = backgroundWorker;
            _notificationService = notificationService;
            _influencerProductPromotionReminderService = influencerProductPromotionReminderService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var response = new Response();

            var getCountrySpec = new GetCountrySpec(request.Country);

            var country = await _countriesRepository.SingleOrDefaultAsync(getCountrySpec, cancellationToken);

            if (country is null)
            {
                response.Error = ErrorType.ValidationError;
                response.ErrorMessage = ValidationMessages.InvalidCountry;
                return response;
            }

            var influencer = await _db.Influencers
                            .Include(x => x.User)
                            .Where(x => x.InfluencerId == _currentInfluencer.InfluencerId)
                            .SingleAsync(cancellationToken);

            if (influencer.User.Name.IsNotNullOrEmpty())
            {
                return response;
            }

            if (!request.HasAcceptedTermsAndCondition)
            {
                response.Error = ErrorType.ValidationError;
                response.ErrorMessage = ValidationMessages.TermsAndConditionNotAccepted;
                return response;
            }

            influencer.HasAcceptedTermsAndCondition = request.HasAcceptedTermsAndCondition;
            influencer.User.Name = request.FullName;

            var categories = await _db.SystemCategories.GetCategoriesAsync(request.Categories, cancellationToken);

            influencer.Categories = categories.ToList();
            influencer.City = request.City;
            influencer.Country = country;

            var socialMedia = request.SocialMediaAccounts;
            influencer.SocialMediaAccounts = new InfluencerMediaAccounts()
            {
                Facebook = new()
                {
                    MetaData = null,
                    Username = socialMedia.Facebook
                },
                Instagram = new()
                {
                    MetaData = null,
                    Username = socialMedia.Instagram
                },
                TikTok = new()
                {
                    MetaData = null,
                    Username = socialMedia.TikTok
                },
                Twitter = new()
                {
                    MetaData = null,
                    Username = socialMedia.Twitter
                }
            };

            if (request.Location is not null)
            {
                influencer.SetLocation(request.Location.Longitude, request.Location.Latitude);
            }

            await _db.SaveChangesAsync(cancellationToken);

            var userEmailAddress = await _db.EmailAddresses
            .Where(x => x.UserId == influencer.User.UserId && x.IsPrimary)
            .SingleAsync(cancellationToken);

            await _emailService.SendWelcomeEmailAsync(userEmailAddress.EmailAddress_);

            _backgroundWorker.Enqueue<ICdpService>(x =>
                x.UpdateUserNameAsync(influencer.User.UserKey, request.FullName));

            _notificationService.SendOnBoardingCompletedNotification(influencer.User.UserKey);
            _influencerProductPromotionReminderService.ScheduleJobToRemindInfluencerToPickProduct(influencer
                .InfluencerId);

            return response;
        }
    }

    public class Response : Result
    {
    }
}
