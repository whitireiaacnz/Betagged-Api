﻿using System;
using System.Linq.Expressions;
using Hangfire;

namespace BeTagged.Core.Services.BackgroundWork;

public class HangfireBackgroundWorker : IBackgroundWorker
{
    private readonly IBackgroundJobClient _backgroundJobClient;

    public HangfireBackgroundWorker(IBackgroundJobClient backgroundJobClient)
        => _backgroundJobClient = backgroundJobClient;

    public string Enqueue(Expression<Action> methodCall)
        => _backgroundJobClient.Enqueue(methodCall);

    public string Enqueue(Expression<Func<Task>> methodCall)
        => _backgroundJobClient.Enqueue(methodCall);

    public string Enqueue<T>(Expression<Action<T>> methodCall)
        => _backgroundJobClient.Enqueue(methodCall);

    public string Enqueue<T>(Expression<Func<T, Task>> methodCall)
        => _backgroundJobClient.Enqueue(methodCall);

    public string Schedule(Expression<Action> methodCall, TimeSpan delay)
        => _backgroundJobClient.Schedule(methodCall, delay);

    public string Schedule(Expression<Func<Task>> methodCall, TimeSpan delay)
        => _backgroundJobClient.Schedule(methodCall, delay);

    public string Schedule<T>(Expression<Action<T>> methodCall, TimeSpan delay)
        => _backgroundJobClient.Schedule(methodCall, delay);

    public string Schedule<T>(Expression<Func<T, Task>> methodCall, TimeSpan delay)
        => _backgroundJobClient.Schedule(methodCall, delay);

    public string Schedule(Expression<Func<Task>> methodCall, DateTime dateTime)
        => _backgroundJobClient.Schedule(methodCall, dateTime);

    public string Schedule<T>(Expression<Func<T, Task>> methodCall, DateTime dateTime)
        => _backgroundJobClient.Schedule(methodCall, dateTime);
}
