﻿using System;
using System.Threading;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class HasUserListedAnyProductSpec : IAnyQuerySpecification<BrandProduct>
{
    public HasUserListedAnyProductSpec(int userId)
    {
        Query = async (q, ctx) => await
            q.AnyAsync(x => x.CreatedByUserId == userId, ctx);
    }

    public Func<IQueryable<BrandProduct>, CancellationToken, Task<bool>> Query { get; }
}
