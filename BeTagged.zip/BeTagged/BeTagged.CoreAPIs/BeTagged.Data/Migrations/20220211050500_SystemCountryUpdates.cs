﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class SystemCountryUpdates : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AlterColumn<int>(
                name: "system_country_id",
                schema: "public",
                table: "system_countries_lut",
                type: "integer",
                nullable: false,
                oldClrType: typeof(byte),
                oldType: "smallint")
            .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

        migrationBuilder.AlterColumn<int>(
            name: "system_country_id",
            schema: "public",
            table: "brand_product_countries",
            type: "integer",
            nullable: false,
            oldClrType: typeof(byte),
            oldType: "smallint");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AlterColumn<byte>(
                name: "system_country_id",
                schema: "public",
                table: "system_countries_lut",
                type: "smallint",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "integer")
            .OldAnnotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn);

        migrationBuilder.AlterColumn<byte>(
            name: "system_country_id",
            schema: "public",
            table: "brand_product_countries",
            type: "smallint",
            nullable: false,
            oldClrType: typeof(int),
            oldType: "integer");
    }
}
