﻿using System.Collections.Generic;
using System.Linq;
using BeTagged.Data.Models;
using BeTagged.Data.Services;

namespace BeTagged.Data.Builders;

public static class SqlBuilder
{
    public static string BuildFilterPredicate(IEnumerable<DynamicFilterItem> filterItems)
    {
        var dynamicFilterItems = filterItems?.ToList();
        if (!(dynamicFilterItems?.Any() ?? false))
        {
            return string.Empty;
        }

        var filters = dynamicFilterItems
            .Select(BuildFilterPredicate)
            .Where(filterSql => !string.IsNullOrEmpty(filterSql))
            .Where(filterSql => filterSql != "()")
            .ToList();

        return string.Join(" and ", filters);
    }

    private static string BuildFilterPredicate(DynamicFilterItem filterItem)
    {
        var filter = filterItem.Filter;

        return filter switch
        {
            IEnumerable<RangeField<int>> fields => $"({BuildRangeFilterPredicate(filterItem, fields)})",
            IEnumerable<InclusiveRangeField<int>> fields => $"({BuildInclusiveRangeFilterPredicate(filterItem, fields)})",
            _ => string.Empty
        };
    }

    private static string BuildRangeFilterPredicate<T>(DynamicFilterItem filterItem, IEnumerable<RangeField<T>> ranges) where T : struct
    {
        if (!ranges.Any())
        {
            return string.Empty;
        }

        IEnumerable<string> filterPredicate = ranges
            .Select(range => $"({BuildRangeFilterPredicate(filterItem, range)})");

        return string.Join(" or ", filterPredicate);
    }

    private static string BuildRangeFilterPredicate<T>(DynamicFilterItem filterItem, RangeField<T> range) where T : struct
    {
        return !range.To.HasValue
            ? $"{filterItem.ColumnName} >= {range.From}"
            : $"{filterItem.ColumnName} >= {range.From} and {filterItem.ColumnName} < {range.To}";
    }

    private static string BuildInclusiveRangeFilterPredicate<T>(DynamicFilterItem filterItem, IEnumerable<InclusiveRangeField<T>> ranges) where T : struct
    {
        if (!ranges.Any())
        {
            return string.Empty;
        }

        List<string> filterPredicate = new List<string>();

        foreach (var range in ranges)
        {
            filterPredicate.Add($"({BuildInclusiveRangeFilterPredicate(filterItem, range)})");
        }

        return string.Join(" or ", filterPredicate);
    }

    private static string BuildInclusiveRangeFilterPredicate<T>(DynamicFilterItem filterItem, InclusiveRangeField<T> range) where T : struct
    {
        return !range.To.HasValue
            ? $"{filterItem.ColumnName} >= {range.From}"
            : $"{filterItem.ColumnName} between {range.From} and {range.To}";
    }
}
