﻿using System;
using System.Threading;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class HasInfluencerRequestForPromotionSpec : IAnyQuerySpecification<ProductPromotionRequest>
{
    public HasInfluencerRequestForPromotionSpec(int influencerId)
    {
        Query = async (q, ctx) => await q
            .AnyAsync(x => x.InfluencerId == influencerId && !x.IsDeleted, ctx);
    }

    public Func<IQueryable<ProductPromotionRequest>, CancellationToken, Task<bool>> Query { get; }
}
