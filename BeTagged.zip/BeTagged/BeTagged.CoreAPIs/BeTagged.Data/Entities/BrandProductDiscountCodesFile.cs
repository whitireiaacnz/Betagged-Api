﻿using System.Collections.Generic;
using BeTagged.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(BrandProductDiscountCodesFileEntityConfiguration))]
public class BrandProductDiscountCodesFile : BaseEntity
{
    public BrandProductDiscountCodesFile()
    {
        DiscountCodes = new List<BrandProductDiscountCode>();
    }

    public int BrandProductDiscountCodesFileId { get; set; }

    public string FilePath { get; set; }

    public int BrandProductId { get; set; }

    public ImportStatus ImportStatusId { get; set; }

    public string ImportError { get; set; }

    // Foreign keys
    public BrandProduct BrandProduct { get; set; }

    // Reverse navigation
    public ICollection<BrandProductDiscountCode> DiscountCodes { get; set; }
}
