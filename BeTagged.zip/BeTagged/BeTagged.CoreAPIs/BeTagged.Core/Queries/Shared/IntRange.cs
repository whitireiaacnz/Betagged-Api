﻿using BeTagged.Data.Models;

namespace BeTagged.Core.Queries.Shared;

public class IntRange : RangeField<int>
{
}

public class IntRangeValidator : AbstractValidator<IntRange>
{
    public IntRangeValidator()
    {
        RuleFor(x => x.From).LessThan(x => x.To)
            .When(x => x.To is not null);
    }
}
