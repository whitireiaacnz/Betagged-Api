﻿using System.Text;

namespace BeTagged.Common.Extensions;

public static class StringExtensions
{
    public static bool IsNotNullOrEmpty(this string input) => !string.IsNullOrEmpty(input);

    public static bool IsNullOrEmpty(this string input) => string.IsNullOrEmpty(input);

    public static int ToInt(this string input) => Convert.ToInt32(input);

    public static bool IsUri(this string input) => Uri.TryCreate(input, UriKind.Absolute, out _);

    public static Uri ToUri(this string input) => new(input);

    public static Uri ToSafeUri(this string input)
    {
        var builder = new UriBuilder(input) { Scheme = "https", Port = 443 };
        return builder.Uri;
    }

    public static StreamReader GetStreamReader(this string input)
    {
        var stream = new MemoryStream();
        var writer = new StreamWriter(stream);
        writer.Write(input);
        writer.Flush();
        stream.Position = 0;
        return new StreamReader(stream);
    }

    public static string ConvertFromBase64(this string base64String)
    {
        var bytes = Convert.FromBase64String(base64String);
        return Encoding.UTF8.GetString(bytes);
    }
}
