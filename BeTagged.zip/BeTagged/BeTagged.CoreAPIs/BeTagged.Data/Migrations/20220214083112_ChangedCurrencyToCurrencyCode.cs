﻿using BeTagged.Data.Seed;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class ChangedCurrencyToCurrencyCode : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropForeignKey(
            name: "fk_brand_products_system_currencies_lut_system_currency_id",
            schema: "public",
            table: "brand_products");

        migrationBuilder.DropTable(
            name: "system_currencies_lut",
            schema: "public");

        migrationBuilder.DropColumn(
            name: "currency_code",
            schema: "public",
            table: "brand_products");

        migrationBuilder.RenameColumn(
            name: "system_currency_id",
            schema: "public",
            table: "brand_products",
            newName: "currency_code_id");

        migrationBuilder.RenameIndex(
            name: "ix_brand_products_system_currency_id",
            schema: "public",
            table: "brand_products",
            newName: "ix_brand_products_currency_code_id");

        migrationBuilder.CreateTable(
            name: "system_currency_code_lut",
            schema: "public",
            columns: table => new
            {
                system_currency_code_id = table.Column<byte>(type: "smallint", nullable: false),
                name = table.Column<string>(type: "text", nullable: true)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_system_currency_code_lut", x => x.system_currency_code_id);
            });

        EnumLookupTableSeeder.FillEnumLookup(migrationBuilder, "system_currency_code_lut", typeof(SystemCurrencyCodeOption));

        migrationBuilder.AddForeignKey(
            name: "fk_brand_products_system_currency_code_lut_currency_code_id",
            schema: "public",
            table: "brand_products",
            column: "currency_code_id",
            principalSchema: "public",
            principalTable: "system_currency_code_lut",
            principalColumn: "system_currency_code_id",
            onDelete: ReferentialAction.Restrict);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropForeignKey(
            name: "fk_brand_products_system_currency_code_lut_currency_code_id",
            schema: "public",
            table: "brand_products");

        migrationBuilder.DropTable(
            name: "system_currency_code_lut",
            schema: "public");

        migrationBuilder.RenameColumn(
            name: "currency_code_id",
            schema: "public",
            table: "brand_products",
            newName: "system_currency_id");

        migrationBuilder.RenameIndex(
            name: "ix_brand_products_currency_code_id",
            schema: "public",
            table: "brand_products",
            newName: "ix_brand_products_system_currency_id");

        migrationBuilder.AddColumn<string>(
            name: "currency_code",
            schema: "public",
            table: "brand_products",
            type: "character varying(4)",
            maxLength: 4,
            nullable: true);

        migrationBuilder.CreateTable(
            name: "system_currencies_lut",
            schema: "public",
            columns: table => new
            {
                system_currency_id = table.Column<byte>(type: "smallint", nullable: false),
                name = table.Column<string>(type: "text", nullable: true)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_system_currencies_lut", x => x.system_currency_id);
            });

        migrationBuilder.AddForeignKey(
            name: "fk_brand_products_system_currencies_lut_system_currency_id",
            schema: "public",
            table: "brand_products",
            column: "system_currency_id",
            principalSchema: "public",
            principalTable: "system_currencies_lut",
            principalColumn: "system_currency_id",
            onDelete: ReferentialAction.Restrict);
    }
}
