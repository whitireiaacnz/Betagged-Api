﻿namespace BeTagged.Core.Dtos;

public class SendEmailDto
{
    public SendEmailDto()
    {
        RecipientEmails = new List<string>();
    }

    public string EmailName { get; set; } = EmailConstants.EmailName;

    public string SendEmail { get; set; }

    public List<string> RecipientEmails { get; set; }

    public object TemplateId { get; set; }

    public dynamic DynamicTemplateData { get; set; }

    public void AddRecipientEmail(string email)
    {
        RecipientEmails.Add(email);
    }

    public void AddRecipientEmails(IEnumerable<string> emails)
    {
        RecipientEmails.AddRange(emails);
    }
}
