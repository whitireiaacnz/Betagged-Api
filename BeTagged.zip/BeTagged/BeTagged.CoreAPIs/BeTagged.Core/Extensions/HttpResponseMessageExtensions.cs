﻿using System.Net.Http;
using BeTagged.Common.Utils;

namespace BeTagged.Core.Extensions;

public static class HttpResponseMessageExtensions
{
    public static async Task<T> ReadResponseAsync<T>(this HttpResponseMessage httpResponseMessage)
    {
        var responseString = await httpResponseMessage.Content.ReadAsStringAsync();
        return responseString.Deserialize<T>();
    }
}
