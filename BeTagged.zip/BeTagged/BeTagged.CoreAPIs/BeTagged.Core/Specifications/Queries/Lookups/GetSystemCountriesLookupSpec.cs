﻿using System;
using System.Threading;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries.Lookups;

public class GetSystemCountriesLookupSpec : IListResultQuerySpecification<SystemCountry, SystemCountryLookupItem>
{
    public GetSystemCountriesLookupSpec()
    {
        Query = async (queryable, ctx) => await queryable
            .OrderBy(x => x.Name)
            .Select(x => new SystemCountryLookupItem(x.SystemCountryId, x.Name)
            {
                IsdCode = x.IsdCode,
                IsoCode = x.IsoCode,
                CurrencyCode = x.CurrencyCode,
                CurrencySymbol = x.CurrencySymbol,
                Iso3Code = x.Iso3Code
            })
            .ToListAsync(ctx);
    }

    public Func<IQueryable<SystemCountry>, CancellationToken, Task<IList<SystemCountryLookupItem>>> Query { get; }
}
