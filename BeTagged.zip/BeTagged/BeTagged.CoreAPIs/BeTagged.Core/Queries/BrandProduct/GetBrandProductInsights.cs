﻿using System;
using System.Threading;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;
using BeTagged.Data.Services;

namespace BeTagged.Core.Queries.BrandProduct;

public static class GetBrandProductInsights
{
    public class Query : IRequest<Response>
    {
        public int BrandProductId { get; set; }

        public DateTime? From { get; set; }

        public DateTime? To { get; set; }
    }

    public class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.From).LessThan(x => x.To)
                .When(x => x.From is not null);
        }
    }

    public class Handler : IRequestHandler<Query, Response>
    {
        private readonly ICurrentBrandMember _currentBrandMember;
        private readonly IQueryService _queryService;
        private readonly IReadOnlyRepository<Data.Entities.BrandProduct> _brandProductsRepository;

        public Handler(ICurrentBrandMember currentBrandMember, IQueryService queryService,
            IReadOnlyRepository<Data.Entities.BrandProduct> brandProductsRepository)
        {
            _currentBrandMember = currentBrandMember;
            _queryService = queryService;
            _brandProductsRepository = brandProductsRepository;
        }

        public async Task<Response> Handle(Query request, CancellationToken cancellationToken)
        {
            var doesProductExistsSpec =
                new DoesBrandProductExistsSpec(_currentBrandMember.BrandOrganizationId, request.BrandProductId);
            var doesProductExists = await _brandProductsRepository.AnyAsync(doesProductExistsSpec, cancellationToken);

            var response = new Response();

            if (!doesProductExists)
            {
                response.Error = ErrorType.ValidationError;
                response.ErrorMessage = ValidationMessages.ProductDoesNotExist;
                return response;
            }

            var parameters = new
            {
                BrandProductId = request.BrandProductId,
                BrandOrganizationId = _currentBrandMember.BrandOrganizationId,
                FromDate = request.From,
                ToDate = request.To,
            };

            var queryResult = await _queryService.QueryMultipleAsync(BtQueryType.GetBrandProductInsight, null, parameters);
            using (queryResult)
            {
                response.Facebook = queryResult.ReadFirst<SalesChannelInsight>();
                response.TikTok = queryResult.ReadFirst<SalesChannelInsight>();
                response.Instagram = queryResult.ReadFirst<SalesChannelInsight>();
                response.Twitter = queryResult.ReadFirst<SalesChannelInsight>();
                response.MonthlySalesDistribution = queryResult.Read<MonthlySales>();
            }

            return response;
        }
    }

    public class Response : Result
    {
        public SalesChannelInsight Facebook { get; set; }

        public SalesChannelInsight TikTok { get; set; }

        public SalesChannelInsight Instagram { get; set; }

        public SalesChannelInsight Twitter { get; set; }

        public IEnumerable<MonthlySales> MonthlySalesDistribution { get; set; }
    }

    public class SalesChannelInsight
    {
        public int Sales { get; set; }

        public int Clicks { get; set; }
    }

    public class MonthlySales
    {
        public DateTime Month { get; set; }

        public int Sales { get; set; }
    }
}
