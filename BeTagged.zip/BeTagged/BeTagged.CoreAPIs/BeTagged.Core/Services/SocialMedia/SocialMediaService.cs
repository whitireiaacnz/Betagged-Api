﻿using System;
using BeTagged.Core.Services.UrlUtils;

namespace BeTagged.Core.Services.SocialMedia;

public class SocialMediaService : ISocialMediaService
{
    private readonly IUrlBuilder _urlBuilder;

    public SocialMediaService(IUrlBuilder urlBuilder)
    {
        _urlBuilder = urlBuilder;
    }

    public string GetSalesChannelLink(SystemSalesChannelOption salesChannelId, InfluencerMediaAccounts socialMediaAccounts)
    {
        switch (salesChannelId)
        {
            case SystemSalesChannelOption.Facebook:
                return _urlBuilder.BuildFacebookHandleUrl(socialMediaAccounts.Facebook.Username);
            case SystemSalesChannelOption.TikTok:
                return _urlBuilder.BuildTikTokHandleUrl(socialMediaAccounts.TikTok.Username);
            case SystemSalesChannelOption.Instagram:
                return _urlBuilder.BuildInstagramHandleUrl(socialMediaAccounts.Instagram.Username);
            case SystemSalesChannelOption.Twitter:
                return _urlBuilder.BuildTwitterHandleUrl(socialMediaAccounts.Twitter.Username);
            default:
                throw new ArgumentOutOfRangeException(nameof(salesChannelId), salesChannelId, null);
        }
    }
}
