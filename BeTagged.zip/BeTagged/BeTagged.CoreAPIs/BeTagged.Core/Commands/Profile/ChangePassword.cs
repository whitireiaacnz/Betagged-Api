﻿using System.Threading;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Users;
using BeTagged.Core.Utils;

namespace BeTagged.Core.Commands.Profile;

public static class ChangePassword
{
    public class Command : IRequest<Response>
    {
        public string OldPassword { get; set; }

        public string NewPassword { get; set; }
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.OldPassword).NotEmpty();
            RuleFor(x => x.NewPassword).NotEmpty().Matches(PropertyValidationUtil.PasswordRegex)
                .WithMessage(ValidationMessages.PasswordMustBeValid);
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IUserService _userService;

        private readonly ICurrentUser _currentUser;

        public Handler(IUserService userService, ICurrentUser currentUser)
        {
            _userService = userService;
            _currentUser = currentUser;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var passwordResponse = await _userService.ValidateAndChangePassword(request.OldPassword, request.NewPassword, _currentUser.UserId);

            return passwordResponse.Map<Response>();
        }
    }

    public class Response : Result<string>
    {
    }
}
