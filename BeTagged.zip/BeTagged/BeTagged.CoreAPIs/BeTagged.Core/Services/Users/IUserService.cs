﻿using System;
using BeTagged.Core.Dtos;

namespace BeTagged.Core.Services.Users;

public interface IUserService
{
    Task<Result<User>> CreateUserAsync(CreateUserDto createUser);

    Task ChangePasswordAsync(int userId, string password);

    Task<Result<UserEmailAddressDto>> AddUnverifiedEmailAsync(string emailAddress);

    Task<Result<UserPhoneDto>> AddUnverifiedPhoneAsync(string countryCode, string phoneNumber);

    Task<Result<string>> ValidateAndChangePassword(string currentPassword, string newPassword, int userId);

    Task<string> AddProfilePicture(string url, int userId);

    Task<Result<bool>> SetPrimaryEmail(int emailAddressId, int userId);

    Task<Result<bool>> SetPrimaryPhone(int phoneId, int userId);

    Task<Guid> GetUserKeyAsync(int userId);
}
