﻿using Microsoft.Extensions.Configuration;
using Serilog;

namespace BeTagged.Common.Logging;

public static class BeTaggedLogger
{
    public static void CreateLogger(IConfiguration configuration)
    {
        Log.Logger = new LoggerConfiguration()
            .Enrich.FromLogContext()
            .Enrich.WithThreadId()
            .Enrich.WithThreadName()
            .Enrich.WithEnvironmentUserName()
            .Enrich.WithMachineName()
            .Enrich.WithProcessName()
            .Enrich.WithProcessId()
            .WriteTo.Console()
            .WriteTo.Sentry()
            .ReadFrom.Configuration(configuration)
            .CreateLogger();
    }
}
