﻿namespace BeTagged.Core.Dtos;

public class BrandInsightsInfluencerInfoDto
{
    public string InfluencerProfilePicUrl { get; set; }

    public string InfluencerName { get; set; }

    public int Sales { get; set; }

    public decimal Commission { get; set; }

    public IEnumerable<BrandProductInfo> ProductsSold { get; set; }

    public string CurrencyCode { get; internal set; }

    public string CurrencySymbol { get; internal set; }
}

public class BrandProductInfo
{
    public string BrandProductName { get; set; }

    public int BrandProductId { get; set; }
}
