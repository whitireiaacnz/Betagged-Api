﻿namespace BeTagged.Common.Utils;

public static class ThreadSafeRandom
{
    private static readonly ThreadLocal<Random> Random = new(() => new Random(GetSeed()));

    public static int Next(int min, int max) => Random.Value.Next(min, max);

    public static int Next(int max) => Random.Value.Next(max);

    public static T Next<T>(IList<T> list)
    {
        if (list is null || list.Count == 0) { return default; }

        return list[Next(0, list.Count)];
    }

    public static double NextDouble() => Random.Value.NextDouble();

    private static int GetSeed() => Environment.TickCount * Environment.CurrentManagedThreadId;
}
