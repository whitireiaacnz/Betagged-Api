﻿using System;
using BeTagged.Data.Specifications;

namespace BeTagged.Core.Specifications.Queries;

public class GetEmailAddressSpec : ISingleResultQuerySpecification<EmailAddress, EmailAddress>
{
    public GetEmailAddressSpec(string emailAddress)
    {
        var normalizedEmail = emailAddress.ToUpper();

        Query = queryable => queryable
        .Where(x => x.NormalizedEmailAddress == normalizedEmail);
    }

    public GetEmailAddressSpec(int emailAddressId, int userId)
    {
        Query = queryable => queryable
        .Where(x => x.EmailAddressId == emailAddressId && x.UserId == userId);
    }

    public Func<IQueryable<EmailAddress>, IQueryable<EmailAddress>> Query { get; }
}
