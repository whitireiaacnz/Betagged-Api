﻿using System.Threading;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Users;

namespace BeTagged.Core.Commands.Profile;

public static class SetEmailPrimary
{
    public record Command(int EmailAddressId) : IRequest<Response>;

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IUserService _userService;

        private readonly ICurrentUser _currentUser;

        public Handler(IUserService userService, ICurrentUser currentUser)
        {
            _userService = userService;
            _currentUser = currentUser;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            Result response = await _userService.SetPrimaryEmail(request.EmailAddressId, _currentUser.UserId);

            return response.Map<Response>();
        }
    }

    public class Response : Result
    {
    }
}
