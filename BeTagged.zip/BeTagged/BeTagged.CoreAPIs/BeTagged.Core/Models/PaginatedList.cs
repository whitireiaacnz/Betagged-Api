﻿using Newtonsoft.Json;

namespace BeTagged.Core.Models;

public class PaginatedList<T>
{
    private readonly int _currentSkip;

    private readonly int _currentTake;

    public PaginatedList(int? totalCount, IEnumerable<T> data, int currentSkip, int currentTake)
    {
        _currentSkip = currentSkip;
        _currentTake = currentTake;
        TotalCount = totalCount;
        Data = data;
        HasNext = _currentSkip + _currentTake < TotalCount;
    }

    public PaginatedList(IEnumerable<T> data, int currentSkip, int currentTake)
    {
        _currentSkip = currentSkip;
        _currentTake = currentTake;
        Data = data.Take(currentTake);
        HasNext = data.Count() > currentTake;
    }

    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public int? TotalCount { get; }

    public string PreviousLink { get; set; }

    public string NextLink { get; set; }

    public IEnumerable<T> Data { get; }

    [JsonIgnore]
    public bool HasNext { get; }

    [JsonIgnore]
    public bool HasPrevious => _currentSkip > 0;
}
