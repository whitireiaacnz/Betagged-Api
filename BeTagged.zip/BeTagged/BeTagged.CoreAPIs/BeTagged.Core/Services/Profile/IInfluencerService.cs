﻿using System.Threading;
using BeTagged.Core.Dtos;

namespace BeTagged.Core.Services.Profile;

public interface IInfluencerService
{
    Task<Result<bool>> UpdateSocialMediaHandle(int influencerId, InfluencerMediaAccountsModel SocialMediaAccounts);

    Task DeleteInfluencerBankAccountAsync(int influencerId, int id);

    Task<InfluencerBankAccountDto> AddBankAccountAsync(int influencerId, InfluencerBankAccountDto bankAccountInfo);

    Task<IEnumerable<InfluencerBankAccountDto>> GetInfluencerBankAccountsAsync(int influencerId, CancellationToken cancellationToken = default);

    Task<Result<bool>> SetPrimaryBankAccount(int id, int influencerId);
}
