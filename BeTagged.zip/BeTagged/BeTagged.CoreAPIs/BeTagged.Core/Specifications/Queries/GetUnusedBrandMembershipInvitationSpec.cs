﻿using System;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetUnusedBrandMembershipInvitationSpec : ISingleResultQuerySpecification<BrandMembershipInvitation, BrandMembershipInvitation>
{
    public GetUnusedBrandMembershipInvitationSpec(string email, string invitationKey)
    {
        Query = q => q
            .Include(x => x.BrandMembership)
            .Where(x => x.EmailAddress == email)
            .Where(x => x.InvitationKey == invitationKey)
            .Where(x => x.BrandMembership == null);
    }

    public Func<IQueryable<BrandMembershipInvitation>, IQueryable<BrandMembershipInvitation>> Query { get; }
}
