﻿using System;
using System.ComponentModel.DataAnnotations;

namespace BeTagged.Data.Entities;

public abstract class Otp : BaseEntity
{
    public int OtpId { get; set; }

    [MaxLength(6), Required]
    public string Value { get; set; }

    public DateTime ValidTillUtc { get; set; }

    public int EntityId { get; set; }

    public virtual SystemOtpEntityTypeOption EntityTypeId { get; }

    public SystemOtpUsageTypeOption UsageTypeId { get; set; }

    // Foreign keys
    public SystemOtpEntityType EntityType { get; set; }

    public SystemOtpUsageType UsageType { get; set; }
}

public class PhoneOtp : Otp
{
    public override SystemOtpEntityTypeOption EntityTypeId => SystemOtpEntityTypeOption.Phone;
}

public class EmailOtp : Otp
{
    public override SystemOtpEntityTypeOption EntityTypeId => SystemOtpEntityTypeOption.Email;
}
