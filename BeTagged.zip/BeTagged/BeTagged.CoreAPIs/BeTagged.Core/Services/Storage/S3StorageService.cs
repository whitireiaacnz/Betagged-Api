﻿using System;
using System.IO;
using Amazon;
using Amazon.CloudFront;
using Amazon.S3;
using Amazon.S3.Model;
using BeTagged.Common.Extensions;
using BeTagged.Core.Configurations;
using BeTagged.Core.Dtos;
using BeTagged.Core.Utils;
using Microsoft.Extensions.Options;

namespace BeTagged.Core.Services.Storage;

internal class S3StorageService : IStorageService
{
    private readonly AwsConfiguration _awsConfig;
    private readonly AmazonS3Client _s3Client;
    private readonly string _urlSignerPrivateKey;

    public S3StorageService(IOptions<AwsConfiguration> awsConfig)
    {
        _awsConfig = awsConfig.Value;
        _s3Client = new AmazonS3Client(_awsConfig.AccessKeyId, _awsConfig.AccessKeySecret, RegionEndpoint.APSoutheast1);
        _urlSignerPrivateKey = _awsConfig.S3CloudFrontUrlSignerPrivateKey.ConvertFromBase64();
    }

    public async Task<string> UploadFileAsync(FileUploadDto fileUpload)
    {
        if (fileUpload.Category is null)
        {
            throw new InvalidOperationException(
                "Category is required to upload the files. Please specify the file category.");
        }

        var directory = FileUtils.GetUploadDirectory(fileUpload.Category.Value);
        var fileName = Guid.NewGuid() + Path.GetExtension(fileUpload.FileName);
        var filePath = Path.Combine(directory, fileName);

        var putObjectRequest = new PutObjectRequest
        {
            BucketName = _awsConfig.S3BucketName,
            Key = filePath,
            InputStream = fileUpload.Stream,
            ContentType = fileUpload.ContentType
        };

        _ = await _s3Client.PutObjectAsync(putObjectRequest);

        return GetSignedUrl(filePath, fileUpload.Expiry);
    }

    public string GetUploadSignedUrl(FileUploadSignedUrlDto signedUrlDto)
    {
        if (signedUrlDto.Category is null)
        {
            throw new InvalidOperationException(
                "Category is required to upload the files. Please specify the file category.");
        }

        var directory = FileUtils.GetUploadDirectory(signedUrlDto.Category.Value);
        var fileName = Guid.NewGuid() + Path.GetExtension(signedUrlDto.FileName);
        var filePath = Path.Combine(directory, fileName);

        // https://stackoverflow.com/questions/62338717/url-expiration-clarification-for-uploading-file-through-s3-pre-singed-url
        var signedRequest = new GetPreSignedUrlRequest()
        {
            BucketName = _awsConfig.S3BucketName,
            Key = filePath,
            Verb = HttpVerb.PUT,
            Expires = DateTime.UtcNow.AddMinutes(1),
            ContentType = signedUrlDto.ContentType,
        };

        signedRequest.Headers.ContentLength = signedUrlDto.ContentLength;

        return _s3Client.GetPreSignedURL(signedRequest);
    }

    public async Task DeleteFileAsync(string file)
    {
        var filePath = FileUtils.GetFileAbsolutePath(file);

        var request = new DeleteObjectRequest() { BucketName = _awsConfig.S3BucketName, Key = filePath };

        _ = await _s3Client.DeleteObjectAsync(request);
    }

    public string GetSignedUrl(string file, DateTime? expiry = null)
    {
        if (file.IsNullOrEmpty())
        {
            return file;
        }

        var filePath = FileUtils.GetFileAbsolutePath(file);

        var cfPolicy = AmazonCloudFrontUrlSigner.BuildPolicyForSignedUrl(
            null,
            expiry ?? DateTime.UtcNow.AddMinutes(5),
            null);

        var resourceUri = new Uri(_awsConfig.S3CloudFrontDomain, filePath).ToString();

        using var pkReader = _urlSignerPrivateKey.GetStreamReader();
        return AmazonCloudFrontUrlSigner.SignUrl(
            resourceUri,
            _awsConfig.S3CloudFrontUrlSignerKeyPairId,
            pkReader,
            cfPolicy);
    }
}
