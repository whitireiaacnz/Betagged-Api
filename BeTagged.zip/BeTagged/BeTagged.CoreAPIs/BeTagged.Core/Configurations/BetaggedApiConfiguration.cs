﻿namespace BeTagged.Core.Configurations;

public class BetaggedApiConfiguration
{
    public const string Section = "BetaggedApi";

    public string Address { get; set; }
}
