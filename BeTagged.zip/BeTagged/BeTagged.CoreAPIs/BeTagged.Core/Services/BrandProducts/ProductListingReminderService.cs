﻿using System;
using BeTagged.Core.Configurations;
using BeTagged.Core.Services.BackgroundWork;
using BeTagged.Core.Services.Notification;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;
using Microsoft.Extensions.Options;

namespace BeTagged.Core.Services.BrandProducts;

internal class ProductListingReminderService : IProductListingReminderService
{
    private readonly IBackgroundWorker _backgroundWorker;
    private readonly ScheduledJobsDurationConfiguration _scheduledJobsDurationConfiguration;
    private readonly IReadOnlyRepository<BrandProduct> _brandProductReadRepo;
    private readonly INotificationService _notificationService;

    public ProductListingReminderService(IBackgroundWorker backgroundWorker, IOptions<ScheduledJobsDurationConfiguration> scheduledJobsDurationConfiguration,
        IReadOnlyRepository<BrandProduct> brandProductReadRepo, INotificationService notificationService)
    {
        _backgroundWorker = backgroundWorker;
        _brandProductReadRepo = brandProductReadRepo;
        _notificationService = notificationService;
        _scheduledJobsDurationConfiguration = scheduledJobsDurationConfiguration.Value;
    }

    public void ScheduleProductListingReminderJob(int userId)
    {
        _backgroundWorker.Schedule(() => SendProductListingReminderNotification(userId, _scheduledJobsDurationConfiguration.ProductListingReminder1),
            TimeSpan.FromDays(_scheduledJobsDurationConfiguration.ProductListingReminder1));

        _backgroundWorker.Schedule(() => SendProductListingReminderNotification(userId, _scheduledJobsDurationConfiguration.ProductListingReminder2),
            TimeSpan.FromDays(_scheduledJobsDurationConfiguration.ProductListingReminder2));
    }

    // ReSharper disable once MemberCanBePrivate.Global
    public async Task SendProductListingReminderNotification(int userId, int daysWithoutListingProduct)
    {
        var hasListedAnyProductSpec = new HasUserListedAnyProductSpec(userId);
        var hasListedAProduct = await _brandProductReadRepo.AnyAsync(hasListedAnyProductSpec);

        if (hasListedAProduct)
        {
            return;
        }

        await _notificationService.SendProductListingReminderNotificationAsync(userId, daysWithoutListingProduct);
    }
}
