﻿using BeTagged.Core.Enums;

namespace BeTagged.Core.Configurations;

public class EmailConfiguration
{
    public const string Section = "EmailConfiguration";

    public EmailMode EmailMode { get; set; }
}
