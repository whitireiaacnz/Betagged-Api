﻿using BeTagged.Common.Extensions;
using BeTagged.Core.Commands.Signup;
using BeTagged.Core.Dtos;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Brand;
using BeTagged.Core.Services.Otp;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Users;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Core.Utils;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Services.Signup;

internal class BrandSignupService : IBrandSignupService
{
    private readonly IUserService _userService;
    private readonly IBtDb _db;
    private readonly IBrandMembershipService _brandMembershipService;
    private readonly IAuthTokenService _authTokenService;
    private readonly IEmailOtpService _emailOtpService;
    private readonly IPhoneOtpService _phoneOtpService;
    private readonly IRepository<BrandMembershipInvitation> _brandMembershipInvitationsRepo;
    private readonly IRepository<BrandOrganization> _brandOrganizationsRepo;
    private readonly ICompleteSignupReminderService _completeSignupReminderService;

    public BrandSignupService(IUserService userService, IBtDb db, IBrandMembershipService brandMembershipService,
        IAuthTokenService authTokenService, IEmailOtpService emailOtpService, IPhoneOtpService phoneOtpService,
        IRepository<BrandMembershipInvitation> brandMembershipInvitationsRepo, IRepository<BrandOrganization> brandOrganizationsRepo,
        ICompleteSignupReminderService completeSignupReminderService)
    {
        _userService = userService;
        _db = db;
        _brandMembershipService = brandMembershipService;
        _authTokenService = authTokenService;
        _emailOtpService = emailOtpService;
        _phoneOtpService = phoneOtpService;
        _brandMembershipInvitationsRepo = brandMembershipInvitationsRepo;
        _brandOrganizationsRepo = brandOrganizationsRepo;
        _completeSignupReminderService = completeSignupReminderService;
    }

    public async Task<BrandSignup.Response> SignupBrandAsync(BrandSignup.Command command)
    {
        var response = new BrandSignup.Response();

        var emailDomain = EmailUtil.GetDomain(command.Email.Trim().ToLower());

        if (BlacklistedEmailDomains.BlacklistEmailDomains.Contains(emailDomain))
        {
            response.ErrorMessage = ValidationMessages.BlacklistedEmailMessage;
            response.Error = ErrorType.ValidationError;
            return response;
        }

        BrandMembershipInvitation invitation = null;

        if (command.InvitationKey.IsNotNullOrEmpty())
        {
            var unusedInvitationSpec = new GetUnusedBrandMembershipInvitationSpec(command.Email, command.InvitationKey);
            invitation = await _brandMembershipInvitationsRepo.SingleOrDefaultAsync(unusedInvitationSpec);
        }

        var userCreationResult = await _userService.CreateUserAsync(new CreateUserDto()
        {
            Email = command.Email,
            Password = command.Password,
            CountryCode = command.CountryCode,
            Phone = command.Phone,
            UserType = SystemUserTypeOption.BrandMember
        });

        if (!userCreationResult.IsSuccess)
        {
            response.ErrorMessage = userCreationResult.ErrorMessage;
            response.Error = userCreationResult.Error;
            return response;
        }

        var user = userCreationResult.Data;
        var email = user.EmailAddresses.First();
        var phone = user.Phones.First();

        var brandMember = new BrandMember() { User = user };
        _db.BrandMembers.Add(brandMember);

        BrandOrganization brandOrganization;
        SystemRoleOption brandMembershipRole;

        if (invitation is null)
        {
            brandOrganization = new BrandOrganization()
            {
                OnBoardedByMember = brandMember,
                EmailDomain = emailDomain
            };

            _db.BrandOrganizations.Add(brandOrganization);
            brandMembershipRole = SystemRoleOption.Administrator;
        }
        else
        {
            brandOrganization =
                await _brandOrganizationsRepo.SingleAsync(
                    new GetBrandOrganizationWithCategoriesSpec(invitation.BrandOrganizationId));

            brandMembershipRole = invitation.RoleId;
        }

        await _db.SaveChangesAsync();

        // signed up organization will be the primary organization of the signing member
        brandMember.PrimaryBrandOrganization = brandOrganization;

        var brandMembership = await _brandMembershipService.AddBrandMembershipAsync(
            brandMember.BrandMemberId,
            brandOrganization.BrandOrganizationId,
            invitation?.InvitedByBrandMemberId ?? brandMember.BrandMemberId,
            brandMembershipRole,
            invitation);

        await _db.SaveChangesAsync();

        await _emailOtpService.GenerateAndSendEmailOtpAsync(email, SystemOtpUsageTypeOption.Verification);
        await _phoneOtpService.GenerateAndSendPhoneOtpAsync(phone, SystemOtpUsageTypeOption.Verification);

        _completeSignupReminderService.ScheduleCompleterSignupReminderJob(brandMember.UserId);

        response.AccessToken = _authTokenService.GetTokenForBrandMember(brandMember, brandMembership);
        response.BrandMemberInfo = new BrandMemberAuthenticationInfo()
        {
            UserKey = user.UserKey,
            IsUserOnBoarded = user.Name.IsNotNullOrEmpty(),
            IsBrandOnBoarded = brandOrganization.IsOnboarded(),
            PrimaryEmailAddressId = email.EmailAddressId,
            PrimaryEmailAddress = email.EmailAddress_,
            IsEmailVerified = email.IsVerified,
            PrimaryPhoneId = phone.PhoneId,
            PrimaryPhone = phone.ToString(),
            IsPhoneVerified = phone.IsVerified,
            FullName = user.Name
        };

        return response;
    }
}
