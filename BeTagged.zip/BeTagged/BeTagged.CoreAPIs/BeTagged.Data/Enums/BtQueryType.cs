﻿namespace BeTagged.Data.Enums;

public enum BtQueryType
{
    GetBrandProducts,
    GetInfluencerProducts,
    GetInfluencerPlatformInsightsData,
    InsertDiscountCode,
    GetBrandProductInsight,
    GetBrandOrganizationBusinessInsightsSummary,
    GetBrandPlatformInsights,
    GetBrandDashboardInsights,
    GetInfluencerDashboardInsights,
    GetInfluencerLeaderboardInsights,
    GetInfluencerPromotedProducts,
    GetBrandMembers,
    UpdateShortenedLinkClickCount,
    GetSalesAndClicksForBrandBusinessInsights,
    GetSalesAndClicksForInfluencerBusinessInsights
}
