﻿namespace BeTagged.Core.Constants;

public static class ContentTypes
{
    public const string ApplicationJson = "application/json";

    public const string ProblemJson = "application/problem+json";
}
