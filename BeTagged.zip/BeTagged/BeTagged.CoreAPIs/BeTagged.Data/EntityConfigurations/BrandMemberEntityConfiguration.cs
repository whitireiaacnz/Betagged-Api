﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

internal class BrandMemberEntityConfiguration : IEntityTypeConfiguration<BrandMember>
{
    public void Configure(EntityTypeBuilder<BrandMember> builder)
    {
        builder.HasKey(x => x.BrandMemberId);

        builder.Property(x => x.BrandMemberId)
            .UseIdentityAlwaysColumn();

        builder.HasOne(x => x.User)
            .WithOne().HasForeignKey<BrandMember>(f => f.UserId);

        builder.HasOne(x => x.PrimaryBrandOrganization)
            .WithMany()
            .HasForeignKey(x => x.PrimaryBrandOrganizationId);
    }
}
