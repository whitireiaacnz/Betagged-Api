﻿using BeTagged.Data.Models;

namespace BeTagged.Core.Queries.Shared;

public class InclusiveIntRange : InclusiveRangeField<int>
{
}

public class InclusiveIntRangeValidator : AbstractValidator<InclusiveIntRange>
{
    public InclusiveIntRangeValidator()
    {
        RuleFor(x => x.From).LessThan(x => x.To)
            .When(x => x.To is not null);
    }
}

public class InclusivePercentageValidator : AbstractValidator<InclusiveIntRange>
{
    public InclusivePercentageValidator()
    {
        Include(new InclusiveIntRangeValidator());
        RuleFor(x => x.From).GreaterThanOrEqualTo(0).LessThanOrEqualTo(100);
        RuleFor(x => x.To).GreaterThanOrEqualTo(0).LessThanOrEqualTo(100);
    }
}
