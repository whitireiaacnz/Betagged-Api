﻿using System;
using System.Security.Claims;

namespace BeTagged.Core.Services.Security;

public interface ITokenService
{
    string GenerateToken(string secretKey, IEnumerable<Claim> claims, string issuer = "", string audience = "", DateTime? expiresAtUtc = null);

    (bool IsValida, IEnumerable<Claim> Claims) ValidateAndParseToken(string token, string secretKey, string issuer = "", string audience = "",
        bool validateExpiry = true);
}
