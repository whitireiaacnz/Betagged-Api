﻿namespace BeTagged.Core.Models;

public class BrandOrganizationInfo : Result
{
    public int BrandId { get; set; }

    public string LegalName { get; set; }

    public SystemRoleOption Role { get; set; }

    public IEnumerable<LookupItem> Categories { get; set; }
}
