﻿using BeTagged.Core.Dtos;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Services.ProductSales;

public class ProductSalesService : IProductSalesService
{
    private readonly IRepository<ProductSale> _productSalesRepository;
    private readonly IBtDb _db;

    public ProductSalesService(IRepository<ProductSale> productSalesRepository, IBtDb db)
    {
        _productSalesRepository = productSalesRepository;
        _db = db;
    }

    public async Task AddProductSaleAsync(AddProductSaleDto productSaleDto)
    {
        var sale = new ProductSale()
        {
            ProductPromotionId = productSaleDto.ProductPromotionId,
            BrandProductId = productSaleDto.BrandProductId,
            InfluencerId = productSaleDto.InfluencerId,
            BrandOrganizationId = productSaleDto.BrandOrganizationId,
            SalesChannelId = productSaleDto.SalesChannelId,
            IsCommissionPaidOff = productSaleDto.IsCommissionPaidOff,
            SoldAtUtc = productSaleDto.SoldAtUtc,
            Quantity = productSaleDto.Quantity,
            ImportedThroughSaleDataFileId = productSaleDto.SalesDataFileId
        };

        sale.SetSalesInfo(productSaleDto.Price, productSaleDto.Quantity, productSaleDto.CommissionPercentage, productSaleDto.InfluencerCommissionPercentage, productSaleDto.SalesSourceId);
        await _productSalesRepository.AddAsync(sale);
        await _db.SaveChangesAsync();
    }
}
