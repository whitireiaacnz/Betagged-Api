﻿using System.Threading;
using BeTagged.Core.Services.Otp;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Commands.User;

public static class VerifyPhone
{
    public record Command(int PhoneId, string Otp) : IRequest<Response>;

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.PhoneId).GreaterThan(0);
            RuleFor(x => x.Otp).NotEmpty();
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly ICurrentUser _currentUser;
        private readonly IPhoneOtpService _phoneOtpService;

        public Handler(ICurrentUser currentUser, IPhoneOtpService phoneOtpService)
        {
            _currentUser = currentUser;
            _phoneOtpService = phoneOtpService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var verificationResult = await _phoneOtpService.VerifyPhoneAsync(
                _currentUser.UserId,
                request.PhoneId,
                request.Otp,
                SystemOtpUsageTypeOption.Verification);

            return new Response { ErrorMessage = verificationResult.ErrorMessage, Error = verificationResult.Error };
        }
    }

    public class Response : Result
    {
    }
}
