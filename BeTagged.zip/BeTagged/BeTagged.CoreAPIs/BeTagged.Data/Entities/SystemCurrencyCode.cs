﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Entities;

[Table("system_currency_codes_lut")]
public class SystemCurrencyCode
{
    public SystemCurrencyCodeOption SystemCurrencyCodeId { get; set; }

    public string Name { get; set; }

    [MaxLength(16)]
    public string Symbol { get; set; }
}
