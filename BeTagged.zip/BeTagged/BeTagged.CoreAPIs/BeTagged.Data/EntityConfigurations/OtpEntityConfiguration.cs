﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

internal class OtpEntityConfiguration : IEntityTypeConfiguration<Otp>
{
    public void Configure(EntityTypeBuilder<Otp> builder)
    {
        builder.ToTable("otps");

        builder.Property(x => x.OtpId).UseIdentityAlwaysColumn();

        builder.HasDiscriminator(x => x.EntityTypeId)
            .HasValue<PhoneOtp>(SystemOtpEntityTypeOption.Phone)
            .HasValue<EmailOtp>(SystemOtpEntityTypeOption.Email);

        builder.HasOne(x => x.EntityType)
            .WithMany(x => x.Otps)
            .HasForeignKey(x => x.EntityTypeId);

        builder.HasOne(x => x.UsageType)
            .WithMany(x => x.Otps)
            .HasForeignKey(x => x.UsageTypeId).IsRequired();
    }
}
