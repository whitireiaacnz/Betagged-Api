﻿using System;

namespace BeTagged.Data.Entities;

public abstract class BaseEntity
{
    public virtual DateTime CreatedAtUtc { get; set; }

    public virtual DateTime ModifiedAtUtc { get; set; }

    public virtual bool IsDeleted { get; set; }
}
