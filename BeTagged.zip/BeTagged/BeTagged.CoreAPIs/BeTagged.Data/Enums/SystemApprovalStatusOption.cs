﻿namespace BeTagged.Data.Enums;

[EnumLookupTable(typeof(SystemApprovalStatus))]
public enum SystemApprovalStatusOption : byte
{
    Pending = 1,
    Approved = 2,
    Rejected = 3
}
