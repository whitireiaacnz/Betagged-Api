﻿using System;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetPromotionByKeySpec : ISingleResultQuerySpecification<ProductPromotion, ProductPromotion>
{
    public GetPromotionByKeySpec(string key)
    {
        Query = queryable => queryable
        .Include(x => x.BrandProduct)
           .Where(x => x.ProductPromotionKey == Guid.Parse(key));
    }

    public Func<IQueryable<ProductPromotion>, IQueryable<ProductPromotion>> Query { get; }
}
