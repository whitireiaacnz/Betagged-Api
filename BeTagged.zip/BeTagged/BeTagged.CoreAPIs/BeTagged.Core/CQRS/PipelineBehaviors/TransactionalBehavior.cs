﻿using System.Threading;

namespace BeTagged.Core.CQRS.PipelineBehaviors;

internal class TransactionalBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse> where TRequest : ITransactionalRequest<TResponse>
    where TResponse : Result
{
    private readonly IBtDb _db;

    public TransactionalBehavior(IBtDb db) => _db = db;

    public async Task<TResponse> Handle(TRequest request, CancellationToken cancellationToken, RequestHandlerDelegate<TResponse> next)
        => await _db.ExecuteInTransactionAsync(async () => await next(), IsTransactionCommittable);

    private static bool IsTransactionCommittable(Result result) => result.IsSuccess;
}
