﻿using System;
using System.Threading;
using BeTagged.Common.Extensions;
using BeTagged.Core.Services.BrandProducts;
using BeTagged.Core.Utils;

namespace BeTagged.Core.Commands.Product;

public static class UploadBrandProductSalesData
{
    public class Command : IRequest<Response>
    {
        public int BrandProductId { get; set; }

        public string SalesDataFileUrl { get; set; }
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.SalesDataFileUrl)
                .NotEmpty()
                .Must(x => x.IsUri())
                .WithMessage(ValidationMessages.LinkMustBeValidUri)
                .Must(PropertyValidationUtil.IsExcelFile)
                .WithMessage(ValidationMessages.SalesDataFileMustBeExcelFile);
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IBrandProductService _brandProductService;

        public Handler(IBrandProductService brandProductService)
        {
            _brandProductService = brandProductService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var uploadResult =
                await _brandProductService.UploadSalesData(request.BrandProductId, request.SalesDataFileUrl);

            var number = BrandProductService.TwoNumbers();

            var response = ((Result)uploadResult).Map<Response>();
            response.Data = uploadResult.Data?.Data;
            response.SalesDataLastUploadedAtUtc = uploadResult.Data?.SalesDataLastUploadedAtUtc;

            return response;
        }
    }

    public class Response : Result
    {
        public string Data { get; set; }

        public string Message => Data;

        public DateTime? SalesDataLastUploadedAtUtc { get; set; }
    }
}
