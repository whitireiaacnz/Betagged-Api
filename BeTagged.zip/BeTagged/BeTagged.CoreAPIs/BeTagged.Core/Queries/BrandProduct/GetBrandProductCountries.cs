﻿using System.Threading;
using BeTagged.Core.Services.BrandProducts;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Queries.BrandProduct;

public static class GetBrandProductCountries
{
    public record Query() : IRequest<IEnumerable<LookupItem>>;

    public class Handler : IRequestHandler<Query, IEnumerable<LookupItem>>
    {
        private readonly IBrandProductService _brandProductService;
        private readonly ICurrentBrandMember _currentBrandMember;

        public Handler(IBrandProductService brandProductService, ICurrentBrandMember currentBrandMember)
        {
            _brandProductService = brandProductService;
            _currentBrandMember = currentBrandMember;
        }

        public async Task<IEnumerable<LookupItem>> Handle(Query request, CancellationToken cancellationToken)
        {
            return await _brandProductService.GetBrandProductCountries(_currentBrandMember.BrandOrganizationId, cancellationToken);
        }
    }
}
