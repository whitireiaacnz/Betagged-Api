﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Entities;

[Table("system_otp_usage_types_lut")]
public class SystemOtpUsageType
{
    public SystemOtpUsageType() => Otps = new List<Otp>();

    public SystemOtpUsageTypeOption SystemOtpUsageTypeId { get; set; }

    [MaxLength(32)]
    public string Name { get; set; }

    // Reverse navigation
    public ICollection<Otp> Otps { get; }
}
