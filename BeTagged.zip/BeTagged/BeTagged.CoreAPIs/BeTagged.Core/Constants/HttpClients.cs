﻿namespace BeTagged.Core.Constants;
public static class HttpClients
{
    public const string GeoDbCitiesApi = "GeoDbCitiesApi";

    public const string BtUrlShortener = "BtUrlShortener";

    public const string Clevertap = "Clevertap";

    public const string Shopify = "Shopify";
}
