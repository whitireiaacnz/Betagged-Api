﻿using BeTagged.Core.Dtos;

namespace BeTagged.Core.Services.Communication;

public interface IEmailTransportService
{
    Task SendEmailAsync(SendEmailDto sendEmailConfig);
}
