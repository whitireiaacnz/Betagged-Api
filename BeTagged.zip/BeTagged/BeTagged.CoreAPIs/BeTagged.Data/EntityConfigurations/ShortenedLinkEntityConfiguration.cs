﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

public class ShortenedLinkEntityConfiguration : IEntityTypeConfiguration<ShortenedLink>
{
    public void Configure(EntityTypeBuilder<ShortenedLink> builder)
    {
        builder.ToTable("shortened_links");

        builder.HasKey(x => x.ShortenedLinkId);

        builder.Property(x => x.ShortenedLinkId)
            .UseIdentityAlwaysColumn();

        builder.Property(x => x.Url).HasMaxLength(128);

        builder.HasDiscriminator(x => x.EntityTypeId)
            .HasValue<ProductPromotionLink>(SystemShortenedLinkEntityTypeOption.ProductPromotion);

        builder.HasOne(x => x.EntityType)
            .WithMany(x => x.ShortenedLinks)
            .HasForeignKey(x => x.EntityTypeId);
    }
}
