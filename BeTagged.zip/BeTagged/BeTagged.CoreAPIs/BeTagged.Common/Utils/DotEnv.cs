﻿namespace BeTagged.Common.Utils;

public static class DotEnv
{
    public static void Load(string basePath, string fileName = ".env", string env = null)
    {
        AddEnvironmentVariablesFromFile(Path.Combine(basePath, fileName));
        AddEnvironmentVariablesFromFile(Path.Combine(basePath, $"{fileName}.{env}"));
    }

    private static void AddEnvironmentVariablesFromFile(string filePath)
    {
        if (!File.Exists(filePath)) { return; }

        foreach (var line in File.ReadAllLines(filePath))
        {
            var parts = line.Split('=', 2, StringSplitOptions.RemoveEmptyEntries);

            if (parts.Length != 2) { continue; }

            Environment.SetEnvironmentVariable(parts[0], parts[1]);
        }
    }
}
