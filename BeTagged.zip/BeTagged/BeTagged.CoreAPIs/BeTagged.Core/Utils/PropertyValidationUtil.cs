﻿using System;
using Microsoft.IdentityModel.Tokens;

namespace BeTagged.Core.Utils;

public static class PropertyValidationUtil
{
    public const string OnlyAlphabetRegex = @"^[a-zA-Z\s]+$";

    public const string AlphNumericRegex = @"^[a-zA-Z0-9]+$";

    public const string PasswordRegex = @"^((?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*\W).{8,})$";

    public static readonly string[] ImageExtension = { ".png", ".jpeg", ".jpg" };

    public static bool IsBrandPathValid(string link)
    {
        var fileName = new Uri(link).AbsolutePath;
        int idx = fileName.LastIndexOf('/');
        if (idx >= 0)
        {
            fileName = fileName.Substring(0, idx);
        }

        return fileName == "/brand";
    }

    public static bool IsZipFileUrl(string link)
    {
        return FileUtils.GetFileExtension(link) == ".zip";
    }

    public static bool IsExcelFile(string link)
    {
        return FileUtils.GetFileExtension(link) == ".xlsx";
    }

    public static bool IsImageFile(string link)
    {
        var extension = FileUtils.GetFileExtension(link);
        return ImageExtension.Contains(extension.ToLower());
    }

    public static bool IsCityValid(string city)
    {
        if (city.IsNullOrEmpty())
        {
            return false;
        }

        string[] subCity = city.Split(',');

        return subCity.Length >= 2;
    }
}
