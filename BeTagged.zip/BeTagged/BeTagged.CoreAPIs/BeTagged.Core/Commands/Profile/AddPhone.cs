﻿using System.Threading;
using BeTagged.Core.Dtos;
using BeTagged.Core.Services.Users;

namespace BeTagged.Core.Commands.Profile;

public static class AddPhone
{
    public class Command : IRequest<Response>
    {
        public string CountryCode { get; set; }

        public string Phone { get; set; }
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.CountryCode).NotEmpty();
            RuleFor(x => x.Phone).NotEmpty();
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IUserService _userService;

        public Handler(IUserService userService)
        {
            _userService = userService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var phoneResponse = await _userService.AddUnverifiedPhoneAsync(request.CountryCode,
                request.Phone);

            return phoneResponse.Map<Response>();
        }
    }

    public class Response : Result<UserPhoneDto>
    {
    }
}
