﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Entities;

[Table("system_invitation_statuses_lut")]
public class SystemInvitationStatus
{
    public SystemInvitationStatus()
    {
        BrandMembershipInvitations = new List<BrandMembershipInvitation>();
    }

    public SystemInvitationStatusOptions SystemInvitationStatusId { get; set; }

    [MaxLength(32)]
    public string Name { get; set; }

    // Reverse navigation
    public ICollection<BrandMembershipInvitation> BrandMembershipInvitations { get; set; }
}
