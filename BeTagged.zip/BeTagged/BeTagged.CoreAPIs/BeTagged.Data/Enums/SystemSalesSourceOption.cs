﻿namespace BeTagged.Data.Enums;

[EnumLookupTable(typeof(SystemSalesSource))]
public enum SystemSalesSourceOption : byte
{
    SalesDataImport = 1,
    Incomm = 2
}
