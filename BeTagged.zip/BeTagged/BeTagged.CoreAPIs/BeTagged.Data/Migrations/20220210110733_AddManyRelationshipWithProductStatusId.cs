﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class AddManyRelationshipWithProductStatusId : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropIndex(
            name: "ix_brand_products_product_status_id",
            schema: "public",
            table: "brand_products");

        migrationBuilder.CreateIndex(
            name: "ix_brand_products_product_status_id",
            schema: "public",
            table: "brand_products",
            column: "product_status_id");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropIndex(
            name: "ix_brand_products_product_status_id",
            schema: "public",
            table: "brand_products");

        migrationBuilder.CreateIndex(
            name: "ix_brand_products_product_status_id",
            schema: "public",
            table: "brand_products",
            column: "product_status_id",
            unique: true);
    }
}
