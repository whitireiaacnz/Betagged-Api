﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

public class InAppNotificationEntityConfiguration : IEntityTypeConfiguration<InAppNotification>
{
    public void Configure(EntityTypeBuilder<InAppNotification> builder)
    {
        builder.HasKey(x => x.UserNotificationId);

        builder.Property(x => x.UserNotificationId)
            .UseIdentityAlwaysColumn();

        builder.HasOne(x => x.User)
            .WithMany(x => x.Notifications)
            .HasForeignKey(x => x.UserId);

        builder.HasOne(x => x.SystemInAppNotificationType)
            .WithMany(x => x.InAppNotifications)
            .HasForeignKey(x => x.SystemInAppNotificationTypeId);
    }
}
