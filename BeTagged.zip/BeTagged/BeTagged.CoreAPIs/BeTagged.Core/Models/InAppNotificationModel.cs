﻿using System;
using BeTagged.Common.Utils;
using Newtonsoft.Json;

namespace BeTagged.Core.Models;

public class InAppNotificationModel : Result
{
    public int NotificationId { get; set; }

    public string Title { get; set; }

    public string Content { get; set; }

    public SystemInAppNotificationTypeOption NotificationType { get; set; }

    [JsonIgnore]
    public string ArgumentsString { get; set; }

    public Dictionary<string, object> Arguments => ArgumentsString.Deserialize<Dictionary<string, object>>();

    public bool HasReadByUser { get; set; }

    public DateTime CreatedAtUtc { get; set; }
}
