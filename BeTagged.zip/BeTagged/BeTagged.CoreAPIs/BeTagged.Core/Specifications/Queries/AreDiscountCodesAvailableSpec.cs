﻿using System;
using System.Threading;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

internal class AreDiscountCodesAvailableSpec : IAnyQuerySpecification<BrandProductDiscountCode>
{
    public AreDiscountCodesAvailableSpec(int brandProductId)
    {
        Query = async (q, ct) =>
           await q.AnyAsync(x => x.BrandProductId == brandProductId && x.ProductPromotion == null,
               ct);
    }

    public Func<IQueryable<BrandProductDiscountCode>, CancellationToken, Task<bool>> Query { get; }
}
