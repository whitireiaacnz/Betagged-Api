﻿using System.ComponentModel.DataAnnotations;
using BeTagged.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(PhoneEntityConfiguration))]
public class Phone : BaseEntity
{
    public int PhoneId { get; set; }

    [MaxLength(16)]
    public string PhoneNumber { get; set; }

    [MaxLength(4)]
    public string CountryCode { get; set; }

    public bool IsVerified { get; set; }

    public bool IsPrimary { get; set; }

    public int? UserId { get; set; }

    // Foreign keys
    public User User { get; set; }

    public override string ToString() => $"{CountryCode}-{PhoneNumber}";
}
