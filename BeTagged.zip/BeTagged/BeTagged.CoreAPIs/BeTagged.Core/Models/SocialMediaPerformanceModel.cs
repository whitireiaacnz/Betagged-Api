﻿namespace BeTagged.Core.Models;

public class SocialMediaPerformanceModel
{
    public MediaPlatformPerformance Instagram { get; set; }

    public MediaPlatformPerformance Twitter { get; set; }

    public MediaPlatformPerformance TikTok { get; set; }

    public MediaPlatformPerformance Facebook { get; set; }

    public class MediaPlatformPerformance
    {
        public int Sales { get; set; }

        public int Clicks { get; set; }
    }
}
