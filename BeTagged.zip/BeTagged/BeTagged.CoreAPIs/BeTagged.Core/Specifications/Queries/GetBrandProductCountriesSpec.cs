﻿using System;
using System.Threading;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetBrandProductCountriesSpec : IListResultQuerySpecification<BrandProduct, LookupItem>
{
    public GetBrandProductCountriesSpec(int brandOrganizationId)
    {
        Query = async (queryable, ct) => await queryable
            .Where(x => x.BrandOrganizationId == brandOrganizationId)
            .GroupBy(x => x.CountryId)
            .Select(x => new LookupItem(x.First().Country.SystemCountryId, x.First().Country.Name))
            .ToListAsync(ct);
    }

    public Func<IQueryable<BrandProduct>, CancellationToken, Task<IList<LookupItem>>> Query { get; }
}
