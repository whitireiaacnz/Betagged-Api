﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using BeTagged.Data.Constants;
using BeTagged.Data.EntityConfigurations;
using BeTagged.Data.Utils;
using Microsoft.EntityFrameworkCore;
using NetTopologySuite.Geometries;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(BrandProductEntityConfiguration))]
public class BrandProduct : BaseEntity, IUserEntity, IBrandEntity
{
    public BrandProduct()
    {
        ProductPromotionRequests = new List<ProductPromotionRequest>();
        ProductPromotions = new List<ProductPromotion>();
        ShowCaseMediaUrls = new List<string>();
        Categories = new List<SystemCategory>();
        SocialMediaKits = new();
        ProductSales = new List<ProductSale>();
        DiscountCodesFiles = new List<BrandProductDiscountCodesFile>();
        DiscountCodes = new List<BrandProductDiscountCode>();
        BrandProductsSaleDataFiles = new List<BrandProductsSalesDataFile>();
        ProductIncommDetails = new();
    }

    public int BrandProductId { get; set; }

    public long? ShopifyProductId { get; set; }

    public Guid BrandProductKey { get; set; }

    [MaxLength(128)]
    public string Name { get; set; }

    [MaxLength(64)]
    public string ProductCode { get; set; }

    [MaxLength(1024)]
    public string Description { get; set; }

    [CurrencyColumn]
    public decimal Price { get; set; }

    public int CommissionPercentage { get; set; }

    public int BrandPlatformCommissionPercentage { get; private set; }

    [PercentageColumn]
    public decimal PlatformCommissionPercentage { get; private set; }

    [PercentageColumn]
    public decimal InfluencerCommissionPercentage { get; private set; }

    public int BuyerDiscountPercentage { get; set; }

    public bool IsApprovalBasedOffer { get; set; }

    [MaxLength(DbConstants.UrlFieldLength)]
    public string BannerImageUrl { get; set; }

    public List<string> ShowCaseMediaUrls { get; set; }

    [JsonbColumn]
    public ProductSocialMediaKit SocialMediaKits { get; set; }

    [JsonbColumn]
    public ProductIncommDetail ProductIncommDetails { get; set; }

    public string ProductUrl { get; set; }

    public SystemProductUrlOption ProductUrlTypeId { get; set; }

    public DateTime? ListedOnUtc { get; set; }

    public DateTime? UnlistedAtUtc { get; set; }

    public int BrandOrganizationId { get; set; }

    public SystemProductStatusOption ProductStatusId { get; set; }

    [MaxLength(1024)]
    public string Hashtags { get; set; }

    public int CreatedByUserId { get; set; }

    public int ModifiedByUserId { get; set; }

    public byte CountryId { get; set; }

    [MaxLength(128)]
    public string City { get; set; }

    [GeometryPoint]
    public Point Location { get; set; }

    public DateTime? SalesDataLastUploadedAtUtc { get; set; }

    public int? LastDiscountCodeExhaustionNotificationPercentage { get; set; }

    [NotMapped]
    public DateTime? SalesAllowedTillUtc => UnlistedAtUtc?.AddDays(5);

    // Foreign Keys
    public BrandOrganization BrandOrganization { get; set; }

    public SystemProductStatus ProductStatus { get; set; }

    public SystemProductUrlType ProductUrlType { get; set; }

    public User CreatedByUser { get; set; }

    public User ModifiedByUser { get; set; }

    public SystemCountry Country { get; set; }

    public ICollection<SystemCategory> Categories { get; set; }

    // Reverse Navigation
    public ICollection<ProductPromotion> ProductPromotions { get; set; }

    public ICollection<ProductPromotionRequest> ProductPromotionRequests { get; set; }

    public ICollection<ProductSale> ProductSales { get; set; }

    public ICollection<BrandProductDiscountCodesFile> DiscountCodesFiles { get; set; }

    public ICollection<BrandProductDiscountCode> DiscountCodes { get; set; }

    public ICollection<BrandProductsSalesDataFile> BrandProductsSaleDataFiles { get; set; }

    public static (decimal PlatformCommissionPercentage, decimal InfluencerCommissionPercentage)
        GetCommissionPercentageDistribution(int brandPlatformCommissionPercentage, int commissionPercentage)
    {
        var platformCommissionPercentage = (decimal)(commissionPercentage * brandPlatformCommissionPercentage) / 100;
        var influencerCommissionPercentage = commissionPercentage - platformCommissionPercentage;
        return (platformCommissionPercentage, influencerCommissionPercentage);
    }

    public void SetLocation(double longitude, double latitude)
    {
        Location = SpatialUtils.GetGeometricPoint(longitude, latitude);
    }

    public void SetCommissionPercentage(int brandPlatformCommissionPercentage, int commissionPercentage)
    {
        CommissionPercentage = commissionPercentage;
        BrandPlatformCommissionPercentage = brandPlatformCommissionPercentage;
        (PlatformCommissionPercentage, InfluencerCommissionPercentage) = GetCommissionPercentageDistribution(
            brandPlatformCommissionPercentage,
            commissionPercentage);
    }

    public void Unlist()
    {
        ProductStatusId = SystemProductStatusOption.Unlisted;
        ListedOnUtc = null;
        UnlistedAtUtc = DateTime.UtcNow;
    }
}
