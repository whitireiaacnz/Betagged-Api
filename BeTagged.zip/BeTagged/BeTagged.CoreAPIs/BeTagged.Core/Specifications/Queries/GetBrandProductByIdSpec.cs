﻿using System;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetBrandProductByIdSpec : ISingleResultQuerySpecification<BrandProduct, BrandProduct>
{
    public GetBrandProductByIdSpec(int brandOrganizationId, int brandProductId)
    {
        Query = queryable => queryable
            .Include(x => x.Categories)
            .Include(x => x.Country)
            .Where(x => x.BrandProductId == brandProductId)
            .Where(x => x.BrandOrganizationId == brandOrganizationId);
    }

    public Func<IQueryable<BrandProduct>, IQueryable<BrandProduct>> Query { get; }
}
