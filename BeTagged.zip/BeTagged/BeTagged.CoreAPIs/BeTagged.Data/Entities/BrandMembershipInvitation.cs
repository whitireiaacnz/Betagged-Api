﻿using System.ComponentModel.DataAnnotations;
using BeTagged.Data.Constants;
using BeTagged.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(BrandMembershipInvitationEntityConfiguration))]
public class BrandMembershipInvitation : BaseEntity, IBrandEntity
{
    public int BrandMembershipInvitationId { get; set; }

    [MaxLength(DbConstants.EmailAddressFieldLength), Required]
    public string EmailAddress { get; set; }

    [MaxLength(DbConstants.EmailAddressFieldLength), Required]
    public string NormalizedEmailAddress { get; set; }

    public int InvitedByBrandMemberId { get; set; }

    public int BrandOrganizationId { get; set; }

    public SystemRoleOption RoleId { get; set; }

    [MaxLength(64), Required]
    public string InvitationKey { get; set; }

    public SystemInvitationStatusOptions InvitationStatusId { get; set; }

    // Foreign keys
    public BrandMember InvitedByBrandMember { get; set; }

    public BrandOrganization BrandOrganization { get; set; }

    public SystemRole Role { get; set; }

    public SystemInvitationStatus InvitationStatus { get; set; }

    // Reverse navigation
    public BrandMembership BrandMembership { get; set; }
}
