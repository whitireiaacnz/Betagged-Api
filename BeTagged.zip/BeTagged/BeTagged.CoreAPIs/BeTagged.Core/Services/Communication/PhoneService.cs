﻿namespace BeTagged.Core.Services.Communication;

internal class PhoneService : IPhoneService
{
    private readonly IPhoneTransportService _phoneTransportService;

    public PhoneService(IPhoneTransportService phoneTransportService)
    {
        _phoneTransportService = phoneTransportService;
    }

    public async Task SendOtpText(string phoneNumber, string otp)
    {
        await _phoneTransportService.SendTextAsync(phoneNumber, string.Format(PhoneConstants.OtpSmsTemplate, otp));
    }
}
