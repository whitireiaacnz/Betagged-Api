﻿using System;
using System.Threading;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetPromotionRequestsByProductIdSpec : IListResultQuerySpecification<ProductPromotionRequest, ProductPromotionRequest>
{
    public GetPromotionRequestsByProductIdSpec(int brandProductId, int brandOrganizationId)
    {
        Query = async (queryable, ct) => await queryable
           .Where(x => x.BrandProductId == brandProductId)
           .Where(x => x.BrandOrganizationId == brandOrganizationId)
           .ToListAsync(ct);
    }

    public Func<IQueryable<ProductPromotionRequest>, CancellationToken, Task<IList<ProductPromotionRequest>>> Query { get; }
}
