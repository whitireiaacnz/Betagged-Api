﻿using System.Threading;
using BeTagged.Core.Dtos;
using BeTagged.Core.Queries.Shared;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Storage;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Queries;

public class GetProductLeaderBoardInfluencers
{
    public class ODataQuery : ODataQueryBase, IRequest<PaginatedList<InfluencerLeaderboardDto>>
    {
    }

    public class Query : ODataQuery
    {
        public int BrandProductId { get; set; }
    }

    public class Handler : IRequestHandler<Query, PaginatedList<InfluencerLeaderboardDto>>
    {
        private readonly IReadOnlyRepository<Data.Entities.ProductPromotion> _productPromotionsRepo;
        private readonly ICurrentInfluencer _currentInfluencer;
        private readonly IStorageService _storageService;

        public Handler(IReadOnlyRepository<Data.Entities.ProductPromotion> productPromotionsRepo,
            ICurrentInfluencer currentInfluencer, IStorageService storageService)
        {
            _productPromotionsRepo = productPromotionsRepo;
            _currentInfluencer = currentInfluencer;
            _storageService = storageService;
        }

        public async Task<PaginatedList<InfluencerLeaderboardDto>> Handle(Query request, CancellationToken cancellationToken)
        {
            var influencersByLeaderboardSpec = new GetInfluencerListByLeaderboardSpec(request.BrandProductId,
                request.Skip, request.Take,
                _currentInfluencer.InfluencerId);

            var influencers = await _productPromotionsRepo
                .ListAsync(influencersByLeaderboardSpec, cancellationToken);

            foreach (var influencer in influencers)
            {
                influencer.InfluencerProfilePicUrl = _storageService.GetSignedUrl(influencer.InfluencerProfilePicUrl);
            }

            return new PaginatedList<InfluencerLeaderboardDto>(influencers, request.Skip, request.Take);
        }
    }
}
