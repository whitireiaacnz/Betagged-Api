﻿using System;
using BeTagged.Core.Utils;
using BeTagged.Data.Specifications;

namespace BeTagged.Core.Specifications.Queries;

public class GetPhoneSpec : ISingleResultQuerySpecification<Phone, Phone>
{
    public GetPhoneSpec(string countryCode, string phoneNo)
    {
        var (parsedCountryCode, parsedPhone) = PhoneUtil.ParsePhone(countryCode, phoneNo);

        Query = queryable => queryable
        .Where(x => x.CountryCode == parsedCountryCode && x.PhoneNumber == parsedPhone);
    }

    public GetPhoneSpec(int phoneId, int userId)
    {
        Query = queryable => queryable
       .Where(x => x.PhoneId == phoneId && x.UserId == userId);
    }

    public Func<IQueryable<Phone>, IQueryable<Phone>> Query { get; }
}
