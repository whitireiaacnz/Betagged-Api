﻿namespace BeTagged.Core.Services;

public interface IInfluencerProductPromotionReminderService
{
    public void ScheduleJobToRemindInfluencerToPickProduct(int influencerId);
}
