﻿namespace BeTagged.Core.Services.Otp;

public interface IEmailOtpService
{
    Task GenerateAndSendEmailOtpAsync(EmailAddress emailAddress, SystemOtpUsageTypeOption otpUsageType);

    Task<Result<bool>> VerifyEmailAsync(int userId, int emailAddressId, string otp, SystemOtpUsageTypeOption otpUsageType);
}
