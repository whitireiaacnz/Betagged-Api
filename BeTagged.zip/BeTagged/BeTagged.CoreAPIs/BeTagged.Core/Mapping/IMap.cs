﻿namespace BeTagged.Core.Mapping;

internal interface IMap<TSource, TDestination>
{
}
