﻿using BeTagged.Data.Seed;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class OtpUsageTypeTable : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(
            name: "system_otp_usage_types_lut",
            schema: "public",
            columns: table => new
            {
                system_otp_usage_type_id = table.Column<byte>(type: "smallint", nullable: false),
                name = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: true)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_system_otp_usage_types_lut", x => x.system_otp_usage_type_id);
            });

        EnumLookupTableSeeder.FillEnumLookup(migrationBuilder, "system_otp_usage_types_lut", typeof(SystemOtpUsageTypeOption));
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable(
            name: "system_otp_usage_types_lut",
            schema: "public");
    }
}
