﻿using System;
using BeTagged.Data.Specifications;

namespace BeTagged.Core.Specifications.Queries;

public class GetUserKeySpecification : ISingleResultQuerySpecification<User, Guid>
{
    public GetUserKeySpecification(int userId)
    {
        Query = q => q.Where(x => x.UserId == userId)
            .Select(x => x.UserKey);
    }

    public Func<IQueryable<User>, IQueryable<Guid>> Query { get; }
}
