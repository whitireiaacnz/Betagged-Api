﻿using Microsoft.EntityFrameworkCore;

namespace BeTagged.Data;

internal partial class BtDb : IBtDb
{
    public DbSet<User> Users { get; set; }

    public DbSet<Influencer> Influencers { get; set; }

    public DbSet<BrandMember> BrandMembers { get; set; }

    public DbSet<Phone> Phones { get; set; }

    public DbSet<EmailAddress> EmailAddresses { get; set; }

    public DbSet<PhoneOtp> PhoneOtps { get; set; }

    public DbSet<EmailOtp> EmailOtps { get; set; }

    public DbSet<BrandOrganization> BrandOrganizations { get; set; }

    public DbSet<BrandMembership> BrandMemberships { get; set; }

    public DbSet<PasswordResetToken> PasswordResetTokens { get; set; }

    public DbSet<BrandProduct> BrandProducts { get; set; }

    public DbSet<BrandProductDiscountCodesFile> BrandProductDiscountCodesFiles { get; set; }

    public DbSet<BrandProductDiscountCode> BrandProductDiscountCodes { get; set; }

    public DbSet<ProductPromotion> ProductPromotions { get; set; }

    public DbSet<ProductPromotionRequest> ProductPromotionRequests { get; set; }

    public DbSet<ProductPromotionLink> ProductPromotionLinks { get; set; }

    public DbSet<ProductSale> ProductSales { get; set; }

    public DbSet<CommissionPayout> CommissionPayouts { get; set; }

    public DbSet<Transaction> Transactions { get; set; }

    public DbSet<ShortenedLink> ShortenedLinks { get; set; }

    public DbSet<BrandProductsSalesDataFile> BrandProductsSalesDataFiles { get; set; }

    public DbSet<BrandMembershipInvitation> BrandMembershipInvitations { get; set; }

    public DbSet<InfluencerBankAccount> InfluencerBankAccounts { get; set; }

    public DbSet<InAppNotification> InAppNotifications { get; set; }

    public DbSet<NotificationProcessorLog> NotificationProcessorLogs { get; set; }

    public DbSet<WebhookMappingDetail> ShopifyWebhookMappingDetails { get; set; }

    // System lookup tables
    public DbSet<SystemSalesSource> SystemSalesSources { get; set; }

    public DbSet<SystemProductUrlType> SystemProductUrlTypes { get; set; }

    public DbSet<SystemInAppNotificationType> SystemInAppNotificationTypes { get; set; }

    public DbSet<SystemInvitationStatus> SystemInvitationStatuses { get; set; }

    public DbSet<SystemRole> SystemRoles { get; set; }

    public DbSet<SystemUserType> SystemUserTypes { get; set; }

    public DbSet<SystemCategory> SystemCategories { get; set; }

    public DbSet<SystemCountry> SystemCountries { get; set; }

    public DbSet<SystemOtpUsageType> SystemOtpUsageTypes { get; set; }

    public DbSet<SystemCurrencyCode> SystemCurrencyCodes { get; set; }

    public DbSet<SystemSalesChannel> SystemSalesChannels { get; set; }

    public DbSet<SystemApprovalStatus> SystemApprovalStatuses { get; set; }

    public DbSet<SystemShortenedLinkEntityType> SystemShortenedLinkEntityTypes { get; set; }
}
