﻿using System;

namespace BeTagged.Core.Dtos;

public class AddProductSaleDto
{
    public int ProductPromotionId { get; set; }

    public int BrandProductId { get; set; }

    public int InfluencerId { get; set; }

    public int BrandOrganizationId { get; set; }

    public SystemSalesChannelOption SalesChannelId { get; set; }

    public bool IsCommissionPaidOff { get; set; }

    public DateTime SoldAtUtc { get; set; }

    public int Quantity { get; set; }

    public int? SalesDataFileId { get; set; }

    public decimal Price { get; set; }

    public int CommissionPercentage { get; set; }

    public decimal InfluencerCommissionPercentage { get; set; }

    public SystemSalesSourceOption SalesSourceId { get; set; }
}
