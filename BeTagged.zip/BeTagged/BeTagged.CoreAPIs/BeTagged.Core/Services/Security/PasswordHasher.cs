﻿using System;
using System.Security.Cryptography;
using System.Text;
using BeTagged.Core.Configurations;
using Microsoft.Extensions.Options;

namespace BeTagged.Core.Services.Security;

internal class PasswordHasher : IPasswordHasher
{
    private readonly SecurityConfiguration _securityConfig;

    public PasswordHasher(IOptions<SecurityConfiguration> securityConfigOptions) =>
        _securityConfig = securityConfigOptions.Value;

    public string GetHashedPassword(string password, string salt)
    {
        var hashingKey = _securityConfig.PasswordHashingSecret + GetHashedSalt(salt);

        var passwordBytes = Encoding.UTF8.GetBytes(password);
        var saltBytes = Encoding.UTF8.GetBytes(hashingKey);

        var byteResult = new Rfc2898DeriveBytes(passwordBytes, saltBytes, 50000);
        return Convert.ToBase64String(byteResult.GetBytes(64));
    }

    private static string GetHashedSalt(string salt)
    {
        var saltBytes = Encoding.UTF8.GetBytes(salt);
        var base64SaltBytes = Encoding.UTF8.GetBytes(Convert.ToBase64String(saltBytes));
        var byteResult = new Rfc2898DeriveBytes(saltBytes, base64SaltBytes, 10000);
        return Convert.ToBase64String(byteResult.GetBytes(24));
    }
}
