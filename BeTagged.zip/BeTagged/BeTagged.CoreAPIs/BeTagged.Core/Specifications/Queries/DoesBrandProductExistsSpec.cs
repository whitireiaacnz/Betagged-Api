﻿using System;
using System.Threading;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class DoesBrandProductExistsSpec : IAnyQuerySpecification<BrandProduct>
{
    public DoesBrandProductExistsSpec(int brandOrganizationId, int brandProductId)
    {
        Query = async (q, ct) =>
            await q.AnyAsync(x => x.BrandOrganizationId == brandOrganizationId && x.BrandProductId == brandProductId,
                ct);
    }

    public DoesBrandProductExistsSpec(int brandProductId)
    {
        Query = async (q, ct) =>
            await q.AnyAsync(x => x.BrandProductId == brandProductId,
                ct);
    }

    public Func<IQueryable<BrandProduct>, CancellationToken, Task<bool>> Query { get; }
}
