﻿using System;
using BeTagged.Data.Specifications;

namespace BeTagged.Core.Specifications.Queries;

public class GetBrandProductMinimalSpec : ISingleResultQuerySpecification<BrandProduct, BrandProduct>
{
    public GetBrandProductMinimalSpec(int brandOrganizationId, int brandProductId)
    {
        Query = queryable => queryable
            .Where(x => x.BrandProductId == brandProductId)
            .Where(x => x.BrandOrganizationId == brandOrganizationId);
    }

    public GetBrandProductMinimalSpec(int brandProductId)
    {
        Query = queryable => queryable
            .Where(x => x.BrandProductId == brandProductId && !x.IsDeleted);
    }

    public Func<IQueryable<BrandProduct>, IQueryable<BrandProduct>> Query { get; }
}
