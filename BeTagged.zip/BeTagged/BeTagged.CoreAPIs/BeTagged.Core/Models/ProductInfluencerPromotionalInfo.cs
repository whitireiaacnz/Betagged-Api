﻿using System;

namespace BeTagged.Core.Models;

public class ProductInfluencerPromotionalInfo
{
    public ProductPromotionDetails Facebook { get; set; }

    public ProductPromotionDetails Twitter { get; set; }

    public ProductPromotionDetails TikTok { get; set; }

    public ProductPromotionDetails Instagram { get; set; }
}

public class ProductPromotionDetails
{
    public ProductPromotionRequestDetails Request { get; set; }

    public int? ProductPromotionId { get; set; }

    public string ProductLink { get; set; }

    public string DiscountCode { get; set; }

    public int? ClickCount { get; set; }
}

public class ProductPromotionRequestDetails
{
    public int ProductPromotionRequestId { get; set; }

    public SystemSalesChannelOption? SalesChannel { get; set; }

    public SystemApprovalStatusOption? ApprovalStatus { get; set; }

    public DateTime? RequestedOnUtc { get; set; }

    public DateTime? ActedOnUtc { get; set; }

    public bool? IsRejectedDueToPeriodExpiration { get; set; }
}
