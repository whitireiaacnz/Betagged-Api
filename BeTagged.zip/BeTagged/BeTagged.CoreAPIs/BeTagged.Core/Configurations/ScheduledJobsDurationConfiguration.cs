﻿namespace BeTagged.Core.Configurations;

public class ScheduledJobsDurationConfiguration
{
    public const string Section = "ScheduledJobsDurationConfiguration";

    public int RequestAutoRejectTimeDurationInDays { get; set; }

    public int SalesDataUploadReminderDurationInDays { get; set; }

    public int ProductListingReminder1 { get; set; }

    public int ProductListingReminder2 { get; set; }

    public int HasNotPickedProductReminder1 { get; set; }

    public int HasNotPickedProductReminder2 { get; set; }

    public int CompleteSignupReminderDelayInDays { get; set; }

    public int CompleteOnboardingReminderDelayInDays { get; set; }
}
