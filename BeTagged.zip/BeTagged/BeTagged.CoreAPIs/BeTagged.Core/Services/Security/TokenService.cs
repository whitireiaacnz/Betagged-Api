﻿using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;

namespace BeTagged.Core.Services.Security;

internal class TokenService : ITokenService
{
    public string GenerateToken(string secretKey, IEnumerable<Claim> claims, string issuer, string audience, DateTime? expires = null)
    {
        var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey));
        var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256Signature);

        var tokenDescriptor = new JwtSecurityToken(
            issuer,
            audience,
            claims,
            DateTime.UtcNow,
            expires,
            credentials);

        return new JwtSecurityTokenHandler().WriteToken(tokenDescriptor);
    }

    public (bool IsValida, IEnumerable<Claim> Claims) ValidateAndParseToken(string token, string secretKey, string issuer, string audience,
        bool validateExpiry = true)
    {
        var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(secretKey));
        var tokenHandler = new JwtSecurityTokenHandler();

        try
        {
            tokenHandler.ValidateToken(token, new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidIssuer = issuer,
                ValidAudience = audience,
                IssuerSigningKey = mySecurityKey,
                ValidateLifetime = validateExpiry,
                ClockSkew = TimeSpan.Zero
            }, out SecurityToken _);

            var securityToken = tokenHandler.ReadToken(token) as JwtSecurityToken;
            return (true, securityToken!.Claims);
        }
        catch
        {
            return (false, null);
        }
    }
}
