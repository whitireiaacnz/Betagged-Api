﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Entities;

[Table("system_sale_channels_lut")]
public class SystemSalesChannel
{
    public SystemSalesChannel()
    {
        ProductPromotionRequests = new List<ProductPromotionRequest>();
        ProductPromotions = new List<ProductPromotion>();
        ProductSales = new List<ProductSale>();
    }

    public SystemSalesChannelOption SystemSalesChannelId { get; set; }

    [Required, MaxLength(32)]
    public string Name { get; set; }

    // Reverse navigation
    public ICollection<ProductPromotion> ProductPromotions { get; set; }

    public ICollection<ProductPromotionRequest> ProductPromotionRequests { get; set; }

    public ICollection<ProductSale> ProductSales { get; set; }
}
