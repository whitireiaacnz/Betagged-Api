﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class OtpUsageType : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AddColumn<byte>(
            name: "usage_type_id",
            schema: "public",
            table: "otps",
            type: "smallint",
            nullable: false,
            defaultValue: (byte)1);

        migrationBuilder.CreateIndex(
            name: "ix_otps_usage_type_id",
            schema: "public",
            table: "otps",
            column: "usage_type_id");

        migrationBuilder.AddForeignKey(
            name: "fk_otps_system_otp_usage_types_lut_usage_type_id",
            schema: "public",
            table: "otps",
            column: "usage_type_id",
            principalSchema: "public",
            principalTable: "system_otp_usage_types_lut",
            principalColumn: "system_otp_usage_type_id",
            onDelete: ReferentialAction.Restrict);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropForeignKey(
            name: "fk_otps_system_otp_usage_types_lut_usage_type_id",
            schema: "public",
            table: "otps");

        migrationBuilder.DropIndex(
            name: "ix_otps_usage_type_id",
            schema: "public",
            table: "otps");

        migrationBuilder.DropColumn(
            name: "usage_type_id",
            schema: "public",
            table: "otps");
    }
}
