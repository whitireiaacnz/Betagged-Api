﻿using System;
using System.Threading;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetInfluencerBankAccountListSpec : IListResultQuerySpecification<InfluencerBankAccount, InfluencerBankAccount>
{
    public GetInfluencerBankAccountListSpec(int influencerId)
    {
        Query = async (queryable, ct) => await queryable
        .Where(x => x.InfluencerId == influencerId)
        .ToListAsync(ct);
    }

    public Func<IQueryable<InfluencerBankAccount>, CancellationToken, Task<IList<InfluencerBankAccount>>> Query { get; }
}
