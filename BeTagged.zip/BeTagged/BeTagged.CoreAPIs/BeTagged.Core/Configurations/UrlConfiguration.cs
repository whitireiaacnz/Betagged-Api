﻿namespace BeTagged.Core.Configurations;

public class UrlConfiguration
{
    public const string Section = "UrlConfig";

    public string WebClientBaseUrl { get; set; }
}
