﻿namespace BeTagged.Core.Services.Clevertap;

public static class CustomUserAttributes
{
    public const string UserType = "user-type";

    public const string HasCompletedSignUp = "has-completed-signup";

    public const string HasCompletedOnboarding = "has-completed-onboarding";

    public const string HasListedAProduct = "has-listed-a-product";

    public const string ProductsSold = "products-sold";
}
