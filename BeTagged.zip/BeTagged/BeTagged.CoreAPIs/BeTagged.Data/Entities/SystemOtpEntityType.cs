﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Entities;

[Table("system_otp_entity_types_lut")]
public class SystemOtpEntityType
{
    public SystemOtpEntityType()
    {
        Otps = new List<Otp>();
    }

    public SystemOtpEntityTypeOption SystemOtpEntityTypeId { get; set; }

    [MaxLength(16), Required]
    public string Name { get; set; }

    // Reverse navigation
    public ICollection<Otp> Otps { get; set; }
}
