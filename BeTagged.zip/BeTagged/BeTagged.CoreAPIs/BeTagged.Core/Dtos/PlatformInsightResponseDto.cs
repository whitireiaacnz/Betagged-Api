﻿namespace BeTagged.Core.Dtos;

public class PlatformInsightResponseDto
{
    public int Sales { get; set; }

    public int ClickCount { get; set; }

    public decimal Conversions { get; set; }

    public decimal CommissionEarned { get; set; }

    public int BrandProductId { get; set; }

    public string BrandProductName { get; set; }
}
