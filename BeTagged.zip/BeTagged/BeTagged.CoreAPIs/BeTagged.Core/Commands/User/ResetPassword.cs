﻿using System.Threading;
using BeTagged.Core.CQRS;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Utils;

namespace BeTagged.Core.Commands.User;

public static class ResetPassword
{
    public record Command(string Email, string Password, string PasswordResetToken, SystemUserTypeOption? UserType) : ITransactionalRequest<Response>;

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.Email).NotEmpty().EmailAddress();
            RuleFor(x => x.Password).NotEmpty().Matches(PropertyValidationUtil.PasswordRegex)
                .WithMessage(ValidationMessages.PasswordMustBeValid);
            RuleFor(x => x.PasswordResetToken).NotEmpty();
            RuleFor(x => x.UserType).NotNull();
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IPasswordResetService _passwordResetService;

        public Handler(IPasswordResetService passwordResetService) => _passwordResetService = passwordResetService;

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var resetResult = await _passwordResetService.ResetPassword(
                request.Email,
                request.Password,
                request.PasswordResetToken, request.UserType!.Value);

            var response = new Response();

            if (!resetResult.IsSuccess)
            {
                response.Error = resetResult.Error;
                response.ErrorMessage = resetResult.ErrorMessage;
            }

            return response;
        }
    }

    public class Response : Result
    {
    }
}
