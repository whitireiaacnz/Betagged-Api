﻿namespace BeTagged.Core.Services.Clevertap;

public class ClevertapResponse
{
    public string Status { get; set; }
}
