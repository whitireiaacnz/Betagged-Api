﻿using Newtonsoft.Json;

namespace BeTagged.Core.Models;

public record ErrorItem
{
    public ErrorItem(string message, string fieldName = null)
        => (FieldName, Message) = (fieldName, message);

    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public string FieldName { get; set; }

    public string Message { get; set; }
}
