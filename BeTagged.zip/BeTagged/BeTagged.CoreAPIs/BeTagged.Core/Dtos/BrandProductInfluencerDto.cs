﻿namespace BeTagged.Core.Dtos;

public class BrandProductInfluencerDto
{
    public string InfluencerProfilePicUrl { get; set; }

    public string Name { get; set; }

    public int Sales { get; set; }

    public decimal Commission { get; set; }

    public string CurrencySymbol { get; set; }

    public IEnumerable<SalesChannelData> SalesChannelData { get; set; }
}

public class SalesChannelData
{
    public SystemSalesChannelOption SalesChannel { get; set; }

    public string Link { get; set; }

    public int Sale { get; set; }

    public int ClickCount { get; set; }
}
