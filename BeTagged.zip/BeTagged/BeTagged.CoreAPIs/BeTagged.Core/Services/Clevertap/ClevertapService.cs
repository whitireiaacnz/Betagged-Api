﻿using System;
using System.Net.Http;
using System.Text;
using BeTagged.Common.Utils;
using BeTagged.Core.Dtos;
using BeTagged.Core.Extensions;
using BeTagged.Core.Services.CDP;
using BeTagged.Core.Services.Notification;
using BeTagged.Core.Utils;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace BeTagged.Core.Services.Clevertap;

public class ClevertapService : ICdpService
{
    private const string UploadEndpoint = "/1/upload";
    private const string Success = "success";

    private static readonly JsonSerializerSettings JsonSerializerSettings;

    private readonly IHttpClientFactory _clientFactory;

    static ClevertapService()
    {
        JsonSerializerSettings = new JsonSerializerSettings()
        {
            Converters = new List<JsonConverter>
            {
                new StringEnumConverter()
            }
        };
    }

    public ClevertapService(IHttpClientFactory clientFactory)
        => _clientFactory = clientFactory;

    public async Task CreateUserProfileAsync(Guid userKey, CreateUserDto userDto)
    {
        var (countryCode, phone) = PhoneUtil.ParsePhone(userDto.CountryCode, userDto.Phone);

        var profileData = new Dictionary<string, object>()
        {
            ["Name"] = userDto.Name,
            ["Email"] = userDto.Email,
            ["Phone"] = $"{countryCode}{phone}",
            ["MSG-email"] = true,
            ["MSG-sms"] = true,
            ["MSG-whatsapp"] = true,
            [CustomUserAttributes.UserType] = userDto.UserType,
        };

        if (userDto.UserType == SystemUserTypeOption.Influencer)
        {
            profileData[CustomUserAttributes.ProductsSold] = 0;
        }

        await UploadUserProfileAsync(userKey, profileData);
    }

    public async Task AddHasCompletedSignupUserAttributeAsync(Guid userKey)
    {
        var profileData = new Dictionary<string, object>()
        {
            [CustomUserAttributes.HasCompletedSignUp] = true
        };

        await UploadUserProfileAsync(userKey, profileData);
    }

    public async Task AddHasCompletedOnboardingUserAttributeAsync(Guid userKey)
    {
        var profileData = new Dictionary<string, object>()
        {
            [CustomUserAttributes.HasCompletedOnboarding] = true
        };

        await UploadUserProfileAsync(userKey, profileData);
    }

    public async Task AddHasListedAProductUserAttributeAsync(Guid userKey)
    {
        var profileData = new Dictionary<string, object>()
        {
            [CustomUserAttributes.HasListedAProduct] = true
        };

        await UploadUserProfileAsync(userKey, profileData);
    }

    public async Task UpdateUserNameAsync(Guid userKey, string name)
    {
        var profileData = new Dictionary<string, object>()
        {
            ["Name"] = name
        };

        await UploadUserProfileAsync(userKey, profileData);
    }

    public async Task UpdateUserEmailAsync(Guid userKey, string email)
    {
        var profileData = new Dictionary<string, object>()
        {
            ["Email"] = email
        };

        await UploadUserProfileAsync(userKey, profileData);
    }

    public async Task IncrementProductsSoldCountAsync(Guid userKey, int count)
    {
        var profileData = new Dictionary<string, object>()
        {
            [CustomUserAttributes.ProductsSold] = new Dictionary<string, object>()
            {
                ["$incr"] = count
            }
        };

        await UploadUserProfileAsync(userKey, profileData);
    }

    public async Task DecrementProductSoldCountAsync(Guid userKey, int count)
    {
        var profileData = new Dictionary<string, object>()
        {
            [CustomUserAttributes.ProductsSold] = new Dictionary<string, object>()
            {
                ["$decr"] = count
            }
        };

        await UploadUserProfileAsync(userKey, profileData);
    }

    public async Task UpdateUserPhoneAsync(Guid userKey, string countryCode, string phoneNumber)
    {
        var (parsedCountryCode, parsedPhoneNumber) = PhoneUtil.ParsePhone(countryCode, phoneNumber);

        var profileData = new Dictionary<string, object>()
        {
            ["Phone"] = $"{parsedCountryCode}{parsedPhoneNumber}"
        };

        await UploadUserProfileAsync(userKey, profileData);
    }

    public async Task SendSignupCompletedEventAsync(Guid userKey)
        => await SendEventAsync(userKey, CdpEvents.SignupCompleted);

    public async Task SendOnboardingCompletedEventAsync(Guid userKey)
        => await SendEventAsync(userKey, CdpEvents.OnboardingCompleted);

    public async Task SendProductListedEventAsync(Guid userKey, string brandProductUrl, int brandProductId,
        string productName)
    {
        var eventData =
            NotificationPayloadUtil.BuildProductListedPayload(brandProductId, brandProductUrl, productName);

        await SendEventAsync(userKey, CdpEvents.ProductListed, eventData);
    }

    public async Task SendXPercentageCouponExhaustedEventAsync(IEnumerable<Guid> userKeys, int percentage, string brandProductUrl,
        int brandProductId, string productName)
    {
        var eventData = NotificationPayloadUtil.BuildPercentageCouponExhaustedPayload(brandProductId,
            brandProductUrl, productName, percentage);

        await SendEventAsync(userKeys, CdpEvents.CouponExhausted, eventData);
    }

    public async Task SendSalesDataNeedsToBeUploadedEventAsync(Guid userKey, string brandProductUrl, int brandProductId,
        string productName)
    {
        var eventData =
            NotificationPayloadUtil.BuildSalesDataNeedsToBeUploadedPayload(brandProductId, brandProductUrl,
                productName);

        await SendEventAsync(userKey, CdpEvents.SalesDataUploadReminder, eventData);
    }

    public async Task SendProductSoldEventAsync(Guid userKey)
    {
        var eventData = new Dictionary<string, object>();

        await SendEventAsync(userKey, CdpEvents.ProductSold, eventData);
    }

    public async Task SendProductRequestApprovedEventAsync(Guid userKey, int productId, string productUrl, string productName)
    {
        var eventData =
            NotificationPayloadUtil.BuildProductRequestApprovedPayload(productId, productUrl, productName);

        await SendEventAsync(userKey, CdpEvents.ProductRequestAccepted, eventData);
    }

    public async Task SendProductRequestRejectedEventAsync(Guid userKey, int productId, string productUrl, string productName)
    {
        var eventData =
            NotificationPayloadUtil.BuildProductRequestRejectedPayload(productId, productUrl, productName);

        await SendEventAsync(userKey, CdpEvents.ProductRequestRejected, eventData);
    }

    public async Task SendProductUnlistedEventAsync(IEnumerable<Guid> userKeys, int productId, string productUrl, string productName)
    {
        var eventData = NotificationPayloadUtil.BuildProductUnlistedPayload(productId, productUrl, productName);

        await SendEventAsync(userKeys, CdpEvents.ProductUnlisted, eventData);
    }

    public async Task SendProductListingReminderEventAsync(Guid userKey, int daysWithoutListingProduct)
    {
        var eventData = NotificationPayloadUtil.BuildProductListingReminderPayload(daysWithoutListingProduct);
        await SendEventAsync(userKey, CdpEvents.ProductListingReminder, eventData);
    }

    public async Task SendInfluencerSeekingApprovalEventAsync(IEnumerable<Guid> userKeys, int productId, string productUrl,
        string productName)
    {
        var eventData =
            NotificationPayloadUtil.BuildInfluencerSeekingApprovalPayload(productId, productUrl, productName);

        await SendEventAsync(userKeys, CdpEvents.InfluencersSeekingApproval, eventData);
    }

    public async Task SendReminderForPickingAProductToInfluencerAsync(Guid userKey, int daysWithoutPickingAProduct)
    {
        var eventData = NotificationPayloadUtil.BuildReminderForPickingAProductPayload(daysWithoutPickingAProduct);
        await SendEventAsync(userKey, CdpEvents.ProductPickingReminder, eventData);
    }

    public async Task SendCompleteSignupReminderEventAsync(Guid userKey)
    {
        await SendEventAsync(userKey, CdpEvents.CompleteSignupReminder);
    }

    public async Task SendCompleteOnboardingReminderEventAsync(Guid userKey)
    {
        await SendEventAsync(userKey, CdpEvents.CompleteOnboardingReminder);
    }

    private static StringContent GetStringContent(object data)
        => new(data.Serialize(JsonSerializerSettings), Encoding.UTF8, ContentTypes.ApplicationJson);

    private static async Task ValidateSuccessResponseAsync(HttpResponseMessage httpResponseMessage)
    {
        if (!httpResponseMessage.IsSuccessStatusCode)
        {
            // TODO: Create domain exception
            throw new Exception("Something went wrong....");
        }

        var response = await httpResponseMessage.ReadResponseAsync<ClevertapResponse>();

        if (response.Status != Success)
        {
            throw new Exception();
        }
    }

    private async Task SendEventAsync(Guid userKey, string eventName,
        Dictionary<string, object> eventData = null)
    {
        var eventPayload = new List<ClevertapEvent>()
        {
            new()
            {
                Identity = userKey,
                EvtName = eventName,
                EvtData = eventData
            }
        };

        await SendEventAsync(eventPayload);
    }

    private async Task SendEventAsync(IEnumerable<Guid> userKeys, string eventName,
        Dictionary<string, object> eventData = null)
    {
        // maximum number of event allowed per api call is 1000.
        var batches = userKeys.ToList().Chunk(1000);

        foreach (var userKeyBatch in batches)
        {
            var eventPayload = userKeyBatch.Select(userKey => new ClevertapEvent()
            {
                Identity = userKey,
                EvtName = eventName,
                EvtData = eventData
            }).ToList();

            await SendEventAsync(eventPayload);
        }
    }

    private async Task SendEventAsync(IEnumerable<ClevertapEvent> eventPayload)
    {
        var client = GetClevertapClient();

        using (client)
        {
            var payload = new
            {
                d = eventPayload
            };

            var content = GetStringContent(payload);

            var response = await client.PostAsync(UploadEndpoint, content);

            await ValidateSuccessResponseAsync(response);
        }
    }

    private async Task UploadUserProfileAsync(Guid userKey, Dictionary<string, object> profileData)
    {
        var client = GetClevertapClient();

        using (client)
        {
            var payload = new
            {
                d = new List<UploadUserProfile>()
                {
                    new()
                    {
                        Identity = userKey,
                        ProfileData = profileData
                    }
                }
            };

            var content = GetStringContent(payload);

            var response = await client.PostAsync(UploadEndpoint, content);

            await ValidateSuccessResponseAsync(response);
        }
    }

    private HttpClient GetClevertapClient() => _clientFactory.CreateClient(HttpClients.Clevertap);
}
