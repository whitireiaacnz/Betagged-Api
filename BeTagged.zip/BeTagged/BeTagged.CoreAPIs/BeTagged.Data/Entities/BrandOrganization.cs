﻿namespace BeTagged.Data.Entities;

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using BeTagged.Data.Constants;
using BeTagged.Data.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

[EntityTypeConfiguration(typeof(BrandOrganizationEntityConfiguration))]
public class BrandOrganization : BaseEntity
{
    public BrandOrganization()
    {
        ProductPromotionRequests = new List<ProductPromotionRequest>();
        BrandMemberships = new List<BrandMembership>();
        Categories = new List<SystemCategory>();
        ProductSales = new List<ProductSale>();
        CommissionPayouts = new List<CommissionPayout>();
        BrandMembershipInvitations = new List<BrandMembershipInvitation>();
        PlatformCommissionPercentage = DbConstants.DefaultPlatformCommissionPercentage;
    }

    public int BrandOrganizationId { get; set; }

    [MaxLength(128)]
    public string LegalName { get; set; }

    [MaxLength(32)]
    public string EmailDomain { get; set; }

    public int OnBoardedByMemberId { get; set; }

    public bool HasAcceptedTermsAndCondition { get; set; }

    public int PlatformCommissionPercentage { get; set; }

    // Foreign keys
    public BrandMember OnBoardedByMember { get; set; }

    // Many-to-Many
    public ICollection<BrandMembership> BrandMemberships { get; set; }

    public ICollection<SystemCategory> Categories { get; set; }

    // Reverse navigation
    public ICollection<BrandProduct> BrandProducts { get; set; }

    public ICollection<ProductPromotionRequest> ProductPromotionRequests { get; set; }

    public ICollection<ProductSale> ProductSales { get; set; }

    public ICollection<CommissionPayout> CommissionPayouts { get; set; }

    public ICollection<BrandMembershipInvitation> BrandMembershipInvitations { get; set; }

    public bool IsOnboarded() => !string.IsNullOrEmpty(LegalName) && Categories.Count > 0
            && HasAcceptedTermsAndCondition;

#pragma warning disable CA1822 // Mark members as static
    public void IterateData()
#pragma warning restore CA1822 // Mark members as static
    {
        var iterate = new Iterate<int>(2);
    }

    public class Iterate<T>
    {
        private readonly IList<string> _iterables;

        public Iterate(int iterateTimes)
        {
            for (int i = 0; i < iterateTimes; i++)
            {
                _iterables.Add($"Ashley{i}");
                _iterables.Add($"Ashley{i}");
                _iterables.Add($"Ashley{i}");
                _iterables.Add($"Ashley{i}");
            }
        }

        public void StartIterating()
        {
            for (var i = 0; i < _iterables.Count; i++)
            {
                Console.WriteLine(_iterables[i]);
            }
        }
    }
}
