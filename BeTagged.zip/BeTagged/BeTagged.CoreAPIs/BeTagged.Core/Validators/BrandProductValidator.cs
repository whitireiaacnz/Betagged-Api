﻿using BeTagged.Common.Extensions;
using BeTagged.Core.Utils;

namespace BeTagged.Core.Validators;

public class BrandProductValidator
{
}

public class BrandProductSocialMediaKitValidator : AbstractValidator<ProductSocialMediaKit>
{
    public BrandProductSocialMediaKitValidator()
    {
        RuleFor(x => x.TwitterMediaKitUrl)
                .Must(x => x.IsUri())
                .WithMessage(ValidationMessages.LinkMustBeValidUri)
                .Must(PropertyValidationUtil.IsZipFileUrl)
                .WithMessage(ValidationMessages.FileMustBeValidZip)
                .When(x => x.TwitterMediaKitUrl is not null);

        RuleFor(x => x.FacebookMediaKitUrl)
            .Must(x => x.IsUri())
            .WithMessage(ValidationMessages.LinkMustBeValidUri)
            .Must(PropertyValidationUtil.IsZipFileUrl)
            .WithMessage(ValidationMessages.FileMustBeValidZip)
            .When(x => x.FacebookMediaKitUrl is not null);

        RuleFor(x => x.InstagramMediaUrl)
            .Must(x => x.IsUri())
            .WithMessage(ValidationMessages.LinkMustBeValidUri)
            .Must(PropertyValidationUtil.IsZipFileUrl)
            .WithMessage(ValidationMessages.FileMustBeValidZip)
            .When(x => x.InstagramMediaUrl is not null);

        RuleFor(x => x.TikTokMediaKitUrl)
            .Must(x => x.IsUri())
            .WithMessage(ValidationMessages.LinkMustBeValidUri)
            .Must(PropertyValidationUtil.IsZipFileUrl)
            .WithMessage(ValidationMessages.FileMustBeValidZip)
            .When(x => x.TikTokMediaKitUrl is not null);
    }
}
