﻿using System.ComponentModel;
using System.Threading;
using BeTagged.Core.Queries.Shared;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Storage;
using BeTagged.Data.Services;

namespace BeTagged.Core.Queries.InfluencerProduct;

public static class GetInfluencerProducts
{
    public class ODataQuery : ODataQueryBase, IRequest<PaginatedList<Response>>
    {
    }

    public class Query : ODataQuery
    {
        public Query()
        {
            Brands = Enumerable.Empty<int>();
            Categories = Enumerable.Empty<int>();
        }

        public IEnumerable<int> Brands { get; set; }

        public IEnumerable<int> Categories { get; set; }

        [DefaultValue(null)]
        public SystemProductListingOfferTypeOption? OfferType { get; set; }
    }

    public class Handler : IRequestHandler<Query, PaginatedList<Response>>
    {
        private readonly ICurrentInfluencer _currentInfluencer;
        private readonly IStorageService _storageService;
        private readonly IQueryService _queryService;

        public Handler(ICurrentInfluencer currentInfluencer, IStorageService storageService, IQueryService queryService)
        {
            _currentInfluencer = currentInfluencer;
            _storageService = storageService;
            _queryService = queryService;
        }

        public async Task<PaginatedList<Response>> Handle(Query request, CancellationToken cancellationToken)
        {
            var parameters = new
            {
                InfluencerId = _currentInfluencer.InfluencerId,
                Criteria = request.Criteria,
                Take = request.Take,
                Skip = request.Skip,
                BrandIds = request.Brands.ToArray(),
                CategoryIds = request.Categories.ToArray(),
                OfferType = request.OfferType
            };

            var products = await _queryService
                .QueryAsync<Response>(BtQueryType.GetInfluencerProducts, null, parameters);

            int totalCount = 0;

            if (products.Count > 0)
            {
                totalCount = products[0].TotalCount;

                for (int i = 0; i < products.Count; i++)
                {
                    products[i].ShowCaseMediaUrls = products[i].ShowCaseMediaUrls
                        .Select(x => _storageService.GetSignedUrl(x));
                }
            }

            return new PaginatedList<Response>(totalCount, products, request.Skip, request.Take);
        }
    }

    public class Response : InfluencerProductsModel
    {
    }
}
