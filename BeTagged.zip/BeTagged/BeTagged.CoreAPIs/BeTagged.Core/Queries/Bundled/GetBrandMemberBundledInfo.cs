﻿using System;
using System.Threading;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Storage;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Queries.Bundled;

public static class GetBrandMemberBundledInfo
{
    public record Query : IRequest<Response>;

    public class Handler : IRequestHandler<Query, Response>
    {
        private readonly IBtDb _db;
        private readonly ICurrentBrandMember _currentBrandMember;
        private readonly IStorageService _storageService;

        public Handler(ICurrentBrandMember currentBrandMember, IBtDb db, IStorageService storageService)
        {
            _currentBrandMember = currentBrandMember;
            _db = db;
            _storageService = storageService;
        }

        public async Task<Response> Handle(Query request, CancellationToken cancellationToken)
        {
            var response = await _db
                .BrandMemberships
                .Include(x => x.BrandMember.User)
                .Include(x => x.BrandOrganization)
                .AsNoTracking()
                .Where(x => x.BrandMembershipId == _currentBrandMember.BrandMembershipId)
                .Select(x => new Response()
                {
                    UserKey = x.BrandMember.User.UserKey,
                    Name = x.BrandMember.User.Name,
                    ProfilePicUrl = x.BrandMember.User.ProfilePicPath,
                    Role = x.RoleId,
                    BrandInfo = new()
                    {
                        BrandId = x.BrandOrganizationId,
                        Role = x.RoleId,
                        LegalName = x.BrandOrganization.LegalName,
                        Categories =
                            x.BrandOrganization.Categories.Select(y =>
                                new SystemCategoryLookupItem(y.SystemCategoryId, y.Name, y.CategoryGroupName))
                    }
                })
                .SingleAsync(cancellationToken);

            // TODO: optimize into single db call
            response.BrandMemberships = _db
                .BrandMemberships
                .Include(x => x.BrandOrganization)
                .Where(x => x.BrandMemberId == _currentBrandMember.BrandMemberId)
                .Where(x => !x.IsDisabled)
                .Select(x => new BrandMembershipInfo()
                {
                    BrandId = x.BrandOrganizationId,
                    LegalName = x.BrandOrganization.LegalName,
                    Role = x.RoleId
                });

            response.ProfilePicUrl = _storageService.GetSignedUrl(response.ProfilePicUrl);

            return response;
        }
    }

    public class Response
    {
        public Guid UserKey { get; set; }

        public string Name { get; set; }

        public string ProfilePicUrl { get; set; }

        public SystemRoleOption Role { get; set; }

        public BrandOrganizationInfo BrandInfo { get; set; }

        public IEnumerable<BrandMembershipInfo> BrandMemberships { get; set; }
    }

    public class BrandMembershipInfo
    {
        public string LegalName { get; set; }

        public int BrandId { get; set; }

        public SystemRoleOption Role { get; set; }
    }
}
