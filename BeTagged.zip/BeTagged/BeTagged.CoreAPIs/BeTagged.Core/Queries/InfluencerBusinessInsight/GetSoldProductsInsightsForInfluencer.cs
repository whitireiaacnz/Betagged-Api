﻿using System;
using System.Threading;
using BeTagged.Core.Queries.Shared;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Storage;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Queries.InfluencerBusinessInsight;

public static class GetSoldProductsInsightsForInfluencer
{
    public class Query : ODataQueryBase, IRequest<PaginatedList<Response>>
    {
        public DateTime? From { get; set; }

        public DateTime? To { get; set; }
    }

    public class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.From).LessThan(x => x.To).When(x => x.From is not null);
        }
    }

    public class Handler : IRequestHandler<Query, PaginatedList<Response>>
    {
        private readonly IReadOnlyBtDb _db;
        private readonly ICurrentInfluencer _currentInfluencer;
        private readonly IStorageService _storageService;

        public Handler(IReadOnlyBtDb db, ICurrentInfluencer currentInfluencer, IStorageService storageService)
        {
            _db = db;
            _currentInfluencer = currentInfluencer;
            _storageService = storageService;
        }

        public Task<PaginatedList<Response>> Handle(Query request, CancellationToken cancellationToken)
        {
            var countQuery = _db.ProductSales
                .Where(x => x.InfluencerId == _currentInfluencer.InfluencerId)
                .Where(y => request.From == null || (y.SoldAtUtc >= request.From && y.SoldAtUtc <= request.To))
                .GroupBy(x => new { x.BrandProductId })
                .Select(x => x.First().ProductSaleId);

            var soldProductsDetails = _db
                .ProductSales
                .Include(x => x.BrandProduct)
                .Include(x => x.ProductPromotion.ProductPromotionLink)
                .Where(x => x.InfluencerId == _currentInfluencer.InfluencerId)
                .Where(y => request.From == null || (y.SoldAtUtc >= request.From && y.SoldAtUtc <= request.To))
                .GroupBy(x => new { x.BrandProductId })
                .Select(x => new Response()
                {
                    BrandProductId = x.First().BrandProductId,
                    ProductName = x.First().BrandProduct.Name,
                    Commission = x.Sum(y => y.InfluencerPayableCommission),
                    NumberOfSales = x.Sum(y => y.Quantity),
                    ShowCaseMediaUrls = x.First().BrandProduct.ShowCaseMediaUrls,
                    Links = x.GroupBy(y => new { y.ProductPromotionId, y.SalesChannelId })
                            .Select(y => new SocialMediaPromotionLinks()
                            {
                                SalesChannel = y.First().SalesChannelId,
                                Url = y.First().ProductPromotion.ProductPromotionLink.Url
                            })
                })
                .Skip(request.Skip).Take(request.Take).ToList();

            if (soldProductsDetails.Any())
            {
                for (int i = 0; i < soldProductsDetails.Count; i++)
                {
                    soldProductsDetails[i].ShowCaseMediaUrls = soldProductsDetails[i].ShowCaseMediaUrls
                            .Select(x => _storageService.GetSignedUrl(x));
                }
            }

            return Task.FromResult(new PaginatedList<Response>(countQuery.Count(), soldProductsDetails, request.Skip, request.Take));
        }
    }

    public class Response
    {
        public int BrandProductId { get; set; }

        public string ProductName { get; set; }

        public int NumberOfSales { get; set; }

        public decimal Commission { get; set; }

        public IEnumerable<string> ShowCaseMediaUrls { get; set; }

        public IEnumerable<SocialMediaPromotionLinks> Links { get; set; }
    }

    public sealed class SocialMediaPromotionLinks
    {
        public SystemSalesChannelOption SalesChannel { get; set; }

        public string Url { get; set; }
    }
}
