﻿namespace BeTagged.Core.Enums;

public enum AppServiceType : byte
{
    WebHandler,
    BackgroundWorker
}
