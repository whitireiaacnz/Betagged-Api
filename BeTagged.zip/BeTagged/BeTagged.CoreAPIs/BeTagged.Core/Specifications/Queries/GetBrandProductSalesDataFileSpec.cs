﻿using System;
using BeTagged.Data.Specifications;

namespace BeTagged.Core.Specifications.Queries;

public class GetBrandProductSalesDataFileSpec : ISingleResultQuerySpecification<BrandProductsSalesDataFile, BrandProductsSalesDataFile>
{
    public GetBrandProductSalesDataFileSpec(int id)
    {
        Query = q => q.Where(x => x.BrandProductsSaleDataFileId == id);
    }

    public Func<IQueryable<BrandProductsSalesDataFile>, IQueryable<BrandProductsSalesDataFile>> Query { get; }
}
