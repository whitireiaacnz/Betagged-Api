﻿using System;
using System.Threading;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetCategoriesSpec : IListResultQuerySpecification<SystemCategory, SystemCategory>
{
    public GetCategoriesSpec(IEnumerable<int> ids)
    {
        Query = async (queryable, ct) => await queryable
            .Where(x => ids.Contains(x.SystemCategoryId))
            .ToListAsync(ct);
    }

    public Func<IQueryable<SystemCategory>, CancellationToken, Task<IList<SystemCategory>>> Query { get; }
}
