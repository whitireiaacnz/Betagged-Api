﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace BeTagged.Common.Extensions;

public static class IServiceCollectionExtensions
{
    public static IServiceCollection AddConfigurationOption<T>(this IServiceCollection services, IConfiguration configuration, string section)
        where T : class
    {
        ArgumentNullException.ThrowIfNull(services);
        ArgumentNullException.ThrowIfNull(configuration);
        ArgumentNullException.ThrowIfNull(section);

        services.Configure<T>(configuration.GetSection(section));

        return services;
    }
}
