﻿using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Attributes;

public class GeometryPointAttribute : ColumnAttribute
{
    public GeometryPointAttribute()
    {
        TypeName = "geometry (point)";
    }
}
