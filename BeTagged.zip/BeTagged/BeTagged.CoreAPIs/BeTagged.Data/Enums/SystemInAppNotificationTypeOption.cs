﻿namespace BeTagged.Data.Enums;

[EnumLookupTable(typeof(SystemInAppNotificationType))]
public enum SystemInAppNotificationTypeOption : byte
{
    ProductListingReminder = 1,
    ProductListed = 2,
    MadeFirstSale = 3,
    XCouponExhausted = 4,
    SalesDataUploadReminder = 5,
    InfluencersSeekingApproval = 6,
    PersonHasJoinedUsingInvitation = 7,
    ProductRequestAccepted = 8,
    ProductRequestRejected = 9,
    ProductUnlisted = 10,
    ProductPickingReminder = 11
}
