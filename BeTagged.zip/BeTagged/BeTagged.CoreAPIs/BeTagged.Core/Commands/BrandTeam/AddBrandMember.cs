﻿using System.Threading;
using BeTagged.Core.Dtos;
using BeTagged.Core.Services.Brand;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Utils;

namespace BeTagged.Core.Commands.BrandTeam;

public static class AddBrandMember
{
    public record Command(string Email, SystemRoleOption Role) : IRequest<Response>;

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.Email)
                .Cascade(CascadeMode.Stop)
                .NotEmpty().EmailAddress()
                .Must(x => !BlacklistedEmailDomains.BlacklistEmailDomains.Contains(EmailUtil.GetDomain(x)))
                .WithMessage(ValidationMessages.BlacklistedEmailMessage);
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly ICurrentBrandMember _currentBrandMember;
        private readonly IBrandMembershipService _brandMembershipService;

        public Handler(ICurrentBrandMember currentBrandMember, IBrandMembershipService brandMembershipService)
        {
            _currentBrandMember = currentBrandMember;
            _brandMembershipService = brandMembershipService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var addMembershipResult = await _brandMembershipService.AddBrandMemberAsync(new AddBrandMemberDto()
            {
                InvitedByBrandMemberId = _currentBrandMember.BrandMemberId,
                InviteeEmailAddress = request.Email,
                BrandOrganizationId = _currentBrandMember.BrandOrganizationId,
                Role = request.Role
            });

            return addMembershipResult.Map<Response>();
        }
    }

    public class Response : Result<BrandMembershipInvitationResponseDto>
    {
    }
}
