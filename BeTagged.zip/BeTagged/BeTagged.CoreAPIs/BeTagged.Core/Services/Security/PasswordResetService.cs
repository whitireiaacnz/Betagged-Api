﻿using System;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Otp;
using BeTagged.Core.Services.Users;
using BeTagged.Core.Utils;
using BeTagged.Data.Queries;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Services.Security;

internal class PasswordResetService : IPasswordResetService
{
    private readonly IBtDb _db;
    private readonly IEmailOtpService _emailOtpService;
    private readonly IUserService _userService;

    public PasswordResetService(IBtDb db, IEmailOtpService emailOtpService, IUserService userService)
    {
        _db = db;
        _emailOtpService = emailOtpService;
        _userService = userService;
    }

    public async Task<Result<bool>> SendResetCode(string email, SystemUserTypeOption userType)
    {
        var emailAddress = await _db.EmailAddresses
            .AsNoTracking()
            .GetEmailAddressAsync(email, userType);

        var result = new Result<bool>();

        if (emailAddress is null || !emailAddress.IsPrimary)
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = ValidationMessages.EmailDoesNotExists;
            return result;
        }

        await _emailOtpService.GenerateAndSendEmailOtpAsync(emailAddress, SystemOtpUsageTypeOption.PasswordReset);
        result.Data = true;
        return result;
    }

    public async Task<Result<string>> VerifyResetCode(string email, string code, SystemUserTypeOption userType)
    {
        var result = new Result<string>();

        var emailAddress = await _db.EmailAddresses.AsNoTracking()
            .GetEmailAddressAsync(email, userType);

        if (emailAddress?.IsPrimary != true)
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = ValidationMessages.EmailDoesNotExists;
            return result;
        }

        var verificationResult = await _emailOtpService.VerifyEmailAsync(
            emailAddress.UserId.Value,
            emailAddress.EmailAddressId,
            code,
            SystemOtpUsageTypeOption.PasswordReset);

        if (!verificationResult.IsSuccess)
        {
            result.Error = verificationResult.Error;
            result.ErrorMessage = verificationResult.ErrorMessage;
            return result;
        }

        var token = Guid.NewGuid().ToString();

        var passwordResetToken = new PasswordResetToken()
        {
            Token = BtHasher.Hash(token),
            ValidTillUtc = DateTime.UtcNow.AddMinutes(5),
            UserId = emailAddress.UserId.Value
        };

        _db.PasswordResetTokens.Add(passwordResetToken);

        await _db.SaveChangesAsync();

        result.Data = token;

        return result;
    }

    public async Task<Result<bool>> ResetPassword(string email, string password, string passwordResetToken,
        SystemUserTypeOption userType)
    {
        var hashedToken = BtHasher.Hash(passwordResetToken);

        var normalizedEmail = email.ToUpper();

        var token = await _db.PasswordResetTokens
            .Include(x => x.User)
            .ThenInclude(x => x.EmailAddresses.Where(y => y.NormalizedEmailAddress == normalizedEmail))
            .Where(x => x.Token == hashedToken)
            .Where(x => x.ValidTillUtc >= DateTime.UtcNow)
            .Where(x => x.User.UserType == userType)
            .SingleOrDefaultAsync();

        var result = new Result<bool>();

        if (token is null)
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = "Invalid Password reset token. Please try again.";
            return result;
        }

        var emailAssociatedWithToken = token.User.EmailAddresses.FirstOrDefault()?.NormalizedEmailAddress;

        if (emailAssociatedWithToken != email.ToUpper())
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = "Invalid Password reset token. Please try again.";
            return result;
        }

        await _userService.ChangePasswordAsync(token.UserId, password);

        token.IsDeleted = true;

        await _db.SaveChangesAsync();

        result.Data = true;

        return result;
    }
}
