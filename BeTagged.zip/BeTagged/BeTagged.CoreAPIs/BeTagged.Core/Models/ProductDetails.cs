﻿namespace BeTagged.Core.Models;

public class ProductDetails
{
    public ProductDetails()
    {
        ShowCaseMediaUrls = Enumerable.Empty<string>();
    }

    public int BrandProductId { get; set; }

    public string ProductName { get; set; }

    public IEnumerable<string> ShowCaseMediaUrls { get; set; }
}
