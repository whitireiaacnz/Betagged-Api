﻿namespace BeTagged.Data.Enums;

[EnumLookupTable(typeof(SystemSalesChannel))]
public enum SystemSalesChannelOption : byte
{
    Facebook = 1,
    TikTok = 2,
    Instagram = 3,
    Twitter = 4
}
