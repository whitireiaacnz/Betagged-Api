﻿namespace BeTagged.Data;

public interface IReadOnlyBtDb : IBtDb
{
}
