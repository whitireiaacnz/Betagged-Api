﻿using System.Threading;

namespace BeTagged.Core.Services.Security;

public interface IAuthenticationService
{
    Task<InfluencerAuthenticationResponse> AuthenticateInfluencerAsync(string email, string password);

    Task<BrandMemberAuthenticationResponse> AuthenticateBrandMemberAsync(string emailAddress, string password, string invitationKey);

    Task<BrandMemberAuthenticationResponse> AuthenticateBrandMemberByPhoneAsync(string countryCode, string phoneNumber,
        string otp, string invitationKey, CancellationToken cancellationToken = default);

    Task<InfluencerAuthenticationResponse> AuthenticateInfluencerByPhoneAsync(string countryCode, string phoneNumber,
        string otp, CancellationToken cancellationToken = default);

    Task<BrandMemberAuthenticationResponse> GetBrandMemberAuthenticationResponse(int userId, string invitationKey,
        CancellationToken cancellationToken = default);

    Task<Result<BrandMemberAuthenticationResponse>> SwitchBrandOrganization(int brandMemberId, int brandOrganizationId);
}
