﻿using System.Threading;
using BeTagged.Core.CQRS;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.Promotion;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Commands.ProductPromotion;

public static class CreateProductPromotion
{
    public class Command : ITransactionalRequest<Result<ProductPromotionDetails>>
    {
        public SystemSalesChannelOption SalesChannel { get; set; }

        public int BrandProductId { get; set; }
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.BrandProductId).NotEmpty().GreaterThan(0);
        }
    }

    public class Handler : IRequestHandler<Command, Result<ProductPromotionDetails>>
    {
        private readonly IBtDb _db;
        private readonly ICurrentInfluencer _currentInfluencer;
        private readonly IProductPromotionService _productPromotionService;
        private readonly IReadOnlyRepository<Influencer> _influencersRepository;
        private readonly IReadOnlyRepository<Data.Entities.BrandProductDiscountCode> _discountcodeRepository;

        public Handler(IBtDb db, ICurrentInfluencer currentInfluencer, IProductPromotionService productPromotionService,
            IReadOnlyRepository<Influencer> influencersRepository, IReadOnlyRepository<BrandProductDiscountCode> discountcodeRepository)
        {
            _db = db;
            _currentInfluencer = currentInfluencer;
            _productPromotionService = productPromotionService;
            _influencersRepository = influencersRepository;
            _discountcodeRepository = discountcodeRepository;
        }

        public async Task<Result<ProductPromotionDetails>> Handle(Command request, CancellationToken cancellationToken)
        {
            var getInfluencerSpec = new GetInfluencerCountryIdSpec(_currentInfluencer.InfluencerId);
            var influencerCountryId = await _influencersRepository.SingleAsync(getInfluencerSpec, cancellationToken);

            var product = await _db.BrandProducts
                 .Include(x => x.ProductPromotionRequests.Where(y => y.InfluencerId == _currentInfluencer.InfluencerId
                                                                    && y.BrandProductId == request.BrandProductId && y.SalesChannelId == request.SalesChannel))
                 .Include(x => x.ProductPromotions.Where(y => y.InfluencerId == _currentInfluencer.InfluencerId
                                                             && y.BrandProductId == request.BrandProductId && y.SalesChannelId == request.SalesChannel))
                 .ThenInclude(x => x.ProductPromotionLink)
                 .Include(x => x.ProductPromotions.Where(y => y.InfluencerId == _currentInfluencer.InfluencerId
                                                             && y.BrandProductId == request.BrandProductId && y.SalesChannelId == request.SalesChannel))
                 .ThenInclude(x => x.DiscountCode)
                 .Where(x => x.BrandProductId == request.BrandProductId)
                 .Where(x => x.ProductStatusId == SystemProductStatusOption.Listed)
                 .Where(x => x.CountryId == influencerCountryId)
                 .SingleOrDefaultAsync(cancellationToken);

            var result = new Result<ProductPromotionDetails>();

            if (product is null)
            {
                result.Error = ErrorType.ResourceNotFound;
                result.ErrorMessage = ValidationMessages.ProductDoesNotExist;
                return result;
            }

            if (product.BuyerDiscountPercentage > 0)
            {
                var discountcodeAvailableSpec = new AreDiscountCodesAvailableSpec(product.BrandProductId);
                var isDicountcodeAvailable = await _discountcodeRepository.AnyAsync(discountcodeAvailableSpec, cancellationToken);

                if (!isDicountcodeAvailable)
                {
                    result.Error = ErrorType.Conflict;
                    result.ErrorMessage = "Discount codes are exhausted";
                    return result;
                }
            }

            var promotionRequest = product
                .ProductPromotionRequests
                .FirstOrDefault(x => x.SalesChannelId == request.SalesChannel);
            var promotion = product.ProductPromotions.FirstOrDefault(x => x.SalesChannelId == request.SalesChannel);

            if (promotionRequest is not null || promotion is not null)
            {
                result.Data = new ProductPromotionDetails()
                {
                    DiscountCode = promotion?.DiscountCode?.DiscountCode,
                    ProductLink = promotion?.ProductPromotionLink.Url,
                    ClickCount = promotion?.ProductPromotionLink.ClickCount,
                    ProductPromotionId = promotion?.ProductPromotionId,
                };

                if (promotionRequest is not null)
                {
                    result.Data.Request = new()
                    {
                        ApprovalStatus = promotionRequest.ApprovalStatusId,
                        RequestedOnUtc = promotionRequest.RequestedOnUtc,
                        ActedOnUtc = promotionRequest.ActedAtUtc,
                        ProductPromotionRequestId = promotionRequest.ProductPromotionRequestId,
                        IsRejectedDueToPeriodExpiration = promotionRequest.IsRejectedDueToPeriodExpiration,
                    };
                }

                return result;
            }

            result = await _productPromotionService.CreatePromotionAsync(request.BrandProductId,
                request.SalesChannel, _currentInfluencer.InfluencerId, product, cancellationToken);

            return result;
        }
    }
}
