﻿using System;
using System.Linq.Expressions;
using BeTagged.Common.Extensions;

namespace BeTagged.Core.Extensions;

public static class IQueryableExtensions
{
    public static IQueryable<T> OrderByDynamic<T>(this IQueryable<T> source, string orderBy, string defaultOrderBy)
    {
        if (orderBy.IsNullOrEmpty() && defaultOrderBy.IsNullOrEmpty())
        {
            return source;
        }

        string internalOrderBy = orderBy.Trim();
retry: ParameterExpression parameter = Expression.Parameter(source.ElementType, string.Empty);
        MemberExpression property;

        var orderByParts = internalOrderBy.Split(" ");
        var columnName = orderByParts[0];
        string direction = orderByParts.Length == 1 ? "asc" : orderByParts[1];

        try
        {
            property = Expression.Property(parameter, columnName);
        }
        catch (ArgumentException)
        {
            internalOrderBy = defaultOrderBy.Trim();
            goto retry;
        }

        LambdaExpression lambda = Expression.Lambda(property, parameter);

        string methodName = string.Equals(direction, "asc", StringComparison.OrdinalIgnoreCase)
            ? "OrderBy"
            : "OrderByDescending";

        Expression methodCallExpression = Expression.Call(typeof(Queryable), methodName,
            new[] { source.ElementType, property.Type },
            source.Expression, Expression.Quote(lambda));

        return source.Provider.CreateQuery<T>(methodCallExpression);
    }
}
