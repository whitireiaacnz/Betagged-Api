﻿using Newtonsoft.Json;

namespace BeTagged.Core.Models;

public class InfluencerProductsModel : Result
{
    [JsonIgnore]
    public int TotalCount { get; set; }

    public int BrandProductId { get; set; }

    public string Name { get; set; }

    public string CurrencyCode { get; set; }

    public string CurrencySymbol { get; set; }

    public decimal Price { get; set; }

    public string BrandName { get; set; }

    public string BrandProductCategories { get; set; }

    public int CommissionPercentage { get; set; }

    public bool IsApprovalBasedOffer { get; set; }

    public IEnumerable<string> ShowCaseMediaUrls { get; set; }
}
