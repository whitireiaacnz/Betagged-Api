﻿namespace BeTagged.Core.Services.Notification;

public static class NotificationPayloadUtil
{
    private const string BrandProductUrlKey = "brandProductUrl";
    private const string BrandProductIdKey = "brandProductId";
    private const string BrandProductNameKey = "brandProductName";
    private const string NotificationTypeKey = "notificationType";
    private const string CouponExhaustingPercentageKey = "exhaustionPercentage";

    public static Dictionary<string, object> BuildProductListedPayload(int productId, string productUrl, string productName)
    {
        return BuildBaseProductRelatedPayload(productId, productUrl, productName,
            SystemInAppNotificationTypeOption.ProductListed);
    }

    public static Dictionary<string, object> BuildPercentageCouponExhaustedPayload(int productId, string productUrl,
        string productName, int exhaustionPercentage)
    {
        var payload = BuildBaseProductRelatedPayload(productId, productUrl, productName,
            SystemInAppNotificationTypeOption.XCouponExhausted);

        payload.Add(CouponExhaustingPercentageKey, exhaustionPercentage);

        return payload;
    }

    public static Dictionary<string, object> BuildSalesDataNeedsToBeUploadedPayload(int productId, string productUrl,
        string productName)
    {
        return BuildBaseProductRelatedPayload(productId, productUrl, productName,
            SystemInAppNotificationTypeOption.SalesDataUploadReminder);
    }

    public static Dictionary<string, object> BuildProductRequestApprovedPayload(int productId, string productUrl,
        string productName)
    {
        return BuildBaseProductRelatedPayload(productId, productUrl, productName,
            SystemInAppNotificationTypeOption.ProductRequestAccepted);
    }

    public static Dictionary<string, object> BuildProductRequestRejectedPayload(int productId, string productUrl,
        string productName)
    {
        return BuildBaseProductRelatedPayload(productId, productUrl, productName,
            SystemInAppNotificationTypeOption.ProductRequestRejected);
    }

    public static Dictionary<string, object> BuildProductUnlistedPayload(int productId, string productUrl,
        string productName)
    {
        return BuildBaseProductRelatedPayload(productId, productUrl, productName,
            SystemInAppNotificationTypeOption.ProductUnlisted);
    }

    public static Dictionary<string, object> BuildProductListingReminderPayload(int daysWithoutListingProduct)
    {
        return new Dictionary<string, object>()
        {
            [NotificationTypeKey] = SystemInAppNotificationTypeOption.ProductListingReminder,
            ["daysWithoutListingProduct"] = daysWithoutListingProduct
        };
    }

    public static Dictionary<string, object> BuildInfluencerSeekingApprovalPayload(int productId, string productUrl,
        string productName)
    {
        return BuildBaseProductRelatedPayload(productId, productUrl, productName,
            SystemInAppNotificationTypeOption.InfluencersSeekingApproval);
    }

    public static Dictionary<string, object> BuildReminderForPickingAProductPayload(int daysWithoutPickingAProduct)
    {
        return new Dictionary<string, object>()
        {
            [NotificationTypeKey] = SystemInAppNotificationTypeOption.ProductPickingReminder,
            ["daysWithoutPickingAProduct"] = daysWithoutPickingAProduct
        };
    }

    public static bool TryGetNotificationType(Dictionary<string, object> payload,
        out SystemInAppNotificationTypeOption? notificationType)
    {
        var result = payload.TryGetValue(NotificationTypeKey, out var value);
        notificationType = value as SystemInAppNotificationTypeOption?;
        return result;
    }

    private static Dictionary<string, object> BuildBaseProductRelatedPayload(int productId, string productUrl,
        string productName, SystemInAppNotificationTypeOption notificationType)
    {
        return new Dictionary<string, object>()
        {
            [BrandProductIdKey] = productId,
            [BrandProductUrlKey] = productUrl,
            [BrandProductNameKey] = productName,
            [NotificationTypeKey] = notificationType
        };
    }
}
