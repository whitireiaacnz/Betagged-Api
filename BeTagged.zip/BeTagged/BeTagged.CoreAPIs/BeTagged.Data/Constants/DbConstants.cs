﻿namespace BeTagged.Data.Constants;

public static class DbConstants
{
    public const int UserSaltLength = 16;

    public const int DiscountCodeLength = 8;

    public const int UrlFieldLength = 256;

    public const int EmailAddressFieldLength = 128;

    public const int DefaultPlatformCommissionPercentage = 10;
}
