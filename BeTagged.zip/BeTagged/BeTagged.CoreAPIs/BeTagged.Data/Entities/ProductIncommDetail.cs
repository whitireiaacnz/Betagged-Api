﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BeTagged.Data.Entities;

public class ProductIncommDetail
{
    public bool IsDeliveredByIncommTeam { get; set; }

    public bool IsDeliveredByBrand { get; set; }

    public List<VariantDetail> VariantDetails { get; set; }

    public string Dimension { get; set; }

    public decimal? Weight { get; set; }

    public string InventoryLocation { get; set; }

    public string ZipCode { get; set; }

    [MaxLength(20)]
    public string ContactPersonNumber { get; set; }
}

public class VariantDetail
{
    public decimal Size { get; set; }

    [MaxLength(128)]
    public string Color { get; set; }

    public int OrderUnits { get; set; }

    public List<string> ProductImageUrls { get; set; }
}
