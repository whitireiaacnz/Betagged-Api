﻿using System;
using System.Threading;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries.Lookups;

public class GetSystemCategoriesLookupSpec : IListResultQuerySpecification<SystemCategory, SystemCategoryLookupItem>
{
    public GetSystemCategoriesLookupSpec()
    {
        Query = async (queryable, ct) => await queryable
            .Select(x => new SystemCategoryLookupItem(x.SystemCategoryId, x.Name, x.CategoryGroupName))
            .ToListAsync(ct);
    }

    public Func<IQueryable<SystemCategory>, CancellationToken, Task<IList<SystemCategoryLookupItem>>> Query { get; }
}
