﻿namespace BeTagged.Core.Configurations;

public class NotificationConfiguration
{
    public const string Section = "NotificationConfiguration";

    public string DefaultQueueName { get; set; }

    public string PriorityQueueName { get; set; }
}
