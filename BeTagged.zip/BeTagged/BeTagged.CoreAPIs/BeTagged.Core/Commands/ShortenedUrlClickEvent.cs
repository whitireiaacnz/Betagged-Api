﻿using System.Threading;
using BeTagged.Data.Services;

namespace BeTagged.Core.Commands;

public static class ShortenedUrlClickEvent
{
    public record Command(string Url) : IRequest<Response>;

    public class Validator : AbstractValidator<Command>
    {
        public Validator() => RuleFor(x => x.Url).NotEmpty();
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IQueryService _queryService;

        public Handler(IQueryService queryService) => _queryService = queryService;

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var parameters = new
            {
                @Url = request.Url
            };

            await _queryService.ExecuteAsync(BtQueryType.UpdateShortenedLinkClickCount, parameters);
            return new Response();
        }
    }

    public class Response : Result
    {
    }
}
