﻿namespace BeTagged.Data.Entities;

public class ProductSocialMediaKit
{
    public string FacebookMediaKitUrl { get; set; }

    public string TikTokMediaKitUrl { get; set; }

    public string TwitterMediaKitUrl { get; set; }

    public string InstagramMediaUrl { get; set; }
}
