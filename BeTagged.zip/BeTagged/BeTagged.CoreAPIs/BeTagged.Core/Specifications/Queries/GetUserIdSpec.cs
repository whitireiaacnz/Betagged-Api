﻿using System;
using BeTagged.Data.Specifications;

namespace BeTagged.Core.Specifications.Queries;

public class GetUserIdSpec : ISingleResultQuerySpecification<User, int>
{
    public GetUserIdSpec(Guid userKey)
    {
        Query = q => q.Where(x => x.UserKey == userKey).Select(x => x.UserId);
    }

    public Func<IQueryable<User>, IQueryable<int>> Query { get; }
}
