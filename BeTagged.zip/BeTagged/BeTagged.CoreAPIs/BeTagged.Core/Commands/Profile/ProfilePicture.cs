﻿using System.Threading;
using BeTagged.Common.Extensions;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Users;
using BeTagged.Core.Utils;

namespace BeTagged.Core.Commands.Profile;

public static class ProfilePicture
{
    public class Command : IRequest<Response>
    {
        public string Url { get; set; }
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.Url)
                .NotEmpty()
                .Must(x => x.IsUri())
                .WithMessage(ValidationMessages.LinkMustBeValidUri)
                .Must(PropertyValidationUtil.IsImageFile)
                .WithMessage(ValidationMessages.ProfilePictureMustBeImageFile);
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IUserService _userService;

        private readonly ICurrentUser _currentUser;

        public Handler(ICurrentUser currentUser, IUserService userService)
        {
            _currentUser = currentUser;
            _userService = userService;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var signedUrl = await _userService.AddProfilePicture(request.Url, _currentUser.UserId);

            var response = new Response
            {
                ProfilePicUrl = signedUrl,
            };

            return response;
        }
    }

    public class Response
    {
        public string ProfilePicUrl { get; set; }
    }
}
