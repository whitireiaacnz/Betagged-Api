﻿using BeTagged.Core.Configurations;
using Microsoft.Extensions.Options;

namespace BeTagged.Core.Services.UrlUtils;

internal class UrlBuilder : IUrlBuilder
{
    private readonly string _webClientBaseUrl;

    public UrlBuilder(IOptions<UrlConfiguration> urlConfig)
    {
        var urlConfig1 = urlConfig.Value;
        _webClientBaseUrl = urlConfig1.WebClientBaseUrl.TrimEnd('/');
    }

    public string SignupInviteUrl(string email, string invitationKey)
    {
        return $"{_webClientBaseUrl}/s/brand/sign-up?email={email}&invitation-key={invitationKey}";
    }

    public string BrandInviteUrl(string email, string invitationKey)
    {
        return $"{_webClientBaseUrl}/app?email={email}&invitation-key={invitationKey}";
    }

    public string BuildProductDetailsUrl(int brandProductId)
    {
        return $"{_webClientBaseUrl}/app/product-details/{brandProductId}";
    }

    public string BuildFacebookHandleUrl(string handle)
    {
        return $"https://www.facebook.com/{handle}";
    }

    public string BuildTikTokHandleUrl(string handle)
    {
        return $"https://www.tiktok.com/{handle}";
    }

    public string BuildInstagramHandleUrl(string handle)
    {
        return $"https://www.instagram.com/{handle}";
    }

    public string BuildTwitterHandleUrl(string handle)
    {
        return $"https://www.twitter.com/{handle}";
    }
}
