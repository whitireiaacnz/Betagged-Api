﻿using System;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetBrandProductDetailsForBrandMemberSpec : ISingleResultQuerySpecification<BrandProduct, BrandProductDetailModel>
{
    public GetBrandProductDetailsForBrandMemberSpec(int brandProductId, int brandOrganizationId)
    {
        Query = queryable => queryable
            .Include(x => x.Categories)
            .Include(x => x.Country)
            .Include(x => x.ProductSales)
            .Where(x => x.BrandProductId == brandProductId)
            .Where(x => x.BrandOrganizationId == brandOrganizationId)
            .Select(x => new BrandProductDetailModel()
            {
                BrandProductId = x.BrandProductId,
                BannerImageUrl = x.BannerImageUrl,
                BuyerDiscountPercentage = x.BuyerDiscountPercentage,
                Categories = x.Categories.Select(y => new LookupItem(y.SystemCategoryId, y.Name)),
                Name = x.Name,
                ProductCode = x.ProductCode,
                ShowCaseMediaUrls = x.ShowCaseMediaUrls,
                SocialMediaKits = x.SocialMediaKits,
                ProductUrl = x.ProductUrl,
                ProductUrlTypeId = x.ProductUrlTypeId,
                ProductStatus = x.ProductStatusId,
                Hashtags = x.Hashtags,
                City = x.City,
                Country = new LookupItem(x.Country.SystemCountryId, x.Country.Name),
                CurrencyCode = x.Country.CurrencyCode,
                CurrencySymbol = x.Country.CurrencySymbol,
                ListedOnUtc = x.ListedOnUtc,
                IsApprovalBasedOffer = x.IsApprovalBasedOffer,
                CommissionPercentage = x.CommissionPercentage,
                Price = x.Price,
                Description = x.Description,
                PayableCommission = x.ProductSales.Sum(y => y.PayableCommission),
                TotalSales = x.ProductSales.Sum(y => y.Quantity),
                TotalSalesAmount = x.ProductSales.Sum(y => y.TotalAmount),
                TotalInfluencers = x.ProductPromotions.Select(y => y.InfluencerId).Distinct().Count(),
                SalesDataLastUploadedAtUtc = x.SalesDataLastUploadedAtUtc,
                UnlistedAtUtc = x.UnlistedAtUtc,
                PlatformCommissionPercentage = x.PlatformCommissionPercentage,
                InfluencerCommissionPercentage = x.InfluencerCommissionPercentage,
                ProductIncommDetails = x.ProductIncommDetails
            });
    }

    public Func<IQueryable<BrandProduct>, IQueryable<BrandProductDetailModel>> Query { get; }
}
