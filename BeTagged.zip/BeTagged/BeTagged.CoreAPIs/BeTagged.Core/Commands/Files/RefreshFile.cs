﻿using System;
using System.Threading;
using BeTagged.Core.Services.Storage;

namespace BeTagged.Core.Commands.Files;

public static class RefreshFile
{
    public record Command(string File) : IRequest<Response>;

    public class Validator : AbstractValidator<Command>
    {
        public Validator() => RuleFor(x => x.File).NotEmpty();
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IStorageService _storageService;

        public Handler(IStorageService storageService) => _storageService = storageService;

        public Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var refreshedUrl = _storageService.GetSignedUrl(request.File, DateTime.UtcNow.AddMinutes(5));

            return Task.FromResult(new Response(refreshedUrl));
        }
    }

    public record Response(string FileUrl);
}
