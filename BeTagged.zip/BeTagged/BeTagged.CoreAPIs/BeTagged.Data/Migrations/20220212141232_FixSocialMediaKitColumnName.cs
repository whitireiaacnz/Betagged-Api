﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class FixSocialMediaKitColumnName : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.RenameColumn(
            name: "social_media_kits_social_media_kit",
            schema: "public",
            table: "brand_products",
            newName: "social_media_kits");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.RenameColumn(
            name: "social_media_kits",
            schema: "public",
            table: "brand_products",
            newName: "social_media_kits_social_media_kit");
    }
}
