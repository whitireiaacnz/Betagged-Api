﻿namespace BeTagged.Core.Dtos;

public class AddBrandMemberDto
{
    public int InvitedByBrandMemberId { get; set; }

    public string InviteeEmailAddress { get; set; }

    public int BrandOrganizationId { get; set; }

    public SystemRoleOption Role { get; set; }
}
