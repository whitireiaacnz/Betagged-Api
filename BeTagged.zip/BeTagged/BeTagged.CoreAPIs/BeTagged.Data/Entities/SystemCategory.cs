﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BeTagged.Data.Entities;

[Table("system_categories_lut")]
public class SystemCategory
{
    public SystemCategory()
    {
        BrandOrganizations = new List<BrandOrganization>();
        Influencers = new List<Influencer>();
        BrandProducts = new List<BrandProduct>();
    }

    [DatabaseGenerated(DatabaseGeneratedOption.None)]
    public short SystemCategoryId { get; set; }

    [MaxLength(64), Required]
    public string Name { get; set; }

    [MaxLength(32), Required]
    public string CategoryGroupName { get; set; }

    // Reverse navigation
    public ICollection<BrandOrganization> BrandOrganizations { get; set; }

    public ICollection<Influencer> Influencers { get; set; }

    public ICollection<BrandProduct> BrandProducts { get; set; }
}
