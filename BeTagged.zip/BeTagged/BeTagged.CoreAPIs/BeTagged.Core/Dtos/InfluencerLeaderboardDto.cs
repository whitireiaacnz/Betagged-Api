﻿using Newtonsoft.Json;

namespace BeTagged.Core.Dtos;

public class InfluencerLeaderboardDto
{
    [JsonIgnore]
    public int InfluencerId { get; set; }

    public string InfluencerProfilePicUrl { get; set; }

    public string Name { get; set; }

    public int Sales { get; set; }

    public decimal Commission { get; set; }

    public string CurrencyCode { get; set; }

    public string CurrencySymbol { get; set; }

    public IEnumerable<SalesChannelDetails> SalesChannelData { get; set; }
}

public class SalesChannelDetails
{
    public SystemSalesChannelOption SalesChannel { get; set; }

    public int Sale { get; set; }
}
