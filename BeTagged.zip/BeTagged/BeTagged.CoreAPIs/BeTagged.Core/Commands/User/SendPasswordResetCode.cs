﻿using System.Threading;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Commands.User;

public static class SendPasswordResetCode
{
    public record Command(string Email, SystemUserTypeOption? UserType) : IRequest<Response>;

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.Email).NotEmpty().EmailAddress();
            RuleFor(x => x.UserType).NotNull();
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IPasswordResetService _passwordResetService;

        public Handler(IPasswordResetService passwordResetService) => _passwordResetService = passwordResetService;

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var result = await _passwordResetService.SendResetCode(request.Email, request.UserType!.Value);

            var response = new Response();

            if (!result.IsSuccess)
            {
                response.Error = result.Error;
                response.ErrorMessage = result.ErrorMessage;
            }

            return response;
        }
    }

    public class Response : Result
    {
    }
}
