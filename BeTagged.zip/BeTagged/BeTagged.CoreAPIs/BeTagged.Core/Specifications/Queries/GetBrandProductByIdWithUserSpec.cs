﻿using System;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetBrandProductByIdWithUserSpec : ISingleResultQuerySpecification<BrandProduct, BrandProduct>
{
    public GetBrandProductByIdWithUserSpec(int brandProductId)
    {
        Query = q => q
            .Include(x => x.CreatedByUser)
            .Where(x => x.BrandProductId == brandProductId);
    }

    public Func<IQueryable<BrandProduct>, IQueryable<BrandProduct>> Query { get; }
}
