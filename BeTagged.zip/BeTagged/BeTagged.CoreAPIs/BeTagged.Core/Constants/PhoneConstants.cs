﻿namespace BeTagged.Core.Constants;

public static class PhoneConstants
{
    public const string DummyOtp = "123456";
    public const string SmsFrom = "+19362376912";
    public const string OtpSmsTemplate = "Your Otp for Betagged is {0}";
    public const int OtpLength = 6;
    public static readonly string[] AllowedOtpChar = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };
}
