﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

public class CommissionPayoutEntityConfiguration : IEntityTypeConfiguration<CommissionPayout>
{
    public void Configure(EntityTypeBuilder<CommissionPayout> builder)
    {
        builder.HasKey(x => x.CommissionPayoutId);

        builder.Property(x => x.CommissionPayoutId)
            .UseIdentityAlwaysColumn();

        builder.HasOne(x => x.Influencer)
           .WithMany(x => x.CommissionPayouts)
           .HasForeignKey(x => x.InfluencerId);

        builder.HasOne(x => x.BrandOrganization)
            .WithMany(x => x.CommissionPayouts)
            .HasForeignKey(x => x.BrandOrganizationId);

        builder.HasOne(x => x.ProductSale)
            .WithOne().HasForeignKey<CommissionPayout>(x => x.ProductSaleId);

        builder.HasOne(x => x.Transaction)
           .WithOne().HasForeignKey<CommissionPayout>(x => x.TransactionId);
    }
}
