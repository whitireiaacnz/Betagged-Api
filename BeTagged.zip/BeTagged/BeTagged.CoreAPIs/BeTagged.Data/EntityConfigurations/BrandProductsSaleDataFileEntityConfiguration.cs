﻿using BeTagged.Data.Constants;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

internal class BrandProductsSaleDataFileEntityConfiguration : IEntityTypeConfiguration<BrandProductsSalesDataFile>
{
    public void Configure(EntityTypeBuilder<BrandProductsSalesDataFile> builder)
    {
        builder.HasKey(x => x.BrandProductsSaleDataFileId);

        builder.Property(x => x.BrandProductsSaleDataFileId)
            .UseIdentityAlwaysColumn();

        builder.Property(x => x.FilePath).HasMaxLength(DbConstants.UrlFieldLength).IsRequired();

        builder.HasOne(x => x.BrandProduct)
           .WithMany(x => x.BrandProductsSaleDataFiles)
           .HasForeignKey(x => x.BrandProductId);

        builder.HasOne(x => x.UploadedByMember)
           .WithMany(x => x.BrandProductsSaleDataFiles)
           .HasForeignKey(x => x.UploadedByMemberId);
    }
}
