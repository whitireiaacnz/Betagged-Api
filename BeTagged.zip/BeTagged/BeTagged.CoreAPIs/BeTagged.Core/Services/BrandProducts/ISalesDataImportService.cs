﻿namespace BeTagged.Core.Services.BrandProducts;

public interface ISalesDataImportService
{
    Task ImportSalesDataAsync(int salesDataFileId);

    Task<Result<bool>> ValidateSalesDataFileAsync(string url);
}
