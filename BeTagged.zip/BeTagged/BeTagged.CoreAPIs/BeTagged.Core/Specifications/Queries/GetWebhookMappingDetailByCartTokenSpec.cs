﻿using System;
using BeTagged.Data.Specifications;

namespace BeTagged.Core.Specifications.Queries;

public class GetWebhookMappingDetailByCartTokenSpec
    : ISingleResultQuerySpecification<WebhookMappingDetail, WebhookMappingDetail>
{
    public GetWebhookMappingDetailByCartTokenSpec(string cartToken)
    {
        Query = queryable => queryable.Where(x => x.CartToken == cartToken);
    }

    public Func<IQueryable<WebhookMappingDetail>, IQueryable<WebhookMappingDetail>> Query { get; }
}
