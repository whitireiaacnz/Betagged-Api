﻿namespace BeTagged.Core.Models;

public record SystemCategoryLookupItem(int Id, string Name, string CategoryGroupName) : LookupItem(Id, Name);
