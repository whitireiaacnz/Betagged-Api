﻿using BeTagged.Data.Constants;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

public class BrandProductDiscountCodesFileEntityConfiguration : IEntityTypeConfiguration<BrandProductDiscountCodesFile>
{
    public void Configure(EntityTypeBuilder<BrandProductDiscountCodesFile> builder)
    {
        builder.HasKey(x => x.BrandProductDiscountCodesFileId);

        builder.Property(x => x.FilePath).HasMaxLength(DbConstants.UrlFieldLength).IsRequired();

        builder.Property(x => x.BrandProductDiscountCodesFileId)
            .UseIdentityAlwaysColumn();

        builder.HasOne(x => x.BrandProduct)
            .WithMany(x => x.DiscountCodesFiles)
            .HasForeignKey(x => x.BrandProductId);
    }
}
