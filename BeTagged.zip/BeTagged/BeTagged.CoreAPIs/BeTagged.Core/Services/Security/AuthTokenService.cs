﻿using System.Security.Claims;
using BeTagged.Core.Configurations;
using Microsoft.Extensions.Options;

namespace BeTagged.Core.Services.Security;

internal class AuthTokenService : IAuthTokenService
{
    private readonly ITokenService _tokenService;
    private readonly SecurityConfiguration _securityConfiguration;

    public AuthTokenService(ITokenService tokenService, IOptions<SecurityConfiguration> securityConfiguration)
    {
        _tokenService = tokenService;
        _securityConfiguration = securityConfiguration.Value;
    }

    public string GetTokenForInfluencer(Influencer influencer)
    {
        var claims = new List<Claim>
        {
            new(ClaimsConstants.UserId, influencer.UserId.ToString()),
            new(ClaimsConstants.InfluencerId, influencer.InfluencerId.ToString()),
            new(ClaimsConstants.UserType, ((int)SystemUserTypeOption.Influencer).ToString()),
            new(ClaimsConstants.UserKey, influencer.User.UserKey.ToString())
        };

        return _tokenService.GenerateToken(
            _securityConfiguration.TokenSecretKey,
            claims,
            _securityConfiguration.TokenIssuer,
            _securityConfiguration.TokenAudience);
    }

    public string GetTokenForBrandMember(BrandMember brandMember, BrandMembership brandMembership)
    {
        var claims = new List<Claim>()
        {
            new(ClaimsConstants.UserId, brandMember.UserId.ToString()),
            new(ClaimsConstants.BrandMemberId, brandMember.BrandMemberId.ToString()),
            new(ClaimsConstants.UserType, ((int)SystemUserTypeOption.BrandMember).ToString()),
            new(ClaimsConstants.BrandMembershipId, brandMembership.BrandMembershipId.ToString()),
            new(ClaimsConstants.Role, ((int)brandMembership.RoleId).ToString()),
            new(ClaimsConstants.BrandOrganizationId, brandMembership.BrandOrganizationId.ToString()),
            new(ClaimsConstants.UserKey, brandMember.User.UserKey.ToString())
        };

        return _tokenService.GenerateToken(
            _securityConfiguration.TokenSecretKey,
            claims,
            _securityConfiguration.TokenIssuer,
            _securityConfiguration.TokenAudience);
    }
}
