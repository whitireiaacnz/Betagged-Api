﻿using System;
using Newtonsoft.Json;

namespace BeTagged.Core.Services.Clevertap;

public class UploadUserProfile
{
    public UploadUserProfile()
    {
        Type = "profile";
    }

    [JsonProperty("identity")]
    public Guid Identity { get; set; }

    [JsonProperty("type")]
    public string Type { get; }

    [JsonProperty("profileData")]
    public Dictionary<string, object> ProfileData { get; set; }
}
