﻿namespace BeTagged.Core.Services.Signup;

public interface ICompleteSignupReminderService
{
    void ScheduleCompleterSignupReminderJob(int userId);
}
