﻿using System;
using BeTagged.Data.Specifications;
using Microsoft.EntityFrameworkCore;

namespace BeTagged.Core.Specifications.Queries;

public class GetBrandMemberByUserIdSpec : ISingleResultQuerySpecification<BrandMember, BrandMember>
{
    public GetBrandMemberByUserIdSpec(int userId)
    {
        Query = q => q
            .Include(x => x.User)
            .Where(x => x.UserId == userId);
    }

    public Func<IQueryable<BrandMember>, IQueryable<BrandMember>> Query { get; }
}
