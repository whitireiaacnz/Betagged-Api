﻿namespace BeTagged.Core.Enums;

public enum EmailMode
{
    Test,
    Live
}
