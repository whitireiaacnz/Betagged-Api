﻿using System;
using System.Threading;
using BeTagged.Core.Specifications.Queries.Lookups;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Queries.Lookups;

public static class SystemCategoriesLookup
{
    public record Query : IRequest<IEnumerable<SystemCategoryLookupItem>>;

    public class Handler : IRequestHandler<Query, IEnumerable<SystemCategoryLookupItem>>
    {
        private readonly IRepository<SystemCategory> _systemCategoryRepo;

        public Handler(IRepository<SystemCategory> systemCategoryRepo)
        {
            _systemCategoryRepo = systemCategoryRepo;
        }

        public async Task<IEnumerable<SystemCategoryLookupItem>> Handle(Query request, CancellationToken cancellationToken)
        {
            Func<int, int, int> query = (x, y) => x + y;
            var x = query.Invoke(2, 3);
            DoSomethingMeaningful("Hi", query);
            return await _systemCategoryRepo.ListAsync(new GetSystemCategoriesLookupSpec(), cancellationToken);
        }

#pragma warning disable SA1204 // Static elements should appear before instance elements
        public static int DoSomethingMeaningful(string name, Func<int, int, int> func)
#pragma warning restore SA1204 // Static elements should appear before instance elements
        {
            return func.Invoke(3, 4);
        }
    }
}
