﻿using System;

namespace BeTagged.Core.Models;
public class InfluencerBasicInfo
{
    public InfluencerBasicInfo()
    {
        UserType = SystemUserTypeOption.Influencer;
    }

    public Guid UserKey { get; set; }

    public bool IsInfluencerOnBoarded { get; set; }

    public int PrimaryEmailAddressId { get; set; }

    public string PrimaryEmailAddress { get; set; }

    public bool IsEmailVerified { get; set; }

    public int PrimaryPhoneId { get; set; }

    public string PrimaryPhone { get; set; }

    public bool IsPhoneVerified { get; set; }

    public SystemUserTypeOption UserType { get; }
}
