﻿using System.Threading;
using BeTagged.Common.Extensions;
using BeTagged.Core.CQRS;
using BeTagged.Core.Dtos;
using BeTagged.Core.Services.BrandProducts;
using BeTagged.Core.Utils;
using BeTagged.Core.Validators;

namespace BeTagged.Core.Commands.Product;

public static class AddBrandProduct
{
    public class Command : AddBrandProductDto, ITransactionalRequest<BrandProductModel>
    {
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.Name).NotEmpty();

            RuleFor(x => x.Description).NotEmpty()
                .MinimumLength(25)
                .MaximumLength(1024);

            RuleFor(x => x.Price).GreaterThan(0).WithMessage("Price must be greater than 0");

            RuleFor(x => x.Country).GreaterThan((byte)0);

            RuleFor(x => x.DiscountCodesFileUrl)
                .NotEmpty()
                .Must(x => x.IsUri())
                .WithMessage(ValidationMessages.LinkMustBeValidUri)
                .Must(PropertyValidationUtil.IsExcelFile)
                .WithMessage(ValidationMessages.DiscountCodesFileMustBeExcelFile)
                .When(x => x.BuyerDiscountPercentage > 0);

            RuleFor(x => x.City)
                .Must(PropertyValidationUtil.IsCityValid)
                .MaximumLength(128)
                .When(x => x.City.IsNotNullOrEmpty())
                .WithMessage(ValidationMessages.InvalidCity);

            RuleFor(x => x.Location).NotNull()
                .When(x => x.City.IsNotNullOrEmpty())
                .WithMessage(ValidationMessages.LocationIsRequiredWithCity);

            RuleFor(x => x.CommissionPercentage).GreaterThan(0).LessThanOrEqualTo(100)
                .WithMessage("Commission Percentage must be between 0 and 100");

            RuleFor(x => x.BuyerDiscountPercentage).GreaterThanOrEqualTo(0).LessThanOrEqualTo(100)
                .WithMessage("Buyer Discount Percentage must be between 0 and 100");

            RuleFor(x => x.BannerImageUrl).NotEmpty()
                .Must(x => x.IsUri())
                .WithMessage(ValidationMessages.LinkMustBeValidUri);

            RuleFor(x => x.ShowCaseMediaUrls).Must(x => x.Count() <= 6)
                .WithMessage("ShowCaseMediaUrls must have less than 6 items.");

            RuleForEach(x => x.ShowCaseMediaUrls).NotEmpty()
                .Must(x => x.IsUri())
                .WithMessage(ValidationMessages.LinkMustBeValidUri);

            RuleFor(x => x.ProductUrls.CompanyProductUrl)
                .Must(x => x.IsUri())
                .WithMessage(ValidationMessages.LinkMustBeValidUri)
                .When(x => x.ProductUrls.CompanyProductUrl is not null);

            RuleFor(x => x.ProductUrls.EcommercePlatformUrl)
                .Must(x => x.IsUri())
                .WithMessage(ValidationMessages.LinkMustBeValidUri)
                .When(x => x.ProductUrls.EcommercePlatformUrl is not null);

            RuleFor(x => x.SocialMediaKits).SetValidator(new BrandProductSocialMediaKitValidator());

            RuleForEach(x => x.ProductIncommDetails.VariantDetails).SetValidator(new ProductVariantValidator())
                .When(x => x.ProductIncommDetails is not null);
        }
    }

    public class Handler : IRequestHandler<Command, BrandProductModel>
    {
        private readonly IBrandProductService _brandProductService;

        public Handler(IBrandProductService brandProductService) => _brandProductService = brandProductService;

        public async Task<BrandProductModel> Handle(Command request, CancellationToken cancellationToken)
        {
            return await _brandProductService.AddBrandProductAsync(request, cancellationToken);
        }
    }
}
