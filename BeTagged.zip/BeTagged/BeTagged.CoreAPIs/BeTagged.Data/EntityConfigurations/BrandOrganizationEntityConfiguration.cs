﻿using System.Collections.Generic;
using BeTagged.Data.Constants;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace BeTagged.Data.EntityConfigurations;

internal class BrandOrganizationEntityConfiguration : IEntityTypeConfiguration<BrandOrganization>
{
    public void Configure(EntityTypeBuilder<BrandOrganization> builder)
    {
        builder.Property(x => x.BrandOrganizationId).UseIdentityAlwaysColumn();

        builder.Property(x => x.EmailDomain).IsRequired();

        builder.Property(x => x.PlatformCommissionPercentage)
            .HasDefaultValue(DbConstants.DefaultPlatformCommissionPercentage);

        builder.HasOne(x => x.OnBoardedByMember)
            .WithOne()
            .HasForeignKey<BrandOrganization>(x => x.OnBoardedByMemberId);

        builder.HasMany(x => x.Categories)
            .WithMany(x => x.BrandOrganizations)
            .UsingEntity<Dictionary<string, object>>(
                "brand_organization_categories",
                j => j.HasOne<SystemCategory>().WithMany().HasForeignKey("system_category_id"),
                j => j.HasOne<BrandOrganization>().WithMany().HasForeignKey("brand_organization_id"));

        // builder.HasIndex(x => x.EmailDomain).IsUnique();
    }
}
