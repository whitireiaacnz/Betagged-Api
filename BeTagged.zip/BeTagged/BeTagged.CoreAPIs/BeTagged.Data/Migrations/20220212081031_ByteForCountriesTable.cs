﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class ByteForCountriesTable : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AlterColumn<byte>(
            name: "system_country_id",
            schema: "public",
            table: "system_countries_lut",
            type: "smallint",
            nullable: false,
            oldClrType: typeof(int),
            oldType: "integer");

        migrationBuilder.AlterColumn<byte>(
            name: "system_country_id",
            schema: "public",
            table: "brand_product_countries",
            type: "smallint",
            nullable: false,
            oldClrType: typeof(int),
            oldType: "integer");
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AlterColumn<int>(
            name: "system_country_id",
            schema: "public",
            table: "system_countries_lut",
            type: "integer",
            nullable: false,
            oldClrType: typeof(byte),
            oldType: "smallint");

        migrationBuilder.AlterColumn<int>(
            name: "system_country_id",
            schema: "public",
            table: "brand_product_countries",
            type: "integer",
            nullable: false,
            oldClrType: typeof(byte),
            oldType: "smallint");
    }
}
