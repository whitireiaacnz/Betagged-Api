﻿using System;
using System.Threading;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Storage;
using BeTagged.Data.Services;

namespace BeTagged.Core.Queries;

public static class GetInfluencerDashboardInsights
{
    public class Query : IRequest<Response>
    {
        public DateTime? From { get; set; }

        public DateTime? To { get; set; }
    }

    public class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.From).LessThan(x => x.To).When(x => x.From is not null);
        }
    }

    public class Handler : IRequestHandler<Query, Response>
    {
        private readonly IQueryService _queryService;
        private readonly ICurrentInfluencer _currentInfluencer;
        private readonly IStorageService _storageService;

        public Handler(IQueryService queryService, ICurrentInfluencer currentInfluencer, IStorageService storageService)
        {
            _queryService = queryService;
            _currentInfluencer = currentInfluencer;
            _storageService = storageService;
        }

        public async Task<Response> Handle(Query request, CancellationToken cancellationToken)
        {
            Response response;

            var parameters = new
            {
                @InfluencerId = _currentInfluencer.InfluencerId,
                @FromDate = request.From,
                @ToDate = request.To,
                @TopSellingProducts = 5
            };

            var queryResult = await _queryService.QueryMultipleAsync(BtQueryType.GetInfluencerDashboardInsights,
                null, parameters);

            using (queryResult)
            {
                response = queryResult.ReadFirst<Response>();
                var currencyInfo = queryResult.ReadFirst<dynamic>();
                response.CurrencyCode = currencyInfo.currencycode;
                response.CurrencySymbol = currencyInfo.currencysymbol;
                response.ProductsActivelyEngaged = queryResult.ReadFirstOrDefault<int>();
                response.TopSellingProducts = queryResult.Read<ProductDetails>();
                response.SocialMediaPerformance = new SocialMediaPerformanceModel()
                {
                    Facebook = queryResult.ReadFirst<SocialMediaPerformanceModel.MediaPlatformPerformance>(),
                    TikTok = queryResult.ReadFirst<SocialMediaPerformanceModel.MediaPlatformPerformance>(),
                    Instagram = queryResult.ReadFirst<SocialMediaPerformanceModel.MediaPlatformPerformance>(),
                    Twitter = queryResult.ReadFirst<SocialMediaPerformanceModel.MediaPlatformPerformance>()
                };
            }

            foreach (var product in response.TopSellingProducts)
            {
                product.ShowCaseMediaUrls = product.ShowCaseMediaUrls
                    .Select(x => _storageService.GetSignedUrl(x));
            }

            return response;
        }
    }

    public class Response
    {
        public Response()
        {
            TopSellingProducts = Enumerable.Empty<ProductDetails>();
        }

        public int ProductSold { get; set; }

        public decimal CommissionEarned { get; set; }

        public string CurrencyCode { get; set; }

        public string CurrencySymbol { get; set; }

        public int ProductsActivelyEngaged { get; set; }

        public IEnumerable<ProductDetails> TopSellingProducts { get; set; }

        public SocialMediaPerformanceModel SocialMediaPerformance { get; set; }
    }
}
