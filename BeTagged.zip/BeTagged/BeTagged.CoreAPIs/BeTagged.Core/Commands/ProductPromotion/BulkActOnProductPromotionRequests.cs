﻿using System.Threading;
using BeTagged.Core.CQRS;
using BeTagged.Core.Dtos;
using BeTagged.Core.Enums;
using BeTagged.Core.Exceptions;
using BeTagged.Core.Services.Promotion;
using BeTagged.Core.Services.Security;

namespace BeTagged.Core.Commands.ProductPromotion;

public static class BulkActOnProductPromotionRequests
{
    public class Command : ITransactionalRequest<Response>
    {
        public int InfluencerId { get; set; }

        public int BrandProductId { get; set; }

        public SystemApprovalStatusOption ApprovalStatus { get; set; }

        public IEnumerable<int> ProductPromotionRequests { get; set; }
    }

    public class Validator : AbstractValidator<Command>
    {
        public Validator()
        {
            RuleFor(x => x.InfluencerId).GreaterThan(0);
            RuleFor(x => x.BrandProductId).GreaterThan(0);
            RuleFor(x => x.ProductPromotionRequests).Must(x => x.Any()).WithMessage($"ProductPromotionRequests must have at least one value.");
            RuleForEach(x => x.ProductPromotionRequests).GreaterThan(0);
        }
    }

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly IProductPromotionService _productPromotionService;
        private readonly ICurrentBrandMember _currentBrandMember;

        public Handler(IProductPromotionService productPromotionService, ICurrentBrandMember currentBrandMember)
        {
            _productPromotionService = productPromotionService;
            _currentBrandMember = currentBrandMember;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var dto = new ActOnProductPromotionRequestsDto()
            {
                InfluencerId = request.InfluencerId,
                ProductPromotionRequestIds = request.ProductPromotionRequests,
                ActedByBrandMemberId = _currentBrandMember.BrandMemberId,
                BrandOrganizationId = _currentBrandMember.BrandOrganizationId,
                BrandProductId = request.BrandProductId,
                ApprovalStatus = request.ApprovalStatus
            };

            try
            {
                var result = await _productPromotionService.ActOnPromotionRequestsAsync(dto);
                return result.Map<Response>();
            }
            catch (DiscountCodesExhaustedException e)
            {
                var response = new Response
                {
                    Error = ErrorType.ValidationError,
                    ErrorMessage = e.Message
                };
                return response;
            }
        }
    }

    public class Response : Result<InfluencerSeekingApprovalModel>
    {
    }
}
