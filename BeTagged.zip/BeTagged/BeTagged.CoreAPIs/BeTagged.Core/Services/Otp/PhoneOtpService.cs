﻿using System;
using BeTagged.Core.Configurations;
using BeTagged.Core.Enums;
using BeTagged.Core.Services.BackgroundWork;
using BeTagged.Core.Services.CDP;
using BeTagged.Core.Services.Communication;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Core.Utils;
using BeTagged.Data.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Z.EntityFramework.Plus;

namespace BeTagged.Core.Services.Otp;

internal class PhoneOtpService : IPhoneOtpService
{
    private readonly IBtDb _db;
    private readonly SecurityConfiguration _securityConfiguration;
    private readonly IPhoneService _phoneService;
    private readonly AppConfiguration _appConfiguration;
    private readonly SmsConfiguration _smsConfiguration;
    private readonly IBackgroundWorker _backgroundWorker;
    private readonly IReadOnlyRepository<User> _usersRepo;

    public PhoneOtpService(IOptions<SecurityConfiguration> securityConfiguration, IBtDb db,
        IPhoneService phoneService, AppConfiguration appConfiguration, IOptions<SmsConfiguration> smsConfiguration,
        IBackgroundWorker backgroundWorker, IReadOnlyRepository<User> usersRepo)
    {
        _db = db;
        _securityConfiguration = securityConfiguration.Value;
        _phoneService = phoneService;
        _appConfiguration = appConfiguration;
        _backgroundWorker = backgroundWorker;
        _usersRepo = usersRepo;
        _smsConfiguration = smsConfiguration.Value;
    }

    public async Task GenerateAndSendPhoneOtpAsync(Phone phone, SystemOtpUsageTypeOption otpUsageType)
    {
        string otp = await GenerateOtpForPhoneAsync(phone, otpUsageType);

        if (IsOtpEnabled())
        {
            await _phoneService.SendOtpText(phone.ToString(), otp);
        }
    }

    public async Task<Result<bool>> VerifyPhoneAsync(int userId, int phoneId, string otp, SystemOtpUsageTypeOption otpUsageType)
    {
        var result = new Result<bool>();

        var phone = await _db.Phones
            .Where(x => (x.UserId == userId || x.UserId == null) && x.PhoneId == phoneId)
            .SingleOrDefaultAsync();

        if (phone is null)
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = ValidationMessages.PhoneDoesNotExists;
            return result;
        }

        var otpEntity = await _db.PhoneOtps
            .Where(x => x.EntityId == phoneId)
            .Where(x => x.Value == otp)
            .Where(x => x.ValidTillUtc >= DateTime.UtcNow)
            .Where(x => x.UsageTypeId == otpUsageType)
            .FirstOrDefaultAsync();

        if (otpEntity is null)
        {
            result.Error = ErrorType.ValidationError;
            result.ErrorMessage = "Invalid Phone OTP.";
            return result;
        }

        phone.IsVerified = true;
        otpEntity.IsDeleted = true;

        phone.UserId = userId;

        await _db.SaveChangesAsync();

        var getUserKeySpec = new GetUserKeySpecification(userId);
        var userKey = await _usersRepo.SingleAsync(getUserKeySpec);

        _backgroundWorker.Enqueue<ICdpService>(x =>
            x.UpdateUserPhoneAsync(userKey, phone.CountryCode, phone.PhoneNumber));

        return result;
    }

    private async Task<string> GenerateOtpForPhoneAsync(Phone phone, SystemOtpUsageTypeOption otpUsageType)
    {
        string otp = string.Empty;

        if (IsOtpEnabled())
        {
            otp = OtpUtil.GenerateRandomOTP(PhoneConstants.OtpLength, PhoneConstants.AllowedOtpChar);
        }
        else
        {
            otp = PhoneConstants.DummyOtp;
        }

        var phoneOtp = new PhoneOtp()
        {
            EntityId = phone.PhoneId,
            Value = otp,
            ValidTillUtc = DateTime.UtcNow.AddMinutes(_securityConfiguration.OtpValidityInMinutes),
            UsageTypeId = otpUsageType
        };

        await _db.PhoneOtps.Where(x => x.EntityId == phone.PhoneId && !x.IsDeleted)
            .Where(x => x.UsageTypeId == otpUsageType)
            .UpdateAsync(_ => new PhoneOtp() { IsDeleted = true });

        _db.PhoneOtps.Add(phoneOtp);
        await _db.SaveChangesAsync();

        return otp;
    }

    private bool IsOtpEnabled()
    {
        return _appConfiguration.Environment == AppEnvironment.Production || _smsConfiguration.SmsMode == SmsMode.Live;
    }
}
