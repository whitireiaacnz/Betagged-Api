﻿using System.Collections.Generic;
using BeTagged.Data.EntityConfigurations;
using BeTagged.Data.Utils;
using Microsoft.EntityFrameworkCore;
using NetTopologySuite.Geometries;

namespace BeTagged.Data.Entities;

[EntityTypeConfiguration(typeof(InfluencerEntityConfiguration))]
public class Influencer : BaseEntity
{
    public Influencer()
    {
        ProductPromotionRequests = new List<ProductPromotionRequest>();
        ProductPromotions = new List<ProductPromotion>();
        Categories = new List<SystemCategory>();
        SocialMediaAccounts = new InfluencerMediaAccounts();
        ProductSales = new List<ProductSale>();
        InfluencerBankAccounts = new List<InfluencerBankAccount>();
    }

    public int InfluencerId { get; set; }

    [JsonbColumn]
    public InfluencerMediaAccounts SocialMediaAccounts { get; set; }

    public int UserId { get; set; }

    public string City { get; set; }

    public byte? CountryId { get; set; }

    [GeometryPoint]
    public Point Location { get; set; }

    public bool HasAcceptedTermsAndCondition { get; set; }

    // Foreign Keys
    public User User { get; set; }

    public SystemCountry Country { get; set; }

    // Many-to-Many
    public ICollection<SystemCategory> Categories { get; set; }

    // Reverse Navigation
    public ICollection<ProductPromotion> ProductPromotions { get; set; }

    public ICollection<ProductPromotionRequest> ProductPromotionRequests { get; set; }

    public ICollection<ProductSale> ProductSales { get; set; }

    public ICollection<CommissionPayout> CommissionPayouts { get; set; }

    public ICollection<InfluencerBankAccount> InfluencerBankAccounts { get; set; }

    public bool IsOnBoarded() => !string.IsNullOrEmpty(User.Name) && Categories.Count > 0 &&
                (SocialMediaAccounts.Twitter != null ||
                SocialMediaAccounts.Facebook != null ||
                SocialMediaAccounts.Instagram != null ||
                SocialMediaAccounts.TikTok != null) && HasAcceptedTermsAndCondition;

    public void SetLocation(double longitude, double latitude)
    {
        Location = SpatialUtils.GetGeometricPoint(longitude, latitude);
    }
}
