﻿using System;
using System.Threading;
using BeTagged.Core.Dtos;
using BeTagged.Core.Queries.Shared;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Services.Storage;
using BeTagged.Data.Services;

namespace BeTagged.Core.Queries.InfluencerBusinessInsight;

public static class GetPlatformInsightsForInfluencer
{
    public class Query : ODataQueryBase, IRequest<Response>
    {
        public SystemSalesChannelOption SalesChannel { get; set; }

        public DateTime? From { get; set; }

        public DateTime? To { get; set; }
    }

    public class Validator : AbstractValidator<Query>
    {
        public Validator()
        {
            RuleFor(x => x.From).LessThan(x => x.To).When(x => x.From is not null);
        }
    }

    public class Handler : IRequestHandler<Query, Response>
    {
        private readonly IQueryService _queryService;
        private readonly ICurrentInfluencer _currentInfluencer;
        private readonly IReadOnlyBtDb _db;
        private readonly IStorageService _storageService;

        public Handler(IQueryService queryService, ICurrentInfluencer currentInfluencer, IReadOnlyBtDb db,
            IStorageService storageService)
        {
            _queryService = queryService;
            _currentInfluencer = currentInfluencer;
            _db = db;
            _storageService = storageService;
        }

        public async Task<Response> Handle(Query request, CancellationToken cancellationToken)
        {
            var response = new Response();

            var parameters = new
            {
                InfluencerId = _currentInfluencer.InfluencerId,
                SalesChannel = request.SalesChannel,
                Take = request.Take,
                Skip = request.Skip,
                FromDate = request.From,
                ToDate = request.To
            };

            List<PlatformInsightResponseDto> allInfluencerData;
            List<PlatformInsightResponseDto> topInfluencerData;
            List<PlatformInsightResponseDto> currentInfluencerData;
            IEnumerable<int> totalCount;
            List<dynamic> currencySymbolAndCode;

            using (var insights = await _queryService.QueryMultipleAsync(BtQueryType.GetInfluencerPlatformInsightsData,
                       null, parameters))
            {
                allInfluencerData = (await insights.ReadAsync<PlatformInsightResponseDto>()).ToList();
                topInfluencerData = (await insights.ReadAsync<PlatformInsightResponseDto>()).ToList();
                currentInfluencerData = (await insights.ReadAsync<PlatformInsightResponseDto>()).ToList();
                totalCount = await insights.ReadAsync<int>();
                currencySymbolAndCode = (await insights.ReadAsync()).ToList();
            }

            int count = totalCount.First();
            string currencyCode = currencySymbolAndCode.First().currencycode;
            string currencySymbol = currencySymbolAndCode.First().currencysymbol;

            List<InfluencerPlatformInsight> platformInsightData = new();

            var brandProductIds = currentInfluencerData.
                Select(x => x.BrandProductId).Distinct();

            var showCaseMediaUrls = _db.BrandProducts
                            .Where(x => brandProductIds.Contains(x.BrandProductId))
                            .Select(x => new
                            {
                                x.ShowCaseMediaUrls,
                                x.BrandProductId
                            }).ToDictionary(x => x.BrandProductId,
                                x => x.ShowCaseMediaUrls);

            foreach (var currentInfluencerProduct in currentInfluencerData)
            {
                var signedShowCaseMediaUrl = showCaseMediaUrls[currentInfluencerProduct.BrandProductId]
                    .Select(x => _storageService.GetSignedUrl(x));
                string productName = currentInfluencerProduct.BrandProductName;
                int brandProductId = currentInfluencerProduct.BrandProductId;

                // Current Influencer
                var currentInfluencerInsight = MapData(currentInfluencerProduct);

                // All Influencer Average
                var allInfluencerProduct = allInfluencerData
                    .Find(x => x.BrandProductId == currentInfluencerProduct.BrandProductId);
                var allInfluencerInsight = MapData(allInfluencerProduct);

                // Top Selling Influencer
                var topInfluencerProduct = topInfluencerData.Find(x => x.BrandProductId
                                                                       == currentInfluencerProduct.BrandProductId);
                var topInfluencerInsight = MapData(topInfluencerProduct);

                platformInsightData.Add(new InfluencerPlatformInsight()
                {
                    BrandProductId = brandProductId,
                    ProductName = productName,
                    CurrencyCode = currencyCode,
                    CurrencySymbol = currencySymbol,
                    ShowCaseMediaUrls = signedShowCaseMediaUrl,
                    CurrentInfluencerData = currentInfluencerInsight,
                    AllInfluencersAverageData = allInfluencerInsight,
                    TopSellingInfluencerData = topInfluencerInsight
                });
            }

            var salesAndClicks = await _queryService.QueryAsync<SalesAndClicksData>(BtQueryType.GetSalesAndClicksForInfluencerBusinessInsights,
                null, parameters);

            response.InfluencerPlatformInsights = platformInsightData;
            response.ClicksSummation = salesAndClicks.Sum(x => x.Clicks);
            response.SalesSummation = salesAndClicks.Sum(x => x.Sales);

            return response;
        }

        private static PlatformInsight MapData(PlatformInsightResponseDto responseDto)
        {
            PlatformInsight platformInsightResponse = new()
            {
                Sales = responseDto.Sales,
                ClickCount = responseDto.ClickCount,
                Conversion = responseDto.Conversions,
                CommissionEarned = responseDto.CommissionEarned
            };

            return platformInsightResponse;
        }
    }

    public class Response
    {
        public int SalesSummation { get; set; }

        public int ClicksSummation { get; set; }

        public IEnumerable<InfluencerPlatformInsight> InfluencerPlatformInsights { get; set; }
    }

    public class PlatformInsight
    {
        public int Sales { get; set; }

        public int ClickCount { get; set; }

        public decimal Conversion { get; set; }

        public decimal CommissionEarned { get; set; }
    }

    public class InfluencerPlatformInsight
    {
        public int BrandProductId { get; set; }

        public string ProductName { get; set; }

        public string CurrencyCode { get; set; }

        public string CurrencySymbol { get; set; }

        public IEnumerable<string> ShowCaseMediaUrls { get; set; }

        public PlatformInsight CurrentInfluencerData { get; set; }

        public PlatformInsight AllInfluencersAverageData { get; set; }

        public PlatformInsight TopSellingInfluencerData { get; set; }
    }
}
