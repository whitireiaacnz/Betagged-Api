﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace BeTagged.Core.Queries.Shared;

public abstract class ODataQueryBase
{
    protected const string DefaultOrderByValidationRegex = OrderByNameValidationRegex + OrderByDirectionValidationRegex;

    protected const string OrderByDirectionValidationRegex = "+( (asc|desc))?";

    private const string OrderByNameValidationRegex = "([a-zA-Z])";

    [DefaultValue(0)]
    public virtual int Skip { get; set; }

    [DefaultValue(100)]
    public virtual int Take { get; set; }

    [RegularExpression(DefaultOrderByValidationRegex)]
    [DefaultValue(null)]
    public virtual string OrderBy { get; set; }

    [DefaultValue(null)]
    public virtual string Criteria { get; set; }

    public T Map<T>() where T : ODataQueryBase, new()
    {
        var instance = new T
        {
            Skip = Skip,
            Take = Take,
            OrderBy = OrderBy,
            Criteria = Criteria
        };

        return instance;
    }
}
