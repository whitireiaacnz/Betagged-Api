﻿using System.Threading;
using BeTagged.Core.Services.Security;
using BeTagged.Core.Specifications.Queries;
using BeTagged.Data.Repositories;

namespace BeTagged.Core.Commands.Product;

public static class CalculateCommissionDistribution
{
    public record Command(int CommissionPercentage) : IRequest<Response>;

    public class Handler : IRequestHandler<Command, Response>
    {
        private readonly ICurrentBrandMember _currentBrandMember;
        private readonly IReadOnlyRepository<BrandOrganization> _brandOrganizationsRepo;

        public Handler(ICurrentBrandMember currentBrandMember, IReadOnlyRepository<BrandOrganization> brandOrganizationsRepo)
        {
            _currentBrandMember = currentBrandMember;
            _brandOrganizationsRepo = brandOrganizationsRepo;
        }

        public async Task<Response> Handle(Command request, CancellationToken cancellationToken)
        {
            var spec = new GetBrandPlatformCommissionPercentageSpec(_currentBrandMember.BrandOrganizationId);
            var platformCommissionPercentageForBrand =
                await _brandOrganizationsRepo.SingleAsync(spec, cancellationToken);

            var (platformCommissionPercentage, influencerCommissionPercentage) = BrandProduct
                .GetCommissionPercentageDistribution(platformCommissionPercentageForBrand,
                    request.CommissionPercentage);

            return new Response()
            {
                PlatformCommissionPercentage = platformCommissionPercentage,
                InfluencerCommissionPercentage = influencerCommissionPercentage
            };
        }
    }

    public class Response : Result
    {
        public decimal PlatformCommissionPercentage { get; set; }

        public decimal InfluencerCommissionPercentage { get; set; }
    }
}
