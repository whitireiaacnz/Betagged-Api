﻿using System;

namespace BeTagged.Core.Services.Security;

public interface ICurrentUser
{
    int UserId { get; }

    public Guid UserKey { get; }

    SystemUserTypeOption UserType { get; }
}
