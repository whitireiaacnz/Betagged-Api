﻿namespace BeTagged.Core.Services.Communication;

public interface IPhoneService
{
    Task SendOtpText(string phoneNumber, string otp);
}
