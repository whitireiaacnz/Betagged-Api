﻿using System;
using BeTagged.Data.Specifications;

namespace BeTagged.Core.Specifications.Queries;

public class GetUserSpec : ISingleResultQuerySpecification<User, User>
{
    public GetUserSpec(int userId)
    {
        Query = queryable => queryable
        .Where(x => x.UserId == userId);
    }

    public Func<IQueryable<User>, IQueryable<User>> Query { get; }
}
