﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace BeTagged.Data.Migrations;

public partial class Initial : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.EnsureSchema(
            name: "public");

        migrationBuilder.CreateTable(
            name: "system_categories_lut",
            schema: "public",
            columns: table => new
            {
                system_category_id = table.Column<short>(type: "smallint", nullable: false),
                name = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_system_categories_lut", x => x.system_category_id);
            });

        migrationBuilder.CreateTable(
            name: "system_otp_entity_types_lut",
            schema: "public",
            columns: table => new
            {
                system_otp_entity_type_id = table.Column<byte>(type: "smallint", nullable: false),
                name = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_system_otp_entity_types_lut", x => x.system_otp_entity_type_id);
            });

        migrationBuilder.CreateTable(
            name: "system_roles_lut",
            schema: "public",
            columns: table => new
            {
                system_role_id = table.Column<byte>(type: "smallint", nullable: false),
                name = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_system_roles_lut", x => x.system_role_id);
            });

        migrationBuilder.CreateTable(
            name: "system_user_types_lut",
            schema: "public",
            columns: table => new
            {
                system_user_type_id = table.Column<byte>(type: "smallint", nullable: false),
                name = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_system_user_types_lut", x => x.system_user_type_id);
            });

        migrationBuilder.CreateTable(
            name: "otps",
            schema: "public",
            columns: table => new
            {
                otp_id = table.Column<int>(type: "integer", nullable: false)
                    .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                value = table.Column<string>(type: "character varying(6)", maxLength: 6, nullable: false),
                valid_till_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                entity_id = table.Column<int>(type: "integer", nullable: false),
                entity_type_id = table.Column<byte>(type: "smallint", nullable: false),
                created_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                modified_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                is_deleted = table.Column<bool>(type: "boolean", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_otps", x => x.otp_id);
                table.ForeignKey(
                    name: "fk_otps_system_otp_entity_types_lut_entity_type_system_otp_ent",
                    column: x => x.entity_type_id,
                    principalSchema: "public",
                    principalTable: "system_otp_entity_types_lut",
                    principalColumn: "system_otp_entity_type_id",
                    onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateTable(
            name: "users",
            schema: "public",
            columns: table => new
            {
                user_id = table.Column<int>(type: "integer", nullable: false)
                    .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                name = table.Column<string>(type: "character varying(64)", maxLength: 64, nullable: true),
                password_hash = table.Column<string>(type: "text", nullable: false),
                user_type = table.Column<byte>(type: "smallint", nullable: false),
                last_login_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                last_activity_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                last_password_change_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                salt = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                created_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                modified_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                is_deleted = table.Column<bool>(type: "boolean", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_users", x => x.user_id);
                table.ForeignKey(
                    name: "fk_users_system_user_types_lut_user_type",
                    column: x => x.user_type,
                    principalSchema: "public",
                    principalTable: "system_user_types_lut",
                    principalColumn: "system_user_type_id",
                    onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateTable(
            name: "email_addresses",
            schema: "public",
            columns: table => new
            {
                email_address_id = table.Column<int>(type: "integer", nullable: false)
                    .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                email_address = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                is_verified = table.Column<bool>(type: "boolean", nullable: false),
                is_primary = table.Column<bool>(type: "boolean", nullable: false),
                user_id = table.Column<int>(type: "integer", nullable: false),
                created_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                modified_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                is_deleted = table.Column<bool>(type: "boolean", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_email_addresses", x => x.email_address_id);
                table.ForeignKey(
                    name: "fk_email_addresses_users_user_id",
                    column: x => x.user_id,
                    principalSchema: "public",
                    principalTable: "users",
                    principalColumn: "user_id",
                    onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateTable(
            name: "influencers",
            schema: "public",
            columns: table => new
            {
                influencer_id = table.Column<int>(type: "integer", nullable: false)
                    .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                social_media_accounts = table.Column<InfluencerMediaAccounts>(type: "jsonb", nullable: true),
                user_id = table.Column<int>(type: "integer", nullable: false),
                created_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                modified_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                is_deleted = table.Column<bool>(type: "boolean", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_influencers", x => x.influencer_id);
                table.ForeignKey(
                    name: "fk_influencers_users_user_id",
                    column: x => x.user_id,
                    principalSchema: "public",
                    principalTable: "users",
                    principalColumn: "user_id",
                    onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateTable(
            name: "phones",
            schema: "public",
            columns: table => new
            {
                phone_id = table.Column<int>(type: "integer", nullable: false)
                    .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                phone_number = table.Column<string>(type: "character varying(16)", maxLength: 16, nullable: false),
                country_code = table.Column<string>(type: "character varying(4)", maxLength: 4, nullable: false),
                is_verified = table.Column<bool>(type: "boolean", nullable: false),
                is_primary = table.Column<bool>(type: "boolean", nullable: false),
                user_id = table.Column<int>(type: "integer", nullable: false),
                created_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                modified_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                is_deleted = table.Column<bool>(type: "boolean", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_phones", x => x.phone_id);
                table.ForeignKey(
                    name: "fk_phones_users_user_id",
                    column: x => x.user_id,
                    principalSchema: "public",
                    principalTable: "users",
                    principalColumn: "user_id",
                    onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateTable(
            name: "influencer_categories",
            schema: "public",
            columns: table => new
            {
                influencer_id = table.Column<int>(type: "integer", nullable: false),
                system_category_id = table.Column<short>(type: "smallint", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_influencer_categories", x => new { x.influencer_id, x.system_category_id });
                table.ForeignKey(
                    name: "fk_influencer_categories_influencers_influencer_id",
                    column: x => x.influencer_id,
                    principalSchema: "public",
                    principalTable: "influencers",
                    principalColumn: "influencer_id",
                    onDelete: ReferentialAction.Restrict);
                table.ForeignKey(
                    name: "fk_influencer_categories_system_categories_lut_system_category",
                    column: x => x.system_category_id,
                    principalSchema: "public",
                    principalTable: "system_categories_lut",
                    principalColumn: "system_category_id",
                    onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateTable(
            name: "brand_members",
            schema: "public",
            columns: table => new
            {
                brand_member_id = table.Column<int>(type: "integer", nullable: false)
                    .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                user_id = table.Column<int>(type: "integer", nullable: false),
                primary_brand_organization_id = table.Column<int>(type: "integer", nullable: true),
                created_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                modified_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                is_deleted = table.Column<bool>(type: "boolean", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_brand_members", x => x.brand_member_id);
                table.ForeignKey(
                    name: "fk_brand_members_users_user_id",
                    column: x => x.user_id,
                    principalSchema: "public",
                    principalTable: "users",
                    principalColumn: "user_id",
                    onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateTable(
            name: "brand_organizations",
            schema: "public",
            columns: table => new
            {
                brand_organization_id = table.Column<int>(type: "integer", nullable: false)
                    .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                legal_name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: true),
                email_domain = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                on_boarded_by_member_id = table.Column<int>(type: "integer", nullable: false),
                created_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                modified_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                is_deleted = table.Column<bool>(type: "boolean", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_brand_organizations", x => x.brand_organization_id);
                table.ForeignKey(
                    name: "fk_brand_organizations_brand_members_on_boarded_by_member_id",
                    column: x => x.on_boarded_by_member_id,
                    principalSchema: "public",
                    principalTable: "brand_members",
                    principalColumn: "brand_member_id",
                    onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateTable(
            name: "brand_memberships",
            schema: "public",
            columns: table => new
            {
                brand_membership_id = table.Column<int>(type: "integer", nullable: false)
                    .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityAlwaysColumn),
                is_disabled = table.Column<bool>(type: "boolean", nullable: false),
                brand_member_id = table.Column<int>(type: "integer", nullable: false),
                brand_organization_id = table.Column<int>(type: "integer", nullable: false),
                invited_by_member_id = table.Column<int>(type: "integer", nullable: false),
                role_id = table.Column<byte>(type: "smallint", nullable: false),
                created_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                modified_at_utc = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                is_deleted = table.Column<bool>(type: "boolean", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_brand_memberships", x => x.brand_membership_id);
                table.ForeignKey(
                    name: "fk_brand_memberships_brand_members_brand_member_id",
                    column: x => x.brand_member_id,
                    principalSchema: "public",
                    principalTable: "brand_members",
                    principalColumn: "brand_member_id",
                    onDelete: ReferentialAction.Restrict);
                table.ForeignKey(
                    name: "fk_brand_memberships_brand_members_invited_by_member_id",
                    column: x => x.invited_by_member_id,
                    principalSchema: "public",
                    principalTable: "brand_members",
                    principalColumn: "brand_member_id",
                    onDelete: ReferentialAction.Restrict);
                table.ForeignKey(
                    name: "fk_brand_memberships_brand_organizations_brand_organization_id",
                    column: x => x.brand_organization_id,
                    principalSchema: "public",
                    principalTable: "brand_organizations",
                    principalColumn: "brand_organization_id",
                    onDelete: ReferentialAction.Restrict);
                table.ForeignKey(
                    name: "fk_brand_memberships_system_roles_lut_role_id",
                    column: x => x.role_id,
                    principalSchema: "public",
                    principalTable: "system_roles_lut",
                    principalColumn: "system_role_id",
                    onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateTable(
            name: "brand_organization_categories",
            schema: "public",
            columns: table => new
            {
                brand_organization_id = table.Column<int>(type: "integer", nullable: false),
                system_category_id = table.Column<short>(type: "smallint", nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("pk_brand_organization_categories", x => new { x.brand_organization_id, x.system_category_id });
                table.ForeignKey(
                    name: "fk_brand_organization_categories_brand_organizations_brand_org",
                    column: x => x.brand_organization_id,
                    principalSchema: "public",
                    principalTable: "brand_organizations",
                    principalColumn: "brand_organization_id",
                    onDelete: ReferentialAction.Restrict);
                table.ForeignKey(
                    name: "fk_brand_organization_categories_system_categories_lut_system_",
                    column: x => x.system_category_id,
                    principalSchema: "public",
                    principalTable: "system_categories_lut",
                    principalColumn: "system_category_id",
                    onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateIndex(
            name: "ix_brand_members_primary_brand_organization_id",
            schema: "public",
            table: "brand_members",
            column: "primary_brand_organization_id");

        migrationBuilder.CreateIndex(
            name: "ix_brand_members_user_id",
            schema: "public",
            table: "brand_members",
            column: "user_id",
            unique: true);

        migrationBuilder.CreateIndex(
            name: "ix_brand_memberships_brand_member_id",
            schema: "public",
            table: "brand_memberships",
            column: "brand_member_id");

        migrationBuilder.CreateIndex(
            name: "ix_brand_memberships_brand_organization_id",
            schema: "public",
            table: "brand_memberships",
            column: "brand_organization_id");

        migrationBuilder.CreateIndex(
            name: "ix_brand_memberships_invited_by_member_id",
            schema: "public",
            table: "brand_memberships",
            column: "invited_by_member_id");

        migrationBuilder.CreateIndex(
            name: "ix_brand_memberships_role_id",
            schema: "public",
            table: "brand_memberships",
            column: "role_id");

        migrationBuilder.CreateIndex(
            name: "ix_brand_organization_categories_system_category_id",
            schema: "public",
            table: "brand_organization_categories",
            column: "system_category_id");

        migrationBuilder.CreateIndex(
            name: "ix_brand_organizations_email_domain",
            schema: "public",
            table: "brand_organizations",
            column: "email_domain",
            unique: true);

        migrationBuilder.CreateIndex(
            name: "ix_brand_organizations_on_boarded_by_member_id",
            schema: "public",
            table: "brand_organizations",
            column: "on_boarded_by_member_id",
            unique: true);

        migrationBuilder.CreateIndex(
            name: "ix_email_addresses_email_address",
            schema: "public",
            table: "email_addresses",
            column: "email_address",
            unique: true);

        migrationBuilder.CreateIndex(
            name: "ix_email_addresses_user_id",
            schema: "public",
            table: "email_addresses",
            column: "user_id");

        migrationBuilder.CreateIndex(
            name: "ix_influencer_categories_system_category_id",
            schema: "public",
            table: "influencer_categories",
            column: "system_category_id");

        migrationBuilder.CreateIndex(
            name: "ix_influencers_user_id",
            schema: "public",
            table: "influencers",
            column: "user_id",
            unique: true);

        migrationBuilder.CreateIndex(
            name: "ix_otps_entity_type_id",
            schema: "public",
            table: "otps",
            column: "entity_type_id");

        migrationBuilder.CreateIndex(
            name: "ix_phones_phone_number_country_code",
            schema: "public",
            table: "phones",
            columns: new[] { "phone_number", "country_code" },
            unique: true);

        migrationBuilder.CreateIndex(
            name: "ix_phones_user_id",
            schema: "public",
            table: "phones",
            column: "user_id");

        migrationBuilder.CreateIndex(
            name: "ix_users_user_type",
            schema: "public",
            table: "users",
            column: "user_type");

        migrationBuilder.AddForeignKey(
            name: "fk_brand_members_brand_organizations_primary_brand_organizatio",
            schema: "public",
            table: "brand_members",
            column: "primary_brand_organization_id",
            principalSchema: "public",
            principalTable: "brand_organizations",
            principalColumn: "brand_organization_id",
            onDelete: ReferentialAction.Restrict);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropForeignKey(
            name: "fk_brand_members_brand_organizations_primary_brand_organizatio",
            schema: "public",
            table: "brand_members");

        migrationBuilder.DropTable(
            name: "brand_memberships",
            schema: "public");

        migrationBuilder.DropTable(
            name: "brand_organization_categories",
            schema: "public");

        migrationBuilder.DropTable(
            name: "email_addresses",
            schema: "public");

        migrationBuilder.DropTable(
            name: "influencer_categories",
            schema: "public");

        migrationBuilder.DropTable(
            name: "otps",
            schema: "public");

        migrationBuilder.DropTable(
            name: "phones",
            schema: "public");

        migrationBuilder.DropTable(
            name: "system_roles_lut",
            schema: "public");

        migrationBuilder.DropTable(
            name: "influencers",
            schema: "public");

        migrationBuilder.DropTable(
            name: "system_categories_lut",
            schema: "public");

        migrationBuilder.DropTable(
            name: "system_otp_entity_types_lut",
            schema: "public");

        migrationBuilder.DropTable(
            name: "brand_organizations",
            schema: "public");

        migrationBuilder.DropTable(
            name: "brand_members",
            schema: "public");

        migrationBuilder.DropTable(
            name: "users",
            schema: "public");

        migrationBuilder.DropTable(
            name: "system_user_types_lut",
            schema: "public");
    }
}
